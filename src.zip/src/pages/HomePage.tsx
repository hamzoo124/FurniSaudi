import React, { useState } from "react";
import HeroSection from "../components/Home/HeroSection";
import SidebarFilters from "../components/Home/SideFilter";


import ProductGrid from "../components/Home/ProductGrid";

const HomePage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Hero Section */}
      <HeroSection />

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex flex-col md:flex-row gap-10">
        {/* Sidebar */}
        <div className="md:w-1/4">
          <SidebarFilters
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
        </div>

        {/* Product Grid */}
        <div className="flex-1">
          <ProductGrid selectedCategory={selectedCategory} />
        </div>
      </div>
    </div>
  );
};

export default HomePage;
