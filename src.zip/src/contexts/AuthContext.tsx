import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";
import { supabase } from "../lib/supabase";

export interface User {
  id: string;
  email: string;
  name: string;
  role: "buyer" | "seller" | "admin";
  status: string;
  phone?: string;
  avatar?: string;
  created_at: string;
  updated_at: string;
}

export interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (
    email: string,
    password: string
  ) => Promise<{ error?: string }>;
  signUp: (
    email: string,
    password: string,
    name: string,
    role: "buyer" | "seller",
    phone?: string,
    city?: string,
    businessName?: string
  ) => Promise<{ error?: string }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initial session
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (session?.user) {
        await fetchUserProfile(session.user.id);
      } else {
        setLoading(false);
      }
    });

    // Auth listener
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session?.user) {
        await fetchUserProfile(session.user.id);
      } else {
        setUser(null);
        setLoading(false);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchUserProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from("users")
        .select("*")
        .eq("id", userId)
        .single();

      if (error) {
        console.error("Error fetching user profile:", error);
        return;
      }

      setUser(data as User);
    } catch (err) {
      console.error("Error in fetchUserProfile:", err);
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) return { error: error.message };

      if (data.user) {
        await fetchUserProfile(data.user.id);
      }

      return {};
    } catch (err) {
      return { error: "An error occurred during sign in" };
    }
  };

  const signUp = async (
    email: string,
    password: string,
    name: string,
    role: "buyer" | "seller",
    phone?: string,
    city?: string,
    businessName?: string
  ) => {
    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
      });

      if (authError) return { error: authError.message };
      if (!authData.user) return { error: "Failed to create user" };

      // Insert user profile
      const { data: userData, error: userError } = await supabase
        .from("users")
        .insert([
          {
            id: authData.user.id,
            email,
            name,
            role,
            status: role === "seller" ? "pending" : "active",
            phone: phone || null,
          },
        ])
        .select()
        .single();

      if (userError) {
        await supabase.auth.admin.deleteUser(authData.user.id);
        return { error: userError.message };
      }

      // Create seller profile
      if (role === "seller" && businessName) {
        const { error: sellerError } = await supabase.from("sellers").insert([
          {
            user_id: authData.user.id,
            business_name: businessName,
            contact_email: email,
            contact_number: phone || "",
            city: city || "",
            approval_status: "pending",
          },
        ]);

        if (sellerError) {
          console.error("Error creating seller profile:", sellerError);
        }
      }

      setUser(userData as User);
      return {};
    } catch (err) {
      return { error: "An error occurred during sign up" };
    }
  };

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) console.error("Error signing out:", error);
      setUser(null);
    } catch (err) {
      console.error("Error in signOut:", err);
    }
  };

  const value: AuthContextType = {
    user,
    loading,
    signIn,
    signUp,
    signOut,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
