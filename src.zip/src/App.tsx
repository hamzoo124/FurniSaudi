import React, { useState, useEffect } from "react";
import { Routes, Route, Navigate, useNavigate, useParams } from "react-router-dom";

// Screens
import HomePage from "./components/HomePage";
import SellerDashboard from "./components/SellerDashboard";
import AdminDashboard from "./components/AdminDashboard";
import AddProduct from "./components/AddProduct";
import OrdersPage from "./components/Orders";
import PaymentsPage from "./components/Payments";
import CustomersPage from "./components/Customers";
import Contracts from "./components/Contracts";
import SettingsPage from "./components/Setting";
import AdvertisingPage from "./components/Advertising";
import { ProductDetail } from "./components/ProductDetail";
import SellerRegistration from "./components/SellerRegistration";
import EditProduct from "./components/EditProduct";
import OrderDetails from "./components/OrderDetails";
import AnalyticsPage from "./components/Analytics";
import WalletPage from "./components/Wallet";
import SupportPage from "./components/Support";
import { Checkout } from "./components/Checkout";

// Simple Cart Component
import { ArrowLeft, Home, UserPlus, Package, Users, ShoppingCart, Megaphone } from "lucide-react";

const SimpleCartPage: React.FC<{
  onNavigate: (page: string, data?: any) => void;
  cartItems: any[];
  onUpdateQuantity: (index: number, quantity: number) => void;
  onRemoveItem: (index: number) => void;
  onClearCart: () => void;
}> = ({ onNavigate, cartItems, onUpdateQuantity, onRemoveItem, onClearCart }) => {
  const calculateTotal = () => {
    return cartItems.reduce((total, item) => {
      const itemPrice = item.product.finalPrice || item.product.price;
      return total + (itemPrice * item.quantity);
    }, 0);
  };

  const handleProceedToCheckout = () => {
    if (cartItems.length === 0) {
      alert("Your cart is empty!");
      return;
    }
    onNavigate('checkout');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <button
            onClick={() => onNavigate('/')}
            className="flex items-center space-x-2 text-gray-600 hover:text-amber-500 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">Back to Home</span>
          </button>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Shopping Cart</h1>
        
        {cartItems.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-600 mb-4">Your cart is empty</p>
            <button
              onClick={() => onNavigate('/')}
              className="bg-amber-500 text-white px-6 py-3 rounded-lg hover:bg-amber-600 transition-colors"
            >
              Continue Shopping
            </button>
          </div>
        ) : (
          <>
            <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
              <div className="space-y-4">
                {cartItems.map((item, index) => (
                  <div key={index} className="flex items-center space-x-4 border-b pb-4">
                    <img
                      src={item.product.images?.[0]}
                      alt={item.product.title || item.product.name}
                      className="w-20 h-20 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold">{item.product.title || item.product.name}</h3>
                      <p className="text-gray-600 text-sm">
                        Price: {(item.product.finalPrice || item.product.price)} SR
                      </p>
                      {item.customization && (
                        <p className="text-xs text-purple-600 mt-1">🎨 Customized Product</p>
                      )}
                    </div>
                    <div className="flex items-center space-x-3">
                      <button
                        onClick={() => onUpdateQuantity(index, item.quantity - 1)}
                        className="w-8 h-8 border rounded-full flex items-center justify-center"
                      >
                        -
                      </button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                        className="w-8 h-8 border rounded-full flex items-center justify-center"
                      >
                        +
                      </button>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-amber-600">
                        {((item.product.finalPrice || item.product.price) * item.quantity).toFixed(2)} SR
                      </p>
                      <button
                        onClick={() => onRemoveItem(index)}
                        className="text-red-500 text-sm hover:text-red-700"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="border-t pt-6 mt-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-xl font-bold">Total: {calculateTotal().toFixed(2)} SR</h3>
                    <button
                      onClick={onClearCart}
                      className="text-red-500 hover:text-red-700 text-sm mt-2"
                    >
                      Clear Cart
                    </button>
                  </div>
                  <button
                    onClick={handleProceedToCheckout}
                    className="bg-amber-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-amber-600 transition-colors"
                  >
                    Proceed to Checkout
                  </button>
                </div>
              </div>
            </div>
            
            <button
              onClick={() => onNavigate('/')}
              className="bg-gray-200 text-gray-800 px-6 py-3 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Continue Shopping
            </button>
          </>
        )}
      </div>
    </div>
  );
};

// ================================
// FLOATING DASHBOARD BUTTONS - DIRECT ACCESS
// ================================
const FloatingDashboardButtons: React.FC<{
  onNavigate: (page: string) => void;
}> = ({ onNavigate }) => {
  const [showTooltip, setShowTooltip] = useState<string | null>(null);
  
  const buttons = [
    {
      icon: <Home className="w-5 h-5" />,
      label: "Home",
      color: "bg-green-600 hover:bg-green-700",
      onClick: () => onNavigate('/'),
      tooltipPosition: "right-16",
    },
    {
      icon: <UserPlus className="w-5 h-5" />,
      label: "Seller Registration",
      color: "bg-purple-600 hover:bg-purple-700",
      onClick: () => onNavigate('/seller-registration'),
      tooltipPosition: "right-16",
    },
    {
      icon: <Package className="w-5 h-5" />,
      label: "Seller Dashboard",
      color: "bg-gray-900 hover:bg-gray-800",
      onClick: () => onNavigate('/seller/dashboard'),
      tooltipPosition: "right-16",
    },
    {
      icon: <Users className="w-5 h-5" />,
      label: "Admin Dashboard",
      color: "bg-blue-600 hover:bg-blue-700",
      onClick: () => onNavigate('/admin-dashboard'),
      tooltipPosition: "right-16",
    },
    {
      icon: <ShoppingCart className="w-5 h-5" />,
      label: "My Cart",
      color: "bg-amber-500 hover:bg-amber-600",
      onClick: () => onNavigate('/cart'),
      tooltipPosition: "right-16",
    },
    // NEW: Advertising button
    {
      icon: <Megaphone className="w-5 h-5" />,
      label: "Advertising Center",
      color: "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700",
      onClick: () => onNavigate('/seller/advertising'),
      tooltipPosition: "right-16",
    }
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3">
      {buttons.map((button, index) => (
        <button
          key={index}
          onClick={button.onClick}
          className={`w-12 h-12 ${button.color} text-white rounded-full shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center group relative`}
          aria-label={button.label}
          onMouseEnter={() => setShowTooltip(button.label)}
          onMouseLeave={() => setShowTooltip(null)}
        >
          {button.icon}
          {showTooltip === button.label && (
            <div 
              className={`absolute ${button.tooltipPosition} top-1/2 -translate-y-1/2 text-white text-xs px-3 py-1.5 rounded whitespace-nowrap pointer-events-none z-50`}
              style={{ 
                backgroundColor: button.color.split(' ')[0].replace('hover:', ''),
                filter: 'brightness(0.9)'
              }}
            >
              {button.label}
            </div>
          )}
        </button>
      ))}
    </div>
  );
};

// ================================
// APP CONTENT
// ================================
function AppContent() {
  const navigate = useNavigate();

  const [wishlistItems, setWishlistItems] = useState<string[]>([]);
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [directOrderData, setDirectOrderData] = useState<any>(null);

  // Load cart from localStorage on mount
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem('cart');
      if (savedCart) {
        setCartItems(JSON.parse(savedCart));
      }
    } catch (error) {
      console.error('Error loading cart:', error);
    }
  }, []);

  // Save cart to localStorage when it changes
  useEffect(() => {
    if (cartItems.length > 0) {
      localStorage.setItem('cart', JSON.stringify(cartItems));
    } else {
      localStorage.removeItem('cart');
    }
  }, [cartItems]);

  // Handle navigation - SIMPLIFIED VERSION
  const handleNavigate = (page: string, data?: any) => {
    console.log('🚀 Navigation called:', page, data);
    
    // Handle checkout navigation - SIMPLIFIED
    if (page === 'checkout') {
      console.log('🎯 CHECKOUT navigation detected');
      
      if (data?.directOrder) {
        console.log('📦 Setting direct order data:', data.directOrder);
        setDirectOrderData(data.directOrder);
      }
      
      navigate('/checkout');
      return;
    }
    
    // Handle advertising navigation
    if (page === 'advertising' || page === 'advertising-center') {
      console.log('📢 Advertising navigation detected');
      navigate('/seller/advertising');
      return;
    }
    
    // Handle product detail navigation
    if (page.startsWith('product-detail-')) {
      const productId = page.replace('product-detail-', '');
      navigate(`/product/${productId}`);
      return;
    }
    
    if (page.startsWith('product-')) {
      const productId = page.replace('product-', '');
      navigate(`/product/${productId}`);
      return;
    }
    
    // Handle other pages
    switch(page) {
      case 'cart':
        navigate('/cart');
        break;
      case 'auth':
      case 'login':
        navigate('/');
        break;
      case 'register':
        navigate('/seller-registration');
        break;
      case 'home':
        navigate('/');
        break;
      case 'seller/dashboard':
        navigate('/seller/dashboard');
        break;
      case 'seller/advertising':
        navigate('/seller/advertising');
        break;
      default:
        // Try to navigate directly if it's a valid path
        if (page.startsWith('/')) {
          navigate(page);
        } else {
          console.warn('Unknown navigation:', page);
        }
        break;
    }
  };

  // Add to cart function
  const handleAddToCart = (productId: string, customization?: any, quantity: number = 1) => {
    console.log('🛍️ Adding to cart:', productId, 'quantity:', quantity);
    
    const savedProducts = JSON.parse(localStorage.getItem('furnitureProducts') || '[]');
    const product = savedProducts.find((p: any) => p.id === productId);
    
    if (!product) {
      alert('Product not found');
      return;
    }

    const cartItem = {
      product: {
        ...product,
        finalPrice: customization?.totalPrice || product.price,
        customization: customization || null
      },
      quantity,
      customization,
      addedAt: new Date().toISOString()
    };
    
    setCartItems(prev => [...prev, cartItem]);
    
    if (customization) {
      alert(`✅ Added ${quantity} customized "${product.name}" to cart!`);
    } else {
      alert(`✅ Added ${quantity} "${product.name}" to cart!`);
    }
  };

  // Remove from cart
  const handleRemoveFromCart = (index: number) => {
    setCartItems(prev => prev.filter((_, i) => i !== index));
  };

  // Update cart quantity
  const handleUpdateCartQuantity = (index: number, quantity: number) => {
    if (quantity < 1) {
      handleRemoveFromCart(index);
      return;
    }
    
    setCartItems(prev => 
      prev.map((item, i) => 
        i === index ? { ...item, quantity } : item
      )
    );
  };

  // Handle order success
  const handleOrderSuccess = () => {
    console.log('✅ Order successful!');
    
    if (cartItems.length > 0 && !directOrderData) {
      setCartItems([]);
      localStorage.removeItem('cart');
    }
    
    setDirectOrderData(null);
    
    setTimeout(() => {
      navigate('/');
    }, 2000);
  };

  // Toggle wishlist
  const handleToggleWishlist = (productId: string) => {
    setWishlistItems(prev =>
      prev.includes(productId) 
        ? prev.filter(id => id !== productId) 
        : [...prev, productId]
    );
  };

  // HomePage Wrapper
  const HomePageWrapper = () => (
    <HomePage
      onNavigate={handleNavigate}
      onAddToCart={handleAddToCart}
      onToggleWishlist={handleToggleWishlist}
      wishlistItems={wishlistItems}
    />
  );

  // Product Detail Wrapper
  const ProductDetailWrapper = () => {
    const { productId } = useParams<{ productId: string }>();
    
    if (!productId) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Product not found</h2>
            <button
              onClick={() => navigate("/")}
              className="bg-amber-500 text-white px-6 py-2 rounded-lg hover:bg-amber-600 transition-colors"
            >
              Back to Home
            </button>
          </div>
        </div>
      );
    }
    
    console.log('📦 Loading product detail for:', productId);
    
    return (
      <ProductDetail
        productId={productId}
        onNavigate={handleNavigate}
        onAddToCart={handleAddToCart}
        onToggleWishlist={handleToggleWishlist}
        wishlistItems={wishlistItems}
      />
    );
  };

  // Cart Page Wrapper
  const CartPageWrapper = () => (
    <SimpleCartPage
      onNavigate={handleNavigate}
      cartItems={cartItems}
      onUpdateQuantity={handleUpdateCartQuantity}
      onRemoveItem={handleRemoveFromCart}
      onClearCart={() => setCartItems([])}
    />
  );

  // Checkout Page Wrapper
  const CheckoutPageWrapper = () => {
    console.log('💳 CheckoutPageWrapper RENDERING');
    console.log('📍 Current URL:', window.location.href);
    
    // Check localStorage for direct order
    useEffect(() => {
      const localStorageOrder = localStorage.getItem('directOrderData');
      if (localStorageOrder && !directOrderData) {
        console.log('📥 Found direct order in localStorage, setting state');
        setDirectOrderData(JSON.parse(localStorageOrder));
      }
    }, []);
    
    return (
      <Checkout
        onNavigate={handleNavigate}
        cartItems={directOrderData ? [] : cartItems}
        onOrderSuccess={handleOrderSuccess}
        directOrder={directOrderData}
      />
    );
  };

  // Edit Product Wrapper
  const EditProductWrapper = () => {
    const { productId } = useParams();
    return (
      <EditProduct 
        productId={productId || ""} 
        onNavigate={handleNavigate}
        onSuccess={() => navigate("/seller/dashboard")} 
      />
    );
  };

  // Order Details Wrappers
  const SellerOrderDetailsWrapper = () => {
    const { orderId } = useParams();
    return (
      <OrderDetails 
        orderId={orderId || ""} 
        onNavigate={handleNavigate}
        onBack={() => navigate("/seller/dashboard")} 
      />
    );
  };

  const AdminOrderDetailsWrapper = () => {
    const { orderId } = useParams();
    return (
      <OrderDetails 
        orderId={orderId || ""} 
        onNavigate={handleNavigate}
        onBack={() => navigate("/admin-dashboard")} 
      />
    );
  };

  // Orders Page Wrappers
  const SellerOrdersPageWrapper = () => (
    <OrdersPage 
      onNavigate={handleNavigate}
      onBack={() => navigate("/seller/dashboard")} 
    />
  );

  const AdminOrdersPageWrapper = () => (
    <OrdersPage 
      onNavigate={handleNavigate}
      onBack={() => navigate("/admin-dashboard")} 
    />
  );

  // Contracts Wrappers
  const ContractsWrapper = () => (
    <Contracts onBack={() => navigate("/seller/dashboard")} />
  );

  const ContractDetailWrapper = () => {
    const { contractId } = useParams();
    const contractData = null;
    return (
      <Contracts 
        onBack={() => navigate("/seller/dashboard")} 
        contractData={contractData} 
      />
    );
  };

  const NewContractFromProductWrapper = () => {
    const { productId } = useParams();
    const productData = null;
    return (
      <Contracts 
        onBack={() => navigate("/seller/dashboard")} 
        productData={productData} 
      />
    );
  };

  const NewContractWrapper = () => (
    <Contracts onBack={() => navigate("/seller/dashboard")} />
  );

  // Advertising Page Wrapper - UPDATED
  const AdvertisingPageWrapper = () => {
    // Get product data from location state if available
    const location = window.location;
    const state = (location as any)?.state;
    
    return (
      <AdvertisingPage 
        onBack={() => navigate("/seller/dashboard")} 
        onNavigate={handleNavigate}
        // Pass product data if available
        initialProductData={state?.product}
      />
    );
  };

  // Other Page Wrappers
  const WalletPageWrapper = () => (
    <WalletPage 
      onNavigate={handleNavigate}
      onBack={() => navigate("/seller/dashboard")} 
    />
  );

  const AnalyticsPageWrapper = () => (
    <AnalyticsPage 
      onNavigate={handleNavigate}
      onBack={() => navigate("/seller/dashboard")} 
    />
  );

  const SupportPageWrapper = () => (
    <SupportPage 
      onNavigate={handleNavigate}
      onBack={() => navigate("/seller/dashboard")} 
    />
  );

  const PaymentsPageWrapper = () => (
    <PaymentsPage 
      onNavigate={handleNavigate}
      onBack={() => navigate("/seller/dashboard")} 
    />
  );

  const SettingsPageWrapper = () => (
    <SettingsPage onLogout={() => navigate("/")} />
  );

  return (
    <div className="relative min-h-screen">
      <FloatingDashboardButtons onNavigate={(page) => handleNavigate(page)} />

      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<HomePageWrapper />} />
        <Route path="/seller-registration" element={<SellerRegistration />} />
        <Route path="/product/:productId" element={<ProductDetailWrapper />} />
        <Route path="/cart" element={<CartPageWrapper />} />
        <Route path="/checkout" element={<CheckoutPageWrapper />} />

        {/* SELLER ROUTES */}
        <Route path="/seller/dashboard" element={<SellerDashboard />} />
        <Route path="/seller/add-product" element={<AddProduct />} />
        <Route path="/seller/edit-product/:productId" element={<EditProductWrapper />} />
        <Route path="/seller/analytics" element={<AnalyticsPageWrapper />} />
        <Route path="/seller/wallet" element={<WalletPageWrapper />} />
        <Route path="/seller/orders" element={<SellerOrdersPageWrapper />} />
        <Route path="/seller/orders/:orderId" element={<SellerOrderDetailsWrapper />} />
        
        {/* Seller Contracts Routes */}
        <Route path="/seller/contracts" element={<ContractsWrapper />} />
        <Route path="/seller/contracts/new" element={<NewContractWrapper />} />
        <Route path="/seller/contracts/:contractId" element={<ContractDetailWrapper />} />
        <Route path="/seller/contracts/new/:productId" element={<NewContractFromProductWrapper />} />
        
        {/* Seller Advertising Routes */}
        <Route path="/seller/advertising" element={<AdvertisingPageWrapper />} />
        
        <Route path="/seller/payments" element={<PaymentsPageWrapper />} />
        <Route path="/seller/settings" element={<SettingsPageWrapper />} />
        <Route path="/seller/support" element={<SupportPageWrapper />} />

        {/* ADMIN ROUTES */}
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/admin/customers" element={<CustomersPage />} />
        <Route path="/admin/orders" element={<AdminOrdersPageWrapper />} />
        <Route path="/admin/orders/:orderId" element={<AdminOrderDetailsWrapper />} />

        {/* Fallback Route - MUST BE LAST */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
}

// ================================
// MAIN APP COMPONENT
// ================================
export default function App() {
  return <AppContent />;
}