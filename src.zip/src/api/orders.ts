import { supabase } from '@/lib/supabase';

export interface Order {
  id: string;
  order_number: string;
  buyer_id: string;
  buyer_name: string;
  buyer_email: string;
  seller_id: string;
  seller_name: string;
  total_amount: number;
  status: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
  payment_status: 'pending' | 'paid' | 'failed' | 'refunded';
  payment_method: 'card' | 'cod' | 'bank_transfer';
  created_at: string;
  items: Array<{
    product_name: string;
    quantity: number;
    price: number;
  }>;
}

export async function getOrders(filters?: {
  page?: number;
  limit?: number;
  status?: string;
  payment_status?: string;
  search?: string;
}) {
  const page = filters?.page || 1;
  const limit = filters?.limit || 10;

  let query = supabase
    .from('orders')
    .select(`
      *,
      order_items (
        product_name,
        quantity,
        price
      )
    `, { count: 'exact' });

  if (filters?.status) {
    query = query.eq('status', filters.status);
  }
  if (filters?.payment_status) {
    query = query.eq('payment_status', filters.payment_status);
  }
  if (filters?.search) {
    query = query.or(`order_number.ilike.%${filters.search}%,buyer_name.ilike.%${filters.search}%`);
  }

  const from = (page - 1) * limit;
  const to = from + limit - 1;

  const { data, error, count } = await query
    .order('created_at', { ascending: false })
    .range(from, to);

  if (error) throw error;

  // Transform data
  const orders = (data || []).map(order => ({
    ...order,
    items: order.order_items || []
  }));

  return {
    data: orders as Order[],
    total: count || 0,
    page,
    limit,
    totalPages: Math.ceil((count || 0) / limit)
  };
}

export async function updateOrderStatus(orderId: string, status: Order['status']) {
  const { error } = await supabase
    .from('orders')
    .update({ status })
    .eq('id', orderId);

  if (error) throw error;
  return { success: true };
}

export async function getOrderStats() {
  const { data } = await supabase
    .from('orders')
    .select('status, payment_status');

  const stats = {
    pending: 0,
    processing: 0,
    shipped: 0,
    delivered: 0,
    cancelled: 0,
    paid: 0,
    unpaid: 0
  };

  (data || []).forEach(order => {
    if (order.status === 'pending') stats.pending++;
    if (order.status === 'processing') stats.processing++;
    if (order.status === 'shipped') stats.shipped++;
    if (order.status === 'delivered') stats.delivered++;
    if (order.status === 'cancelled') stats.cancelled++;
    if (order.payment_status === 'paid') stats.paid++;
    if (order.payment_status === 'pending') stats.unpaid++;
  });

  return stats;
}