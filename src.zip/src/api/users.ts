import { supabase } from '@/lib/supabase';

export interface User {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  phone_number: string;
  avatar_url: string | null;
  is_active: boolean;
  is_banned: boolean;
  last_login: string | null;
  created_at: string;
  login_count: number;
  total_orders: number;
  total_spent: number;
  avg_order_value: number;
  loyalty_points: number;
  membership_tier: 'basic' | 'premium' | 'vip';
  user_type: 'buyer' | 'seller';
}

export async function getUsers(filters?: {
  page?: number;
  limit?: number;
  user_type?: string;
  is_active?: boolean;
  search?: string;
}) {
  const page = filters?.page || 1;
  const limit = filters?.limit || 10;

  // Get buyers
  let buyersQuery = supabase
    .from('buyers')
    .select('*', { count: 'exact' })
    .eq('user_type', 'buyer');

  // Get sellers
  let sellersQuery = supabase
    .from('sellers')
    .select('*', { count: 'exact' })
    .eq('user_type', 'seller');

  if (filters?.is_active !== undefined) {
    buyersQuery = buyersQuery.eq('is_active', filters.is_active);
    sellersQuery = sellersQuery.eq('is_active', filters.is_active);
  }
  if (filters?.search) {
    buyersQuery = buyersQuery.or(`full_name.ilike.%${filters.search}%,email.ilike.%${filters.search}%`);
    sellersQuery = sellersQuery.or(`business_name.ilike.%${filters.search}%,email.ilike.%${filters.search}%`);
  }

  const from = (page - 1) * limit;
  const to = from + limit - 1;

  const [buyersResult, sellersResult] = await Promise.all([
    buyersQuery.range(from, to),
    sellersQuery.range(from, to)
  ]);

  // Combine and transform data
  const buyers = (buyersResult.data || []).map(buyer => ({
    ...buyer,
    user_type: 'buyer' as const,
    full_name: buyer.full_name || 'Unknown Buyer'
  }));

  const sellers = (sellersResult.data || []).map(seller => ({
    ...seller,
    user_type: 'seller' as const,
    full_name: seller.business_name
  }));

  const allUsers = [...buyers, ...sellers].sort((a, b) => 
    new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );

  const totalCount = (buyersResult.count || 0) + (sellersResult.count || 0);

  return {
    data: allUsers as User[],
    total: totalCount,
    page,
    limit,
    totalPages: Math.ceil(totalCount / limit)
  };
}

export async function toggleUserBan(userId: string, isBanned: boolean) {
  // Determine if user is buyer or seller
  const { data: buyer } = await supabase
    .from('buyers')
    .select('id')
    .eq('id', userId)
    .single();

  if (buyer) {
    const { error } = await supabase
      .from('buyers')
      .update({ is_banned: isBanned })
      .eq('id', userId);
    if (error) throw error;
  } else {
    const { error } = await supabase
      .from('sellers')
      .update({ is_active: !isBanned })
      .eq('id', userId);
    if (error) throw error;
  }

  return { success: true };
}

export async function updateUserMembership(userId: string, membership: 'basic' | 'premium' | 'vip') {
  const { error } = await supabase
    .from('buyers')
    .update({ membership_tier: membership })
    .eq('id', userId);

  if (error) throw error;
  return { success: true };
}