// src/lib/supabase.ts
import { createClient } from "@supabase/supabase-js";



const supabaseUrl = import.meta.env.VITE_SUPABASE_URL ?? "https://xirbndvzfpuhbgowoark.supabase.co";
const supabaseAnonKey =
  import.meta.env.VITE_SUPABASE_ANON_KEY ??
  "sb_publishable_Q5wuR6FyN2BcZdFy3G7Tew_QCqUp6kF";

 

if (!supabaseUrl || !supabaseAnonKey) {
  // This will show in the browser console if env is missing
  console.error("Missing Supabase env variables: VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY");
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
