import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ShoppingCart, Package, TrendingUp, Wallet, Star, AlertCircle, Plus,
  Trash2, Edit2, Eye, CheckCircle, XCircle, X, Download, Filter, Search,
  RefreshCw, Bell, Settings, LogOut, Home, CreditCard, Calendar, Truck,
  Shield, Clock, FileText, BarChart3, DollarSign, Percent, Activity,
  ChevronRight, ShoppingBag, TrendingDown, Info, ArrowRight, ChevronDown,
  MoreVertical, Upload, Phone, MapPin, Mail, User, Layers,
  Receipt, Users, Tag, BarChart2, TrendingUp as TrendingUpIcon,
  Store, Grid3X3, Check, Ban, UserPlus, AlertTriangle, MessageCircle,
  PieChart, Image as ImageIcon, Smartphone, FileSpreadsheet, UploadCloud,
  DownloadCloud, LayoutDashboard, FileSignature, RefreshCw as RefreshIcon,
  FileCheck, AlertOctagon, Zap, Target, Award, ShieldCheck, FilePlus,
  BadgeCheck, LineChart, FileCode, Brain, MessageSquare, Tag as TagIcon,
  Shield as ShieldIcon, HelpCircle, ThumbsUp, ThumbsDown, Users as UsersIcon,
  Map, Globe, ArrowUp, ArrowDown, BarChart, FileBarChart, Database,
  Link, Share2, Target as TargetIcon, Gift, BellRing, Languages,
  ShieldAlert, Cpu, Cloud, Lock, Unlock, Printer, QrCode, Barcode,
  PackageOpen, Warehouse, Palette, PercentCircle, MousePointerClick,
  Headphones, Mail as MailIcon, MessageSquare as MessageSquareIcon,
  Award as AwardIcon, Trophy, Clock as ClockIcon, Calendar as CalendarIcon,
  Filter as FilterIcon, Sliders, Activity as ActivityIcon,
  UserCheck, UserX, Globe as GlobeIcon, Calculator, FileDigit,
  FileSearch, FileX, FileMinus, FileText as FileTextIcon,
  Server, Network, Camera, Video, Mic, Headset, Banknote, Coins,
  Landmark, Building as BuildingIcon, Navigation, Compass, Ship,
  Plane, Train, Car, Bike, Walk, CalendarDays, CalendarCheck,
  CalendarClock, ChartLine, ChartPie, ChartArea, ChartColumn,
  Table, Wifi, WifiOff, Signal, Battery, BatteryCharging, Power,
  Sun, Moon, Eye as EyeIcon, EyeOff, Key, Fingerprint, Scan,
  Radio, Satellite, Bluetooth, Usb, HdmiPort, MemoryStick,
  HardDrive, Disc, Save, Folder, FolderOpen, File as FileIcon,
  FileArchive, FileAudio, FileVideo, FileImage, FileKey, FileLock,
  FileQuestion, FileWarning, FileDiff, FileOutput, FileInput,
  FileJson, FileTerminal, FileType, BookOpen, Book, Library,
  Newspaper, Terminal, Command, Cursor, Mouse, Keyboard, Type,
  Bold, Italic, Underline, Strikethrough, Highlighter, Pilcrow,
  List, ListOrdered, ListTodo, ListChecks, ListMinus, ListPlus,
  ListX, ListRestart, ListTree, CheckSquare, MinusCircle, PlusCircle,
  ExternalLink, Unlink, FolderPlus, FolderMinus, FolderX, FolderTree,
  FolderSearch, FolderOutput, FolderInput, FolderKey, FolderLock,
  Archive, ArchiveRestore, Box, Boxes, PackageCheck, PackageX,
  PackageSearch, PackagePlus, PackageMinus, TruckDelivery, ConciergeBell,
  ShoppingBasket, StoreFront, Hotel, BedDouble, Bath, Sofa, Armchair,
  Chair, Table as TableIcon, Lamp, LampDesk, LampFloor, LampCeiling,
  Lightbulb, LightbulbOff, Fan as FanIcon, Thermometer, Droplets,
  Wind, Flame, Sprout, TreePine, TreeDeciduous, Flower2, Leaf,
  Mountain, Waves, CloudSun, CloudRain, CloudSnow, CloudFog,
  CloudLightning, DollarSign as DollarSignIcon, CreditCard as CreditCardIcon,
  FilePen, RotateCcw, CheckCircle as CheckCircleIcon, XCircle as XCircleIcon,
  Megaphone // ADDED: Advertising icon
} from 'lucide-react';

// ==============================
// TYPES
// ==============================

interface Seller {
  id: string;
  user_id: string;
  business_name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  status: 'pending' | 'approved' | 'rejected' | 'suspended';
  wallet_balance: number;
  total_earnings: number;
  total_withdrawn: number;
  pending_payout: number;
  created_at: string;
  rating: number;
  total_sales: number;
  total_orders: number;
  logo_url?: string;
  description?: string;
  store_category?: string;
}

interface Product {
  id: string;
  seller_id: string;
  name: string;
  description: string;
  short_description?: string;
  price: number;
  original_price?: number;
  category: string;
  subcategory?: string;
  type: 'ready' | 'customized' | 'both';
  stock_quantity: number;
  images: string[];
  status: 'active' | 'inactive' | 'draft' | 'out_of_stock';
  rating: number;
  order_count: number;
  created_at: string;
  updated_at: string;
  views: number;
  is_featured: boolean;
  material?: string;
  finish_type?: string;
  weight?: number;
  dimensions?: string;
  warranty?: string;
  delivery_option?: string;
  delivery_price?: number;
  delivery_time?: string;
  brand?: string;
  color?: string;
  customization_requests?: CustomizationRequest[];
}

interface CustomizationRequest {
  id: string;
  customer_name: string;
  customer_email: string;
  request_details: string;
  status: 'pending' | 'reviewing' | 'quoted' | 'accepted' | 'rejected' | 'completed';
  created_at: string;
  estimated_price?: number;
  customer_budget?: number;
  notes?: string;
}

interface PaymentRequest {
  id: string;
  amount: number;
  status: 'pending' | 'processing' | 'completed' | 'rejected';
  requested_at: string;
  processed_at?: string;
  method: 'bank_transfer' | 'paypal' | 'credit_card';
  bank_details?: {
    account_name: string;
    account_number: string;
    bank_name: string;
    iban: string;
  };
}

interface ReturnRequest {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  customer_name: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected' | 'refunded';
  amount: number;
  requested_date: string;
  refund_date?: string;
  notes?: string;
}

interface Contract {
  id: string;
  contractNumber: string;
  status: 'draft' | 'sent' | 'accepted' | 'completed' | 'cancelled';
  createdAt: string;
  lastUpdated: string;
  contractType: 'b2b' | 'b2c';
  seller: CompanyInfo;
  buyer: CustomerInfo;
  products: ProductItem[];
  paymentTerms: PaymentTerms;
  delivery: DeliveryInfo;
  warranty: WarrantyInfo;
  terms: TermsAndConditions;
  signatures: Signatures;
}

interface CustomerInfo {
  type: 'b2b' | 'b2c';
  name: string;
  email: string;
  phone: string;
  companyName?: string;
  crNumber?: string;
  taxNumber?: string;
  address: string;
  representative?: string;
  position?: string;
}

interface CompanyInfo {
  type: 'b2b' | 'b2c';
  name: string;
  crNumber: string;
  taxNumber: string;
  address: string;
  phone: string;
  email: string;
  representative: string;
  position: string;
}

interface ProductItem {
  id: string;
  name: string;
  image: string;
  description: string;
  materials: string[];
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  specifications: {
    dimensions: string;
    weight: string;
    color: string;
    material: string;
  };
}

interface PaymentTerms {
  totalAmount: number;
  currency: string;
  deposit: number;
  depositDueDate: string;
  finalPaymentDue: string;
  paymentMethod: string;
  installmentPlan?: Installment[];
}

interface Installment {
  amount: number;
  dueDate: string;
  percentage: number;
}

interface DeliveryInfo {
  address: string;
  estimatedDate: string;
  installationIncluded: boolean;
  shippingCost: number;
  notes: string;
}

interface WarrantyInfo {
  duration: string;
  coverage: string[];
  limitations: string[];
}

interface TermsAndConditions {
  cancellationPolicy: string;
  returnPolicy: string;
  liability: string;
  governingLaw: string;
  forceMajeure: string;
}

interface Signatures {
  sellerSigned: boolean;
  buyerSigned: boolean;
  sellerSignature?: string;
  buyerSignature?: string;
  signedDate?: string;
}

interface DashboardStats {
  total_products: number;
  active_products: number;
  out_of_stock_products: number;
  total_orders: number;
  pending_orders: number;
  total_sales: number;
  total_revenue: number;
  average_rating: number;
  active_advertising: number;
  total_earnings: number;
  pending_payments: number;
  wallet_balance: number;
  weekly_sales: number;
  monthly_growth: number;
  total_contracts: number;
  pending_contracts: number;
  signed_contracts: number;
  pending_customization_requests: number;
  pending_payment_requests: number;
  pending_return_requests: number;
}

interface Order {
  id: string;
  product_id: string;
  product_name: string;
  customer_name: string;
  customer_email: string;
  quantity: number;
  total_price: number;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';
  payment_status: 'pending' | 'paid' | 'failed' | 'refunded';
  order_date: string;
  delivery_date?: string;
  address: string;
}

interface ProductVariant {
  id: string;
  productId: string;
  variantType: 'size' | 'color' | 'material';
  value: string;
  priceAdjustment: number;
  sku: string;
  stock: number;
  image?: string;
}

interface SupportTicket {
  id: string;
  subject: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high';
  createdDate: string;
}

interface SellerPerformanceMetrics {
  score: number;
  fulfillmentRate: number;
  responseTime: number;
  cancellationRate: number;
  returnRate: number;
  customerSatisfaction: number;
}

interface AnalyticsData {
  dailySales: { date: string; sales: number }[];
  monthlyRevenue: { month: string; revenue: number }[];
  topProducts: { name: string; sales: number; revenue: number }[];
}

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  type: 'b2b' | 'b2c';
  totalOrders: number;
  totalSpent: number;
  lastOrderDate: string;
  segment: 'new' | 'regular' | 'vip' | 'loyal';
}

// ==============================
// UTILITY FUNCTIONS
// ==============================

const formatCurrency = (amount: number, currency: string = 'SAR'): string => {
  return new Intl.NumberFormat('en-SA', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  }).format(date);
};

const getStatusColor = (status: string): { bg: string; text: string; border: string } => {
  const colors: Record<string, { bg: string; text: string; border: string }> = {
    active: { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-200' },
    completed: { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-200' },
    paid: { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-200' },
    delivered: { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-200' },
    confirmed: { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-200' },
    approved: { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-200' },
    pending: { bg: 'bg-yellow-100', text: 'text-yellow-800', border: 'border-yellow-200' },
    processing: { bg: 'bg-blue-100', text: 'text-blue-800', border: 'border-blue-200' },
    shipped: { bg: 'bg-purple-100', text: 'text-purple-800', border: 'border-purple-200' },
    cancelled: { bg: 'bg-red-100', text: 'text-red-800', border: 'border-red-200' },
    failed: { bg: 'bg-red-100', text: 'text-red-800', border: 'border-red-200' },
    rejected: { bg: 'bg-red-100', text: 'text-red-800', border: 'border-red-200' },
    inactive: { bg: 'bg-gray-100', text: 'text-gray-800', border: 'border-gray-200' },
    draft: { bg: 'bg-gray-100', text: 'text-gray-800', border: 'border-gray-200' },
    out_of_stock: { bg: 'bg-red-100', text: 'text-red-800', border: 'border-red-200' },
    sent: { bg: 'bg-blue-100', text: 'text-blue-800', border: 'border-blue-200' },
    accepted: { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-200' },
    reviewing: { bg: 'bg-blue-100', text: 'text-blue-800', border: 'border-blue-200' },
    quoted: { bg: 'bg-purple-100', text: 'text-purple-800', border: 'border-purple-200' }
  };

  return colors[status.toLowerCase()] ||
    { bg: 'bg-gray-100', text: 'text-gray-800', border: 'border-gray-200' };
};

// Simulate real-time order processing
const simulateOrder = (productId: string, quantity: number, price: number) => {
  const orderValue = price * quantity;
  const platformFee = orderValue * 0.15; // 15% platform fee
  const sellerEarnings = orderValue - platformFee;
  
  return {
    orderValue,
    platformFee,
    sellerEarnings
  };
};

// ==============================
// UI COMPONENTS
// ==============================

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  iconBgColor: string;
  iconColor: string;
  onClick?: () => void;
  isLoading?: boolean;
  trend?: number;
  subtitle?: string;
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon,
  iconBgColor,
  iconColor,
  onClick,
  isLoading = false,
  trend,
  subtitle
}) => (
  <button
    onClick={onClick}
    className={`bg-white rounded-lg p-4 border border-gray-200 shadow-sm hover:shadow transition-all duration-200 text-left w-full cursor-pointer group ${
      onClick ? 'hover:border-gray-300' : ''
    }`}
  >
    <div className="flex items-center justify-between mb-3">
      <div className={`p-2 rounded-lg ${iconBgColor} group-hover:scale-105 transition-transform duration-200`}>
        <div className={iconColor}>
          {icon}
        </div>
      </div>
      {trend !== undefined && trend !== 0 && (
        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
          trend >= 0 
            ? 'bg-green-100 text-green-800' 
            : 'bg-red-100 text-red-800'
        }`}>
          {trend >= 0 ? '↑' : '↓'} {Math.abs(trend)}%
        </span>
      )}
    </div>
    <p className="text-2xl font-bold text-gray-900 mb-1">
      {isLoading ? '...' : typeof value === 'number' ? formatCurrency(value) : value}
    </p>
    <p className="text-sm font-semibold text-gray-900">
      {title}
    </p>
    {subtitle && (
      <p className="text-xs text-gray-600 mt-1">
        {subtitle}
      </p>
    )}
  </button>
);

interface ProductCardProps {
  product: Product;
  onEdit: () => void;
  onDelete: () => void;
  onView: () => void;
  onCustomizationRequest: () => void;
  onAdvertise: () => void; // NEW: Added advertising handler
}

const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  onEdit, 
  onDelete, 
  onView, 
  onCustomizationRequest,
  onAdvertise // NEW: Added prop
}) => {
  const mainImage = product.images?.[0] || 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=300&fit=crop';

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-sm transition-all duration-200">
      <div className="relative h-40 bg-gray-50 overflow-hidden">
        <img
          src={mainImage}
          alt={product.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
          onError={(e) => {
            e.currentTarget.src = 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=300&fit=crop';
          }}
        />
        
        <div className="absolute top-2 left-2">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(product.status).bg} ${getStatusColor(product.status).text}`}>
            {product.status.replace('_', ' ')}
          </span>
        </div>
        
        <div className="absolute top-2 right-2">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
            product.stock_quantity === 0 ? 'bg-red-100 text-red-800' :
            product.stock_quantity < 5 ? 'bg-yellow-100 text-yellow-800' :
            'bg-green-100 text-green-800'
          }`}>
            Stock: {product.stock_quantity}
          </span>
        </div>
      </div>

      <div className="p-3">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-gray-900 text-sm line-clamp-1 flex-1 pr-2" title={product.name}>
            {product.name}
          </h3>
          <div className="flex items-center gap-0.5">
            <Star className="w-3.5 h-3.5 text-yellow-400 fill-current" />
            <span className="text-xs font-medium">{product.rating?.toFixed(1) || '0.0'}</span>
          </div>
        </div>

        <p className="text-xs text-gray-600 mb-3 line-clamp-2 min-h-[32px]">
          {product.short_description || product.description?.substring(0, 80)}
        </p>

        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="text-base font-bold text-gray-900">
              {formatCurrency(product.price)}
            </p>
            {product.original_price && product.original_price > product.price && (
              <p className="text-xs text-gray-500 line-through">
                {formatCurrency(product.original_price)}
              </p>
            )}
          </div>
          <span className="text-xs px-2 py-1 bg-gray-100 text-gray-700 rounded">
            {product.category}
          </span>
        </div>

        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={onView}
            className="flex-1 min-w-[70px] py-1.5 border border-gray-300 rounded text-xs font-medium hover:bg-gray-50 transition-colors"
          >
            View
          </button>
          <button
            onClick={onEdit}
            className="flex-1 min-w-[70px] py-1.5 border border-gray-300 rounded text-xs font-medium hover:bg-gray-50 transition-colors"
          >
            Edit
          </button>
          <button
            onClick={onCustomizationRequest}
            className="flex-1 min-w-[70px] py-1.5 border border-gray-300 rounded text-xs font-medium hover:bg-gray-50 transition-colors"
          >
            Customize
          </button>
          <button
            onClick={onAdvertise} // NEW: Added advertising button
            className="flex-1 min-w-[70px] py-1.5 border border-gray-300 rounded text-xs font-medium hover:bg-blue-50 hover:text-blue-700 transition-colors flex items-center justify-center gap-1"
          >
            <Megaphone className="w-3 h-3" />
            <span>Advertise</span>
          </button>
          <button
            onClick={onDelete}
            className="p-1.5 border border-gray-300 rounded text-gray-600 hover:bg-red-50 hover:text-red-600 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

// ==============================
// ENHANCED FEATURE COMPONENTS
// ==============================

// 1. Sales Analytics Dashboard
const SalesAnalytics: React.FC<{ data: AnalyticsData; totalRevenue: number }> = ({ data, totalRevenue }) => {
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | '1y'>('30d');

  return (
    <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Sales Analytics</h3>
          <p className="text-sm text-gray-600">Track your sales performance</p>
        </div>
        <div className="flex gap-2">
          {['7d', '30d', '90d', '1y'].map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range as any)}
              className={`px-3 py-1.5 text-sm rounded-lg transition-colors ${
                timeRange === range
                  ? 'bg-gray-900 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-700">Total Revenue</p>
              <p className="text-2xl font-bold text-blue-900">{formatCurrency(totalRevenue)}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-blue-600" />
          </div>
          <p className="text-xs text-blue-600 mt-2">
            {totalRevenue > 0 ? 'Track your revenue growth' : 'Start selling to see revenue'}
          </p>
        </div>

        <div className="bg-gradient-to-r from-green-50 to-green-100 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-700">Available Balance</p>
              <p className="text-2xl font-bold text-green-900">{formatCurrency(totalRevenue * 0.85)}</p>
            </div>
            <Wallet className="w-8 h-8 text-green-600" />
          </div>
          <p className="text-xs text-green-600 mt-2">After 15% platform fee</p>
        </div>

        <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-purple-700">Platform Fee</p>
              <p className="text-2xl font-bold text-purple-900">{formatCurrency(totalRevenue * 0.15)}</p>
            </div>
            <Receipt className="w-8 h-8 text-purple-600" />
          </div>
          <p className="text-xs text-purple-600 mt-2">15% of total revenue</p>
        </div>

        <div className="bg-gradient-to-r from-orange-50 to-orange-100 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-orange-700">Pending Payout</p>
              <p className="text-2xl font-bold text-orange-900">{formatCurrency(totalRevenue * 0.85)}</p>
            </div>
            <CreditCard className="w-8 h-8 text-orange-600" />
          </div>
          <p className="text-xs text-orange-600 mt-2">Available for withdrawal</p>
        </div>
      </div>

      <div className="border border-gray-200 rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-semibold text-gray-900">Revenue Trend</h4>
          <button className="text-blue-600 text-sm font-medium hover:text-blue-800">
            Export Data
          </button>
        </div>
        <div className="h-64 flex items-center justify-center bg-gray-50 rounded">
          {totalRevenue > 0 ? (
            <div className="text-center">
              <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-2" />
              <p className="text-gray-500">Chart visualization would appear here</p>
              <p className="text-xs text-gray-400">Integrate with charting library like Chart.js or Recharts</p>
            </div>
          ) : (
            <div className="text-center">
              <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-2" />
              <p className="text-gray-500">No sales data yet</p>
              <p className="text-xs text-gray-400">Start selling to see analytics</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// 2. Payment Request Component
const PaymentRequests: React.FC<{ 
  pendingPayout: number; 
  onRequestPayment: (amount: number) => void;
  paymentRequests: PaymentRequest[];
}> = ({ pendingPayout, onRequestPayment, paymentRequests }) => {
  const [amount, setAmount] = useState<string>(pendingPayout.toString());
  const [method, setMethod] = useState<'bank_transfer' | 'paypal' | 'credit_card'>('bank_transfer');

  const handleRequest = () => {
    const numAmount = parseFloat(amount);
    if (numAmount > 0 && numAmount <= pendingPayout) {
      onRequestPayment(numAmount);
      setAmount(pendingPayout.toString());
    }
  };

  return (
    <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Payment Requests</h3>
          <p className="text-sm text-gray-600">Request withdrawal of your earnings</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
            Available: {formatCurrency(pendingPayout)}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="border border-gray-200 rounded-lg p-6">
          <h4 className="font-semibold text-gray-900 mb-4">New Payment Request</h4>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Amount to Withdraw
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                  SAR
                </span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full pl-12 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  min="100"
                  max={pendingPayout}
                  step="100"
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Minimum withdrawal: SAR 100
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Payment Method
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setMethod('bank_transfer')}
                  className={`p-3 border rounded-lg text-center ${
                    method === 'bank_transfer'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <Banknote className="w-6 h-6 mx-auto mb-2" />
                  <span className="text-sm">Bank Transfer</span>
                </button>
                <button
                  type="button"
                  onClick={() => setMethod('paypal')}
                  className={`p-3 border rounded-lg text-center ${
                    method === 'paypal'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <CreditCardIcon className="w-6 h-6 mx-auto mb-2" />
                  <span className="text-sm">PayPal</span>
                </button>
                <button
                  type="button"
                  onClick={() => setMethod('credit_card')}
                  className={`p-3 border rounded-lg text-center ${
                    method === 'credit_card'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <CreditCard className="w-6 h-6 mx-auto mb-2" />
                  <span className="text-sm">Credit Card</span>
                </button>
              </div>
            </div>

            <button
              onClick={handleRequest}
              disabled={pendingPayout < 100}
              className={`w-full py-3 rounded-lg font-medium ${
                pendingPayout >= 100
                  ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white hover:opacity-90'
                  : 'bg-gray-200 text-gray-500 cursor-not-allowed'
              }`}
            >
              {pendingPayout >= 100 
                ? `Request Payment - ${formatCurrency(parseFloat(amount) || 0)}`
                : 'Minimum SAR 100 required'
              }
            </button>
          </div>
        </div>

        <div className="border border-gray-200 rounded-lg p-6">
          <h4 className="font-semibold text-gray-900 mb-4">Recent Requests</h4>
          
          {paymentRequests.length > 0 ? (
            <div className="space-y-3">
              {paymentRequests.slice(0, 3).map(request => (
                <div key={request.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">{formatCurrency(request.amount)}</p>
                    <p className="text-xs text-gray-600">
                      {formatDate(request.requested_at)} • {request.method.replace('_', ' ')}
                    </p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    request.status === 'completed' ? 'bg-green-100 text-green-800' :
                    request.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                    request.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {request.status}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <CreditCard className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No payment requests yet</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// 3. Customization Requests Component
const CustomizationRequests: React.FC<{
  requests: CustomizationRequest[];
  products: Product[];
  onUpdateStatus: (requestId: string, status: CustomizationRequest['status'], price?: number) => void;
}> = ({ requests, products, onUpdateStatus }) => {
  const [selectedRequest, setSelectedRequest] = useState<CustomizationRequest | null>(null);
  const [quotePrice, setQuotePrice] = useState<string>('');

  const getProductName = (productId: string) => {
    const product = products.find(p => p.id === productId);
    return product?.name || 'Unknown Product';
  };

  const handleSendQuote = () => {
    if (selectedRequest && quotePrice) {
      onUpdateStatus(selectedRequest.id, 'quoted', parseFloat(quotePrice));
      setSelectedRequest(null);
      setQuotePrice('');
    }
  };

  return (
    <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Customization Requests</h3>
          <p className="text-sm text-gray-600">Manage customer customization requests</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
            {requests.filter(r => r.status === 'pending' || r.status === 'reviewing').length} Pending
          </span>
        </div>
      </div>

      {requests.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-900">Customer</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-900">Request Details</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-900">Budget</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-900">Status</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-900">Date</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {requests.map(request => (
                <tr key={request.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <div>
                      <p className="font-medium text-gray-900">{request.customer_name}</p>
                      <p className="text-xs text-gray-600">{request.customer_email}</p>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <p className="text-sm text-gray-900 line-clamp-2">{request.request_details}</p>
                  </td>
                  <td className="py-3 px-4">
                    {request.customer_budget ? (
                      <p className="font-medium text-gray-900">{formatCurrency(request.customer_budget)}</p>
                    ) : (
                      <p className="text-sm text-gray-500">Not specified</p>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(request.status).bg} ${getStatusColor(request.status).text}`}>
                      {request.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <p className="text-sm text-gray-600">{formatDate(request.created_at)}</p>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex gap-2">
                      {request.status === 'pending' && (
                        <>
                          <button
                            onClick={() => onUpdateStatus(request.id, 'reviewing')}
                            className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700"
                          >
                            Review
                          </button>
                          <button
                            onClick={() => onUpdateStatus(request.id, 'rejected')}
                            className="px-3 py-1.5 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700"
                          >
                            Reject
                          </button>
                        </>
                      )}
                      {request.status === 'reviewing' && (
                        <button
                          onClick={() => {
                            setSelectedRequest(request);
                            setQuotePrice(request.customer_budget?.toString() || '');
                          }}
                          className="px-3 py-1.5 bg-purple-600 text-white rounded-lg text-sm hover:bg-purple-700"
                        >
                          Send Quote
                        </button>
                      )}
                      {(request.status === 'quoted' || request.status === 'accepted') && (
                        <button
                          onClick={() => window.alert(`Request ${request.status}. Estimated price: ${request.estimated_price ? formatCurrency(request.estimated_price) : 'Not set'}`)}
                          className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50"
                        >
                          View
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center py-12">
          <FilePen className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <h4 className="text-lg font-semibold text-gray-900 mb-2">No Customization Requests</h4>
          <p className="text-gray-600 mb-4">Customers haven't requested any customizations yet</p>
        </div>
      )}
    </div>
  );
};

// 4. Return Requests Component
const ReturnRequests: React.FC<{
  requests: ReturnRequest[];
  onUpdateStatus: (requestId: string, status: ReturnRequest['status']) => void;
}> = ({ requests, onUpdateStatus }) => {
  const pendingRequests = requests.filter(r => r.status === 'pending');

  return (
    <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Return Requests</h3>
          <p className="text-sm text-gray-600">Manage customer return requests</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-medium">
            {pendingRequests.length} Pending
          </span>
        </div>
      </div>

      {requests.length > 0 ? (
        <div className="space-y-4">
          {requests.map(request => (
            <div key={request.id} className="border border-gray-200 rounded-lg p-4 hover:border-gray-300 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="font-semibold text-gray-900">{request.product_name}</h4>
                  <p className="text-sm text-gray-600">Order ID: {request.order_id}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(request.status).bg} ${getStatusColor(request.status).text}`}>
                  {request.status}
                </span>
              </div>
              
              <div className="mb-3">
                <p className="text-sm text-gray-700 mb-1">Reason:</p>
                <p className="text-gray-900 p-2 bg-gray-50 rounded">{request.reason}</p>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Requested: {formatDate(request.requested_date)}</p>
                  <p className="font-medium text-gray-900">Amount: {formatCurrency(request.amount)}</p>
                </div>
                
                {request.status === 'pending' && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => onUpdateStatus(request.id, 'approved')}
                      className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => onUpdateStatus(request.id, 'rejected')}
                      className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm"
                    >
                      Reject
                    </button>
                  </div>
                )}
                
                {request.status === 'approved' && (
                  <button
                    onClick={() => onUpdateStatus(request.id, 'refunded')}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm"
                  >
                    Mark as Refunded
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <RotateCcw className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <h4 className="text-lg font-semibold text-gray-900 mb-2">No Return Requests</h4>
          <p className="text-gray-600">No customers have requested returns yet</p>
        </div>
      )}
    </div>
  );
};

// ==============================
// MAIN DASHBOARD COMPONENT
// ==============================

const SellerDashboard: React.FC = () => {
  const navigate = useNavigate();

  // States
  const [loading, setLoading] = useState<boolean>(true);
  const [activeSection, setActiveSection] = useState<string>('dashboard');
  const [seller, setSeller] = useState<Seller | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>([]);
  const [customizationRequests, setCustomizationRequests] = useState<CustomizationRequest[]>([]);
  const [returnRequests, setReturnRequests] = useState<ReturnRequest[]>([]);
  
  const [stats, setStats] = useState<DashboardStats>({
    total_products: 0,
    active_products: 0,
    out_of_stock_products: 0,
    total_orders: 0,
    pending_orders: 0,
    total_sales: 0,
    total_revenue: 0,
    average_rating: 0,
    active_advertising: 0,
    total_earnings: 0,
    pending_payments: 0,
    wallet_balance: 0,
    weekly_sales: 0,
    monthly_growth: 0,
    total_contracts: 0,
    pending_contracts: 0,
    signed_contracts: 0,
    pending_customization_requests: 0,
    pending_payment_requests: 0,
    pending_return_requests: 0
  });

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [language, setLanguage] = useState<'en' | 'ar'>('en');

  // NEW: Function to navigate to advertising page with product info
  const handleNavigateToAdvertising = (productId?: string) => {
    if (productId) {
      // Navigate to advertising page with product info
      navigate('/seller/advertising', { 
        state: { 
          productId,
          product: products.find(p => p.id === productId)
        } 
      });
    } else {
      // Navigate to general advertising page
      navigate('/seller/advertising');
    }
  };

  // Initialize Data
  const initializeData = useCallback(() => {
    // Demo seller with zero balance
    const demoSeller: Seller = {
      id: 'seller_demo_001',
      user_id: 'user_demo_001',
      business_name: 'Premium Furniture Store',
      email: 'seller@example.com',
      phone: '+966 55 123 4567',
      address: '123 King Abdullah Road, Riyadh, Saudi Arabia',
      city: 'Riyadh',
      status: 'approved',
      wallet_balance: 0,
      total_earnings: 0,
      total_withdrawn: 0,
      pending_payout: 0,
      created_at: new Date().toISOString(),
      rating: 0,
      total_sales: 0,
      total_orders: 0,
      logo_url: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=200&h=200&fit=crop',
      description: 'Premium furniture and home decor store',
      store_category: 'Furniture & Home Decor'
    };

    // Sample products with zero initial stats
    const sampleProducts: Product[] = [
      {
        id: 'prod_001',
        seller_id: 'seller_demo_001',
        name: 'Premium Leather Sofa',
        description: 'Luxury genuine leather sofa with premium craftsmanship',
        short_description: 'Luxury leather sofa for modern living rooms',
        price: 4999,
        original_price: 5999,
        category: 'Sofas',
        subcategory: 'Leather Sofas',
        type: 'both',
        stock_quantity: 10,
        images: ['https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&h=600&fit=crop'],
        status: 'active',
        rating: 0,
        order_count: 0,
        created_at: '2024-01-15',
        updated_at: '2024-03-20',
        views: 0,
        is_featured: false,
        material: 'Genuine Leather',
        weight: 85,
        dimensions: '220cm x 95cm x 85cm',
        warranty: '2 years',
        delivery_time: '5-7 days',
        brand: 'Luxury Living',
        color: 'Brown',
        customization_requests: []
      },
      {
        id: 'prod_002',
        seller_id: 'seller_demo_001',
        name: 'Modern Dining Table',
        description: 'Contemporary dining table with glass top and metal legs',
        short_description: 'Elegant dining table for modern homes',
        price: 2999,
        category: 'Dining',
        type: 'both',
        stock_quantity: 5,
        images: ['https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?w=800&h=600&fit=crop'],
        status: 'active',
        rating: 0,
        order_count: 0,
        created_at: '2024-02-10',
        updated_at: '2024-03-18',
        views: 0,
        is_featured: false,
        material: 'Glass & Metal',
        weight: 45,
        dimensions: '180cm x 90cm x 75cm',
        delivery_time: '3-5 days',
        color: 'Silver',
        customization_requests: []
      },
      {
        id: 'prod_003',
        seller_id: 'seller_demo_001',
        name: 'Office Executive Chair',
        description: 'Ergonomic office chair with lumbar support',
        short_description: 'Comfortable office chair for long working hours',
        price: 1899,
        category: 'Office Furniture',
        type: 'both',
        stock_quantity: 15,
        images: ['https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&h=600&fit=crop'],
        status: 'active',
        rating: 0,
        order_count: 0,
        created_at: '2024-01-25',
        updated_at: '2024-03-15',
        views: 0,
        is_featured: false,
        material: 'Mesh & Leather',
        weight: 22,
        dimensions: '65cm x 65cm x 120cm',
        warranty: '3 years',
        delivery_time: '2-4 days',
        color: 'Black',
        customization_requests: []
      }
    ];

    // Initialize empty arrays for requests
    const initialPaymentRequests: PaymentRequest[] = [];
    const initialCustomizationRequests: CustomizationRequest[] = [];
    const initialReturnRequests: ReturnRequest[] = [];

    setSeller(demoSeller);
    setProducts(sampleProducts);
    setPaymentRequests(initialPaymentRequests);
    setCustomizationRequests(initialCustomizationRequests);
    setReturnRequests(initialReturnRequests);

    // Calculate initial stats (all zeros)
    setStats({
      total_products: sampleProducts.length,
      active_products: sampleProducts.filter(p => p.status === 'active').length,
      out_of_stock_products: sampleProducts.filter(p => p.status === 'out_of_stock').length,
      total_orders: 0,
      pending_orders: 0,
      total_sales: 0,
      total_revenue: 0,
      average_rating: 0,
      active_advertising: 0,
      total_earnings: 0,
      pending_payments: 0,
      wallet_balance: 0,
      weekly_sales: 0,
      monthly_growth: 0,
      total_contracts: 0,
      pending_contracts: 0,
      signed_contracts: 0,
      pending_customization_requests: 0,
      pending_payment_requests: 0,
      pending_return_requests: 0
    });

    setLoading(false);
  }, []);

  // Function to simulate an order
  const simulateOrder = (productId: string, quantity: number = 1) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const orderValue = product.price * quantity;
    const platformFee = orderValue * 0.15;
    const sellerEarnings = orderValue - platformFee;

    // Update product stats
    const updatedProducts = products.map(p => 
      p.id === productId 
        ? { 
            ...p, 
            order_count: p.order_count + quantity,
            stock_quantity: Math.max(0, p.stock_quantity - quantity),
            status: p.stock_quantity - quantity <= 0 ? 'out_of_stock' : p.status
          }
        : p
    );

    // Create new order
    const newOrder: Order = {
      id: `order_${Date.now()}`,
      product_id: productId,
      product_name: product.name,
      customer_name: 'Demo Customer',
      customer_email: 'customer@example.com',
      quantity,
      total_price: orderValue,
      status: 'confirmed',
      payment_status: 'paid',
      order_date: new Date().toISOString(),
      address: 'Demo Address'
    };

    // Update stats
    setStats(prev => ({
      ...prev,
      total_orders: prev.total_orders + 1,
      total_sales: prev.total_sales + quantity,
      total_revenue: prev.total_revenue + orderValue,
      total_earnings: prev.total_earnings + sellerEarnings,
      pending_payments: prev.pending_payments + sellerEarnings,
      wallet_balance: prev.wallet_balance + sellerEarnings,
      weekly_sales: prev.weekly_sales + orderValue,
      active_products: updatedProducts.filter(p => p.status === 'active').length,
      out_of_stock_products: updatedProducts.filter(p => p.status === 'out_of_stock').length
    }));

    // Update seller
    setSeller(prev => prev ? {
      ...prev,
      total_orders: prev.total_orders + 1,
      total_sales: prev.total_sales + quantity,
      total_earnings: prev.total_earnings + sellerEarnings,
      pending_payout: prev.pending_payout + sellerEarnings,
      wallet_balance: prev.wallet_balance + sellerEarnings
    } : null);

    setProducts(updatedProducts);
    setOrders(prev => [...prev, newOrder]);

    setSuccess(`Order placed! You earned ${formatCurrency(sellerEarnings)}`);
    setTimeout(() => setSuccess(null), 3000);
  };

  // Function to request payment
  const handleRequestPayment = (amount: number) => {
    if (amount > stats.pending_payments) {
      setError('Requested amount exceeds available balance');
      setTimeout(() => setError(null), 3000);
      return;
    }

    const newPaymentRequest: PaymentRequest = {
      id: `payreq_${Date.now()}`,
      amount,
      status: 'pending',
      requested_at: new Date().toISOString(),
      method: 'bank_transfer',
      bank_details: {
        account_name: seller?.business_name || 'Account Name',
        account_number: 'SA1234567890123456789012',
        bank_name: 'Saudi National Bank',
        iban: 'SA1234567890123456789012'
      }
    };

    setPaymentRequests(prev => [newPaymentRequest, ...prev]);
    setStats(prev => ({
      ...prev,
      pending_payments: prev.pending_payments - amount,
      pending_payment_requests: prev.pending_payment_requests + 1
    }));

    setSuccess(`Payment request for ${formatCurrency(amount)} submitted`);
    setTimeout(() => setSuccess(null), 3000);
  };

  // Function to add customization request
  const handleAddCustomizationRequest = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const newRequest: CustomizationRequest = {
      id: `custreq_${Date.now()}`,
      customer_name: 'Demo Customer',
      customer_email: 'customer@example.com',
      request_details: 'I would like to customize this product with different materials and colors.',
      status: 'pending',
      created_at: new Date().toISOString(),
      customer_budget: product.price * 1.5, // 50% more than base price
      notes: 'Looking for premium customization options'
    };

    // Add request to product
    const updatedProducts = products.map(p =>
      p.id === productId
        ? {
            ...p,
            customization_requests: [...(p.customization_requests || []), newRequest]
          }
        : p
    );

    setCustomizationRequests(prev => [newRequest, ...prev]);
    setProducts(updatedProducts);
    setStats(prev => ({
      ...prev,
      pending_customization_requests: prev.pending_customization_requests + 1
    }));

    setSuccess('Customization request added');
    setTimeout(() => setSuccess(null), 3000);
  };

  // Function to update customization request status
  const handleUpdateCustomizationStatus = (requestId: string, status: CustomizationRequest['status'], price?: number) => {
    const updatedRequests = customizationRequests.map(req =>
      req.id === requestId
        ? { ...req, status, ...(price && { estimated_price: price }) }
        : req
    );

    setCustomizationRequests(updatedRequests);

    if (status === 'accepted' && price) {
      // When customization is accepted, simulate an order
      simulateOrder('prod_001', 1); // Simulate order for first product
    }

    setSuccess(`Customization request ${status}`);
    setTimeout(() => setSuccess(null), 3000);
  };

  // Function to add return request
  const handleAddReturnRequest = () => {
    if (orders.length === 0) {
      setError('No orders available for return');
      setTimeout(() => setError(null), 3000);
      return;
    }

    const order = orders[0]; // Use first order
    const newReturnRequest: ReturnRequest = {
      id: `retreq_${Date.now()}`,
      order_id: order.id,
      product_id: order.product_id,
      product_name: order.product_name,
      customer_name: order.customer_name,
      reason: 'Product damaged during delivery',
      status: 'pending',
      amount: order.total_price,
      requested_date: new Date().toISOString(),
      notes: 'Customer requesting full refund'
    };

    setReturnRequests(prev => [newReturnRequest, ...prev]);
    setStats(prev => ({
      ...prev,
      pending_return_requests: prev.pending_return_requests + 1
    }));

    setSuccess('Return request added');
    setTimeout(() => setSuccess(null), 3000);
  };

  // Function to update return request status
  const handleUpdateReturnStatus = (requestId: string, status: ReturnRequest['status']) => {
    const updatedRequests = returnRequests.map(req =>
      req.id === requestId ? { ...req, status } : req
    );

    setReturnRequests(updatedRequests);

    if (status === 'refunded') {
      // When refunded, deduct from stats
      const request = returnRequests.find(r => r.id === requestId);
      if (request) {
        setStats(prev => ({
          ...prev,
          pending_return_requests: prev.pending_return_requests - 1,
          wallet_balance: Math.max(0, prev.wallet_balance - request.amount),
          pending_payments: Math.max(0, prev.pending_payments - request.amount)
        }));
      }
    }

    setSuccess(`Return request ${status}`);
    setTimeout(() => setSuccess(null), 3000);
  };

  useEffect(() => {
    initializeData();
  }, [initializeData]);

  // Navigation functions
  const handleNavigateToAddProduct = () => {
    navigate('/seller/add-product');
  };

  const handleNavigateToContracts = () => {
    navigate('/seller/contracts');
  };

  const handleNavigateToEditProduct = (productId: string) => {
    navigate(`/seller/edit-product/${productId}`);
  };

  const handleNavigateToViewProduct = (productId: string) => {
    navigate(`/product/${productId}`);
  };

  const handleDeleteProduct = async (productId: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      setProducts(prev => prev.filter(p => p.id !== productId));
      setSuccess('Product deleted successfully');
      setTimeout(() => setSuccess(null), 3000);
    }
  };

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'ar' : 'en');
  };

  // NEW: Advertising stats card
  const AdvertisingStatsCard = () => (
    <StatCard
      title="Active Campaigns"
      value={stats.active_advertising}
      icon={<Megaphone className="w-5 h-5" />}
      iconBgColor="bg-blue-50"
      iconColor="text-blue-600"
      onClick={() => handleNavigateToAdvertising()}
      subtitle="Promote your products"
    />
  );

  // Navigation tabs with advertising section
  const navigationTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, action: () => setActiveSection('dashboard') },
    { id: 'products', label: 'Products', icon: Package, action: () => setActiveSection('products') },
    { id: 'payments', label: 'Payments', icon: CreditCard, action: () => setActiveSection('payments') },
    { id: 'customizations', label: 'Customizations', icon: FilePen, action: () => setActiveSection('customizations') },
    { id: 'returns', label: 'Returns', icon: RotateCcw, action: () => setActiveSection('returns') },
    { id: 'contracts', label: 'Contracts', icon: FileSignature, action: handleNavigateToContracts },
    { id: 'advertising', label: 'Advertising', icon: Megaphone, action: () => handleNavigateToAdvertising() }, // NEW: Advertising tab
    { id: 'analytics', label: 'Analytics', icon: BarChart, action: () => setActiveSection('analytics') },
    { id: 'customers', label: 'Customers', icon: Users, action: () => setActiveSection('customers') },
    { id: 'orders', label: 'Orders', icon: ShoppingBag, action: () => navigate('/seller/orders') },
    { id: 'wallet', label: 'Wallet', icon: Wallet, action: () => navigate('/seller/wallet') },
    { id: 'settings', label: 'Settings', icon: Settings, action: () => navigate('/seller/settings') },
  ];

  // Render sections
  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          title="Total Revenue"
          value={stats.total_revenue}
          icon={<DollarSign className="w-5 h-5" />}
          iconBgColor="bg-green-50"
          iconColor="text-green-600"
          trend={stats.monthly_growth}
          onClick={() => setActiveSection('analytics')}
        />
        <StatCard
          title="Total Orders"
          value={stats.total_orders}
          icon={<ShoppingBag className="w-5 h-5" />}
          iconBgColor="bg-blue-50"
          iconColor="text-blue-600"
          onClick={() => navigate('/seller/orders')}
        />
        <StatCard
          title="Available Balance"
          value={stats.wallet_balance}
          icon={<Wallet className="w-5 h-5" />}
          iconBgColor="bg-purple-50"
          iconColor="text-purple-600"
          onClick={() => setActiveSection('payments')}
          subtitle="Ready for withdrawal"
        />
        <AdvertisingStatsCard /> {/* NEW: Added advertising stats card */}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <button
          onClick={handleNavigateToAddProduct}
          className="bg-white p-4 border border-gray-200 rounded-lg hover:border-gray-300 hover:shadow transition-all text-center"
        >
          <Plus className="w-8 h-8 text-blue-600 mx-auto mb-2" />
          <p className="font-semibold text-gray-900">Add Product</p>
          <p className="text-xs text-gray-600">Add new product to store</p>
        </button>
        
        <button
          onClick={() => simulateOrder('prod_001', 1)}
          className="bg-white p-4 border border-gray-200 rounded-lg hover:border-gray-300 hover:shadow transition-all text-center"
        >
          <ShoppingCart className="w-8 h-8 text-green-600 mx-auto mb-2" />
          <p className="font-semibold text-gray-900">Simulate Order</p>
          <p className="text-xs text-gray-600">Test order processing</p>
        </button>
        
        <button
          onClick={() => handleAddCustomizationRequest('prod_001')}
          className="bg-white p-4 border border-gray-200 rounded-lg hover:border-gray-300 hover:shadow transition-all text-center"
        >
          <FilePen className="w-8 h-8 text-purple-600 mx-auto mb-2" />
          <p className="font-semibold text-gray-900">Add Customization</p>
          <p className="text-xs text-gray-600">Test customization request</p>
        </button>
        
        <button
          onClick={() => handleNavigateToAdvertising()} // NEW: Advertising button
          className="bg-white p-4 border border-gray-200 rounded-lg hover:border-gray-300 hover:shadow transition-all text-center"
        >
          <Megaphone className="w-8 h-8 text-blue-600 mx-auto mb-2" />
          <p className="font-semibold text-gray-900">Start Advertising</p>
          <p className="text-xs text-gray-600">Promote your products</p>
        </button>
      </div>

      {/* Recent Products */}
      <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Recent Products</h3>
            <p className="text-sm text-gray-600">Latest products in your catalog</p>
          </div>
          <button
            onClick={() => setActiveSection('products')}
            className="text-blue-600 text-sm font-medium hover:text-blue-800"
          >
            View All →
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {products.slice(0, 3).map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onEdit={() => handleNavigateToEditProduct(product.id)}
              onDelete={() => handleDeleteProduct(product.id)}
              onView={() => handleNavigateToViewProduct(product.id)}
              onCustomizationRequest={() => handleAddCustomizationRequest(product.id)}
              onAdvertise={() => handleNavigateToAdvertising(product.id)} // NEW: Added advertising handler
            />
          ))}
        </div>
      </div>
    </div>
  );

  const renderProductsManagement = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Products Management</h2>
          <p className="text-gray-600 text-sm">Manage your product catalog</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Export CSV
          </button>
          <button
            onClick={handleNavigateToAddProduct}
            className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800"
          >
            Add Product
          </button>
          <button
            onClick={() => handleNavigateToAdvertising()} // NEW: Advertising button
            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:opacity-90"
          >
            <Megaphone className="w-4 h-4 inline mr-2" />
            Start Advertising
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-gray-900">All Products ({products.length})</h3>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                placeholder="Search products..."
                className="border border-gray-300 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 w-48"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        {products.length === 0 ? (
          <div className="p-8 text-center">
            <Package className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-gray-900 mb-1.5">No products found</h3>
            <p className="text-gray-600 text-sm">Start by adding your first product to your catalog</p>
            <div className="flex gap-3 justify-center mt-4">
              <button
                onClick={handleNavigateToAddProduct}
                className="px-6 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors"
              >
                Add Your First Product
              </button>
              <button
                onClick={() => handleNavigateToAdvertising()} // NEW: Advertising button
                className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Learn About Advertising
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
            {products
              .filter(product => 
                searchQuery === '' ||
                product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                product.category.toLowerCase().includes(searchQuery.toLowerCase())
              )
              .map(product => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onEdit={() => handleNavigateToEditProduct(product.id)}
                  onDelete={() => handleDeleteProduct(product.id)}
                  onView={() => handleNavigateToViewProduct(product.id)}
                  onCustomizationRequest={() => handleAddCustomizationRequest(product.id)}
                  onAdvertise={() => handleNavigateToAdvertising(product.id)} // NEW: Added advertising handler
                />
              ))}
          </div>
        )}
      </div>
    </div>
  );

  const renderSection = () => {
    switch (activeSection) {
      case 'dashboard': return renderDashboard();
      case 'products': return renderProductsManagement();
      case 'analytics': return <SalesAnalytics data={{ dailySales: [], monthlyRevenue: [], topProducts: [] }} totalRevenue={stats.total_revenue} />;
      case 'payments': return (
        <PaymentRequests
          pendingPayout={stats.wallet_balance}
          onRequestPayment={handleRequestPayment}
          paymentRequests={paymentRequests}
        />
      );
      case 'customizations': return (
        <CustomizationRequests
          requests={customizationRequests}
          products={products}
          onUpdateStatus={handleUpdateCustomizationStatus}
        />
      );
      case 'returns': return (
        <ReturnRequests
          requests={returnRequests}
          onUpdateStatus={handleUpdateReturnStatus}
        />
      );
      default: return renderDashboard();
    }
  };

  if (loading && !seller) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 text-gray-400 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <h1 className="text-xl font-bold text-gray-900">Seller Dashboard</h1>
              
              <div className="hidden lg:flex items-center gap-1 bg-gray-100 p-1 rounded-lg">
                {navigationTabs.slice(0, 8).map(tab => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={tab.action}
                      className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        activeSection === tab.id
                          ? 'bg-white text-gray-900 shadow-sm'
                          : 'text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
                
                {/* More dropdown */}
                <div className="relative group">
                  <button className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-gray-600 hover:text-gray-900">
                    <MoreVertical className="w-4 h-4" />
                    More
                  </button>
                  <div className="absolute right-0 mt-1 w-48 bg-white border border-gray-200 rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                    {navigationTabs.slice(8).map(tab => {
                      const Icon = tab.icon;
                      return (
                        <button
                          key={tab.id}
                          onClick={tab.action}
                          className="w-full flex items-center gap-2 px-4 py-2 text-left text-sm hover:bg-gray-50"
                        >
                          <Icon className="w-4 h-4" />
                          {tab.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              {/* Language toggle */}
              <button
                onClick={toggleLanguage}
                className="flex items-center gap-2 px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200"
              >
                <Globe className="w-4 h-4" />
                <span className="text-sm font-medium">{language === 'en' ? 'EN' : 'AR'}</span>
              </button>
              
              {/* Notifications */}
              <button className="relative p-2 hover:bg-gray-100 rounded-lg">
                <Bell className="w-5 h-5 text-gray-600" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
              </button>
              
              {/* Seller profile */}
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-sm font-semibold text-gray-900">{seller?.business_name}</p>
                  <p className="text-xs text-gray-600">{formatCurrency(stats.wallet_balance)}</p>
                </div>
                <div className="w-8 h-8 bg-gray-200 rounded-full overflow-hidden">
                  {seller?.logo_url ? (
                    <img src={seller.logo_url} alt="Store logo" className="w-full h-full object-cover" />
                  ) : (
                    <Store className="w-5 h-5 text-gray-600 mx-auto mt-1.5" />
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {/* Mobile navigation */}
          <div className="lg:hidden mt-4 overflow-x-auto">
            <div className="flex gap-2 pb-2">
              {navigationTabs.slice(0, 6).map(tab => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={tab.action}
                    className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium ${
                      activeSection === tab.id
                        ? 'bg-gray-900 text-white'
                        : 'bg-gray-100 text-gray-700'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </header>
      
      {/* Main content */}
      <main className="p-6">
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        )}
        
        {success && (
          <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <p className="text-green-700">{success}</p>
            </div>
          </div>
        )}
        
        {renderSection()}
        
        {/* Quick access floating buttons */}
        <div className="fixed bottom-6 right-6 flex flex-col gap-3">
          <button
            onClick={() => simulateOrder('prod_001', 1)}
            className="w-14 h-14 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all flex items-center justify-center"
            title="Simulate Order"
          >
            <ShoppingCart className="w-6 h-6" />
          </button>
          <button
            onClick={handleNavigateToAddProduct}
            className="w-14 h-14 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all flex items-center justify-center"
            title="Add Product"
          >
            <Plus className="w-6 h-6" />
          </button>
          <button
            onClick={() => handleNavigateToAdvertising()} // NEW: Advertising floating button
            className="w-14 h-14 bg-gradient-to-r from-orange-600 to-red-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all flex items-center justify-center"
            title="Start Advertising"
          >
            <Megaphone className="w-6 h-6" />
          </button>
        </div>
      </main>
    </div>
  );
};

export default SellerDashboard;