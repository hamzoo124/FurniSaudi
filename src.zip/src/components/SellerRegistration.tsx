import { useState, useRef, useEffect } from "react";
import { 
  AiOutlineCheckCircle,
  AiOutlineArrowLeft,
  AiOutlineUpload,
  AiOutlineLoading
} from "react-icons/ai";
import { supabase } from "../lib/supabase";

interface SellerRegistrationProps {
  onBack?: () => void;
  onRegistrationComplete?: () => void;
  onNavigate?: (page: string) => void;
}

interface FormData {
  businessName: string;
  contactNumber: string;
  address: string;
  city: string;
  businessType: 'individual' | 'company';
  businessDescription: string;
  crNumber: string;
  crDocument: File | null;
  bankName: string;
  accountNumber: string;
  iban: string;
  fullName: string;
  email: string;
  password: string;
  confirmPassword: string;
}

const SellerRegistration: React.FC<SellerRegistrationProps> = ({ 
  onBack, 
  onRegistrationComplete,
  onNavigate
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [showSuccess, setShowSuccess] = useState<boolean>(false);
  const [submitError, setSubmitError] = useState<string>('');
  const [formData, setFormData] = useState<FormData>({
    businessName: '',
    contactNumber: '',
    address: '',
    city: '',
    businessType: 'individual',
    businessDescription: '',
    crNumber: '',
    crDocument: null,
    bankName: '',
    accountNumber: '',
    iban: '',
    fullName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const businessTypes = [
    { 
      value: 'individual', 
      label: 'Individual Seller', 
      description: 'Freelancer or small business owner',
      icon: '👤'
    },
    { 
      value: 'company', 
      label: 'Business Entity', 
      description: 'Registered company or organization',
      icon: '🏢'
    }
  ];

  const saudiCities = [
    'Riyadh', 'Jeddah', 'Mecca', 'Medina', 'Dammam', 'Khobar', 'Dhahran',
    'Taif', 'Tabuk', 'Abha', 'Jazan', 'Hail', 'Buraidah', 'Najran'
  ];

  const saudiBanks = [
    'Al Rajhi Bank',
    'Saudi National Bank (SNB)',
    'Riyad Bank',
    'Saudi British Bank (SABB)',
    'Arab National Bank (ANB)',
    'Alinma Bank',
    'Bank AlBilad',
    'Saudi Investment Bank (SAIB)',
    'Bank AlJazira',
    'Emirates NBD'
  ];

  // Enhanced input handler
  const handleInputChange = (field: keyof FormData, value: any) => {
    // Special handling for phone numbers
    if (field === 'contactNumber') {
      const cleaned = value.replace(/\D/g, '');
      let formatted = cleaned;
      if (cleaned.length > 3 && cleaned.length <= 6) {
        formatted = `${cleaned.slice(0, 3)} ${cleaned.slice(3)}`;
      } else if (cleaned.length > 6) {
        formatted = `${cleaned.slice(0, 3)} ${cleaned.slice(3, 6)} ${cleaned.slice(6, 10)}`;
      }
      value = formatted.trim();
    }
    
    // Special handling for IBAN
    if (field === 'iban') {
      value = value.toUpperCase().replace(/[^A-Z0-9]/g, '');
      if (value.length > 2) {
        value = `${value.slice(0, 2)} ${value.slice(2)}`;
      }
      if (value.length > 6) {
        value = `${value.slice(0, 6)} ${value.slice(6)}`;
      }
      if (value.length > 10) {
        value = `${value.slice(0, 10)} ${value.slice(10)}`;
      }
      if (value.length > 14) {
        value = `${value.slice(0, 14)} ${value.slice(14)}`;
      }
      if (value.length > 18) {
        value = `${value.slice(0, 18)} ${value.slice(18)}`;
      }
      if (value.length > 22) {
        value = `${value.slice(0, 22)} ${value.slice(22)}`;
      }
      value = value.trim();
    }

    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error for this field
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  // Enhanced file upload with better validation
  const handleFileUpload = (files: FileList | null) => {
    if (!files || !files[0]) return;

    const file = files[0];
    
    // File size validation (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      setErrors(prev => ({ 
        ...prev, 
        crDocument: 'File size exceeds 5MB limit' 
      }));
      return;
    }
    
    // File type validation
    const validTypes = [
      'image/jpeg', 
      'image/jpg', 
      'image/png', 
      'application/pdf',
      'image/webp'
    ];
    
    if (!validTypes.includes(file.type)) {
      setErrors(prev => ({ 
        ...prev, 
        crDocument: 'Only JPG, PNG, PDF, and WebP files are allowed' 
      }));
      return;
    }

    // Simulate upload progress
    setUploadProgress(0);
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + 20;
      });
    }, 100);

    // Complete upload after delay
    setTimeout(() => {
      clearInterval(interval);
      setUploadProgress(100);
      
      // Set the file
      handleInputChange('crDocument', file);
      
      // Clear any previous error
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors.crDocument;
        return newErrors;
      });
      
      // Reset progress after 1 second
      setTimeout(() => setUploadProgress(0), 1000);
    }, 600);
  };

  // Enhanced validation
  const validateCurrentStep = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (currentStep === 1) {
      if (!formData.fullName.trim()) newErrors.fullName = 'Full name is required';
      else if (formData.fullName.trim().length < 2) newErrors.fullName = 'Enter a valid name';
      
      if (!formData.email.trim()) newErrors.email = 'Email is required';
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
        newErrors.email = 'Enter a valid email address';
      }
      
      if (!formData.password) newErrors.password = 'Password is required';
      else if (formData.password.length < 6) newErrors.password = 'Password must be at least 6 characters';
      else if (!/(?=.*[A-Za-z])(?=.*\d)/.test(formData.password)) {
        newErrors.password = 'Password must contain letters and numbers';
      }
      
      if (!formData.confirmPassword) newErrors.confirmPassword = 'Please confirm your password';
      else if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = 'Passwords do not match';
      }
    }

    if (currentStep === 2) {
      if (!formData.businessName.trim()) newErrors.businessName = 'Business name is required';
      else if (formData.businessName.trim().length < 2) {
        newErrors.businessName = 'Enter a valid business name';
      }
      
      if (!formData.contactNumber.trim()) newErrors.contactNumber = 'Contact number is required';
      else if (!/^05\d{8}$/.test(formData.contactNumber.replace(/\D/g, ''))) {
        newErrors.contactNumber = 'Enter a valid Saudi mobile number (05XXXXXXXX)';
      }
      
      if (!formData.address.trim()) newErrors.address = 'Address is required';
      if (!formData.city.trim()) newErrors.city = 'City is required';
      
      if (!formData.businessDescription.trim()) {
        newErrors.businessDescription = 'Business description is required';
      } else if (formData.businessDescription.trim().length < 20) {
        newErrors.businessDescription = 'Description must be at least 20 characters';
      }
    }

    if (currentStep === 3) {
      if (!formData.crNumber.trim()) newErrors.crNumber = 'CR number is required';
      else if (!/^\d{10}$/.test(formData.crNumber)) {
        newErrors.crNumber = 'CR number must be 10 digits';
      }
    }

    if (currentStep === 4) {
      if (!formData.bankName.trim()) newErrors.bankName = 'Please select a bank';
      if (!formData.accountNumber.trim()) newErrors.accountNumber = 'Account number is required';
      else if (!/^\d{10,20}$/.test(formData.accountNumber)) {
        newErrors.accountNumber = 'Account number must be 10-20 digits';
      }
      
      const cleanIban = formData.iban.replace(/\s/g, '');
      if (!formData.iban.trim()) newErrors.iban = 'IBAN is required';
      else if (!/^SA\d{22}$/i.test(cleanIban)) {
        newErrors.iban = 'IBAN must start with SA followed by 22 digits';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateCurrentStep()) {
      setCurrentStep(prev => Math.min(prev + 1, 4));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // UPDATED SUBMIT FUNCTION - Now properly saves to database for admin panel
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');
    
    // First validate all steps
    const validationErrors: Record<string, string> = {};
    
    // Validate step 1
    if (!formData.fullName.trim()) validationErrors.fullName = 'Full name is required';
    if (!formData.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      validationErrors.email = 'Valid email required';
    }
    if (!formData.password || formData.password.length < 6) {
      validationErrors.password = 'Password must be at least 6 characters';
    }
    if (formData.password !== formData.confirmPassword) {
      validationErrors.confirmPassword = 'Passwords do not match';
    }
    
    // Validate step 2
    if (!formData.businessName.trim()) validationErrors.businessName = 'Business name required';
    if (!formData.contactNumber.trim() || !/^05\d{8}$/.test(formData.contactNumber.replace(/\D/g, ''))) {
      validationErrors.contactNumber = 'Valid Saudi mobile number required';
    }
    if (!formData.address.trim()) validationErrors.address = 'Address required';
    if (!formData.city.trim()) validationErrors.city = 'City required';
    if (!formData.businessDescription.trim() || formData.businessDescription.trim().length < 20) {
      validationErrors.businessDescription = 'Description must be at least 20 characters';
    }
    
    // Validate step 3
    if (!formData.crNumber.trim() || !/^\d{10}$/.test(formData.crNumber)) {
      validationErrors.crNumber = 'Valid 10-digit CR number required';
    }
    
    // Validate step 4
    if (!formData.bankName.trim()) validationErrors.bankName = 'Bank selection required';
    if (!formData.accountNumber.trim() || !/^\d{10,20}$/.test(formData.accountNumber)) {
      validationErrors.accountNumber = 'Valid account number required (10-20 digits)';
    }
    const cleanIban = formData.iban.replace(/\s/g, '');
    if (!formData.iban.trim() || !/^SA\d{22}$/i.test(cleanIban)) {
      validationErrors.iban = 'Valid Saudi IBAN required';
    }
    
    // If any validation errors, show them
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      
      // Navigate to step with first error
      const errorFields = Object.keys(validationErrors);
      const firstErrorField = errorFields[0];
      
      if (['fullName', 'email', 'password', 'confirmPassword'].includes(firstErrorField)) {
        setCurrentStep(1);
      } else if (['businessName', 'contactNumber', 'address', 'city', 'businessDescription'].includes(firstErrorField)) {
        setCurrentStep(2);
      } else if (firstErrorField === 'crNumber') {
        setCurrentStep(3);
      } else if (['bankName', 'accountNumber', 'iban'].includes(firstErrorField)) {
        setCurrentStep(4);
      }
      
      setSubmitError('Please fix all errors before submitting');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      console.log('Starting registration process...');
      
      // 1. Create Supabase Auth User
      console.log('Creating auth user...');
      const { data: authData, error: signUpError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            full_name: formData.fullName,
            user_type: 'seller',
            business_name: formData.businessName
          },
          emailRedirectTo: `${window.location.origin}/seller/verify`
        }
      });

      if (signUpError) {
        console.error('Auth error:', signUpError);
        throw signUpError;
      }

      if (!authData.user) {
        throw new Error('Failed to create user account');
      }

      const userId = authData.user.id;
      console.log('Auth user created with ID:', userId);

      // 2. Upload CR Document if provided
      let documentUrl = null;
      if (formData.crDocument) {
        console.log('Uploading CR document...');
        try {
          const fileExt = formData.crDocument.name.split('.').pop();
          const fileName = `${userId}_${Date.now()}.${fileExt}`;
          const filePath = `cr-documents/${fileName}`;

          const { error: uploadError } = await supabase.storage
            .from('seller-documents')
            .upload(filePath, formData.crDocument);

          if (uploadError) {
            console.warn('Document upload failed:', uploadError);
          } else {
            const { data: urlData } = supabase.storage
              .from('seller-documents')
              .getPublicUrl(filePath);
            documentUrl = urlData.publicUrl;
            console.log('Document uploaded:', documentUrl);
          }
        } catch (uploadErr) {
          console.warn('Document upload error (non-critical):', uploadErr);
        }
      }

      // 3. Create Seller Profile in Database
      console.log('Creating seller profile in database...');
      const sellerData = {
        user_id: userId,
        full_name: formData.fullName,
        email: formData.email,
        business_name: formData.businessName,
        contact_number: formData.contactNumber.replace(/\D/g, ''),
        address: formData.address,
        city: formData.city,
        business_type: formData.businessType,
        business_description: formData.businessDescription,
        cr_number: formData.crNumber,
        cr_document_url: documentUrl,
        bank_name: formData.bankName,
        account_number: formData.accountNumber,
        iban: cleanIban,
        
        // IMPORTANT: These fields are for admin panel
        approval_status: 'pending', // Admin will see this
        status: 'pending_review',   // Admin will see this
        is_active: false,
        
        // Tracking fields
        registration_date: new Date().toISOString(),
        last_updated: new Date().toISOString(),
        review_notes: null, // Admin can add notes here
        reviewed_by: null,  // Will be filled by admin
        reviewed_at: null   // Will be filled by admin
      };

      console.log('Inserting seller data:', sellerData);

      const { error: insertError } = await supabase
        .from('sellers')
        .insert([sellerData]);

      if (insertError) {
        console.error('Database insert error:', insertError);
        throw new Error(`Failed to create seller profile: ${insertError.message}`);
      }

      console.log('Seller profile created successfully!');
      
      // 4. Show Success Message
      setShowSuccess(true);
      
      // 5. Redirect after delay
      setTimeout(() => {
        if (onNavigate) {
          onNavigate('seller-pending');
        } else if (onRegistrationComplete) {
          onRegistrationComplete();
        } else if (onBack) {
          onBack();
        } else {
          window.location.href = '/seller/pending';
        }
      }, 3000);

    } catch (error: any) {
      console.error('Registration error:', error);
      
      let errorMessage = 'Registration failed. Please try again.';
      
      if (error.message?.includes('User already registered')) {
        errorMessage = 'This email is already registered. Please use a different email.';
      } else if (error.message?.includes('Email rate limit exceeded')) {
        errorMessage = 'Too many attempts. Please try again in a few minutes.';
      } else if (error.message?.includes('invalid email')) {
        errorMessage = 'Please enter a valid email address.';
      }
      
      setSubmitError(errorMessage);
      setIsSubmitting(false);
    }
  };

  const renderStepIndicator = () => (
    <div className="mb-8">
      <div className="relative">
        <div className="absolute top-1/2 left-0 right-0 h-1 bg-gray-200 transform -translate-y-1/2 -z-10">
          <div 
            className="h-1 bg-yellow-500 transition-all duration-300"
            style={{ width: `${((currentStep - 1) / 3) * 100}%` }}
          ></div>
        </div>
        <div className="flex justify-between">
          {[1, 2, 3, 4].map((step) => {
            const isActive = step === currentStep;
            const isCompleted = step < currentStep;
            
            return (
              <div key={step} className="flex flex-col items-center">
                <div className={`
                  w-10 h-10 rounded-full flex items-center justify-center
                  border-2 transition-all duration-300
                  ${isActive 
                    ? 'bg-yellow-500 border-yellow-500 text-white scale-110' 
                    : isCompleted 
                      ? 'bg-green-500 border-green-500 text-white'
                      : 'bg-white border-gray-300 text-gray-400'
                  }
                `}>
                  {isCompleted ? (
                    <AiOutlineCheckCircle size={16} />
                  ) : (
                    <span className="font-bold">{step}</span>
                  )}
                </div>
                <span className="mt-2 text-sm font-medium">
                  {step === 1 ? 'Account' : step === 2 ? 'Business' : step === 3 ? 'Documents' : 'Payment'}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Create Your Account</h2>
            <p className="text-gray-600">First, create your seller account</p>
            
            <div className="space-y-4">
              <div>
                <label className="block font-medium text-gray-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
                  placeholder="Your full name"
                  disabled={isSubmitting}
                />
                {errors.fullName && <p className="mt-1 text-sm text-red-600">{errors.fullName}</p>}
              </div>

              <div>
                <label className="block font-medium text-gray-700 mb-1">Email Address *</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
                  placeholder="you@example.com"
                  disabled={isSubmitting}
                />
                {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email}</p>}
              </div>

              <div>
                <label className="block font-medium text-gray-700 mb-1">Password *</label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
                  placeholder="At least 6 characters with letters and numbers"
                  disabled={isSubmitting}
                />
                {errors.password && <p className="mt-1 text-sm text-red-600">{errors.password}</p>}
              </div>

              <div>
                <label className="block font-medium text-gray-700 mb-1">Confirm Password *</label>
                <input
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
                  placeholder="Confirm your password"
                  disabled={isSubmitting}
                />
                {errors.confirmPassword && <p className="mt-1 text-sm text-red-600">{errors.confirmPassword}</p>}
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Business Information</h2>
            
            <div>
              <label className="block font-medium text-gray-700 mb-2">Business Type *</label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {businessTypes.map((type) => (
                  <label
                    key={type.value}
                    className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                      formData.businessType === type.value
                        ? 'border-yellow-500 bg-yellow-50'
                        : 'border-gray-300 hover:border-yellow-400'
                    }`}
                  >
                    <input
                      type="radio"
                      name="businessType"
                      value={type.value}
                      checked={formData.businessType === type.value}
                      onChange={(e) => handleInputChange('businessType', e.target.value)}
                      className="hidden"
                      disabled={isSubmitting}
                    />
                    <div className="flex items-center">
                      <span className="text-2xl mr-3">{type.icon}</span>
                      <div>
                        <div className="font-medium">{type.label}</div>
                        <div className="text-sm text-gray-500">{type.description}</div>
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-medium text-gray-700 mb-1">Business Name *</label>
                <input
                  type="text"
                  value={formData.businessName}
                  onChange={(e) => handleInputChange('businessName', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
                  placeholder="Your business name"
                  disabled={isSubmitting}
                />
                {errors.businessName && <p className="mt-1 text-sm text-red-600">{errors.businessName}</p>}
              </div>

              <div>
                <label className="block font-medium text-gray-700 mb-1">Contact Number *</label>
                <input
                  type="tel"
                  value={formData.contactNumber}
                  onChange={(e) => handleInputChange('contactNumber', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
                  placeholder="05X XXX XXXX"
                  maxLength={12}
                  disabled={isSubmitting}
                />
                {errors.contactNumber && <p className="mt-1 text-sm text-red-600">{errors.contactNumber}</p>}
                <p className="mt-1 text-xs text-gray-500">Format: 05XXXXXXXX</p>
              </div>

              <div>
                <label className="block font-medium text-gray-700 mb-1">City *</label>
                <select
                  value={formData.city}
                  onChange={(e) => handleInputChange('city', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
                  disabled={isSubmitting}
                >
                  <option value="">Select city</option>
                  {saudiCities.map(city => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
                {errors.city && <p className="mt-1 text-sm text-red-600">{errors.city}</p>}
              </div>

              <div>
                <label className="block font-medium text-gray-700 mb-1">Address *</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
                  placeholder="Business address"
                  disabled={isSubmitting}
                />
                {errors.address && <p className="mt-1 text-sm text-red-600">{errors.address}</p>}
              </div>
            </div>

            <div>
              <label className="block font-medium text-gray-700 mb-1">Business Description *</label>
              <textarea
                value={formData.businessDescription}
                onChange={(e) => handleInputChange('businessDescription', e.target.value)}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 resize-none"
                placeholder="Describe your business, products, and services..."
                maxLength={500}
                disabled={isSubmitting}
              />
              {errors.businessDescription && (
                <p className="mt-1 text-sm text-red-600">{errors.businessDescription}</p>
              )}
              <div className="mt-1 text-sm text-gray-500 flex justify-between">
                <span>At least 20 characters required</span>
                <span>{formData.businessDescription.length}/500</span>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Business Verification</h2>
            
            <div>
              <label className="block font-medium text-gray-700 mb-1">Commercial Registration (CR) Number *</label>
              <input
                type="text"
                value={formData.crNumber}
                onChange={(e) => handleInputChange('crNumber', e.target.value.replace(/\D/g, '').slice(0, 10))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
                placeholder="Enter 10-digit CR number"
                maxLength={10}
                disabled={isSubmitting}
              />
              {errors.crNumber && <p className="mt-1 text-sm text-red-600">{errors.crNumber}</p>}
              <p className="mt-1 text-xs text-gray-500">Must be exactly 10 digits</p>
            </div>

            <div>
              <label className="block font-medium text-gray-700 mb-1">CR Document (Optional)</label>
              <p className="text-sm text-gray-500 mb-3">
                Upload a scanned copy of your commercial registration document for faster verification
              </p>
              <div
                className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                  formData.crDocument
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-300 hover:border-blue-400 bg-gray-50'
                } ${isSubmitting ? 'opacity-50 cursor-not-allowed' : ''}`}
                onClick={() => !isSubmitting && fileInputRef.current?.click()}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  accept=".jpg,.jpeg,.png,.pdf,.webp"
                  onChange={(e) => handleFileUpload(e.target.files)}
                  disabled={isSubmitting}
                />
                
                {formData.crDocument ? (
                  <div>
                    <AiOutlineCheckCircle className="mx-auto text-green-500 text-3xl mb-2" />
                    <p className="font-medium text-green-600">Document Uploaded</p>
                    <p className="text-sm text-gray-600 truncate">{formData.crDocument.name}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {(formData.crDocument.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                    {uploadProgress > 0 && uploadProgress < 100 && (
                      <div className="mt-3">
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div
                            className="bg-blue-500 h-1.5 rounded-full transition-all"
                            style={{ width: `${uploadProgress}%` }}
                          ></div>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">{uploadProgress}% uploaded</p>
                      </div>
                    )}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleInputChange('crDocument', null);
                        setUploadProgress(0);
                      }}
                      className="mt-3 text-sm text-red-500 hover:text-red-700 px-3 py-1 rounded border border-red-200 hover:bg-red-50"
                      disabled={isSubmitting}
                    >
                      Remove File
                    </button>
                  </div>
                ) : (
                  <div>
                    <AiOutlineUpload className="mx-auto text-gray-400 text-3xl mb-2" />
                    <p className="font-medium text-gray-700">Upload CR Document</p>
                    <p className="text-sm text-gray-500">PDF, JPG, PNG up to 5MB</p>
                    <button
                      type="button"
                      className="mt-3 text-sm bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1 rounded"
                      disabled={isSubmitting}
                    >
                      Browse Files
                    </button>
                  </div>
                )}
              </div>
              {errors.crDocument && <p className="mt-1 text-sm text-red-600">{errors.crDocument}</p>}
              <p className="mt-2 text-xs text-gray-500">
                This document will be visible to administrators for verification purposes
              </p>
            </div>
          </div>
        );

      case 4:
        const cleanIban = formData.iban.replace(/\s/g, '');
        const isIbanValid = /^SA\d{22}$/i.test(cleanIban);
        const isAccountValid = /^\d{10,20}$/.test(formData.accountNumber);
        
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Bank Details</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block font-medium text-gray-700 mb-1">Bank Name *</label>
                <select
                  value={formData.bankName}
                  onChange={(e) => handleInputChange('bankName', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  disabled={isSubmitting}
                >
                  <option value="">Select bank</option>
                  {saudiBanks.map(bank => (
                    <option key={bank} value={bank}>{bank}</option>
                  ))}
                </select>
                {errors.bankName && <p className="mt-1 text-sm text-red-600">{errors.bankName}</p>}
              </div>

              <div>
                <label className="block font-medium text-gray-700 mb-1">Account Number *</label>
                <input
                  type="text"
                  value={formData.accountNumber}
                  onChange={(e) => handleInputChange('accountNumber', e.target.value.replace(/\D/g, '').slice(0, 20))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-mono"
                  placeholder="1234567890"
                  maxLength={20}
                  disabled={isSubmitting}
                />
                {errors.accountNumber && <p className="mt-1 text-sm text-red-600">{errors.accountNumber}</p>}
                <div className="mt-1 text-xs">
                  {formData.accountNumber && (
                    <span className={isAccountValid ? 'text-green-600' : 'text-red-600'}>
                      {isAccountValid ? '✓ Valid account number' : '⚠ Must be 10-20 digits'}
                    </span>
                  )}
                </div>
              </div>

              <div>
                <label className="block font-medium text-gray-700 mb-1">IBAN *</label>
                <input
                  type="text"
                  value={formData.iban}
                  onChange={(e) => handleInputChange('iban', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-mono"
                  placeholder="SA44 2000 0001 2345 6789 1234"
                  maxLength={28}
                  disabled={isSubmitting}
                />
                {errors.iban && <p className="mt-1 text-sm text-red-600">{errors.iban}</p>}
                <div className="mt-1 text-xs">
                  {formData.iban && (
                    <span className={isIbanValid ? 'text-green-600' : 'text-red-600'}>
                      {isIbanValid ? '✓ Valid Saudi IBAN' : '⚠ Must be SA followed by 22 digits'}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-medium text-gray-900 mb-3">Registration Summary</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Name:</span>
                  <span className="font-medium">{formData.fullName || 'Not set'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Email:</span>
                  <span className="font-medium">{formData.email || 'Not set'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Business:</span>
                  <span className="font-medium">{formData.businessName || 'Not set'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Type:</span>
                  <span className="font-medium capitalize">{formData.businessType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">CR Number:</span>
                  <span className="font-medium">{formData.crNumber || 'Not set'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Bank:</span>
                  <span className="font-medium">{formData.bankName || 'Not selected'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Account:</span>
                  <span className="font-medium">{formData.accountNumber || 'Not set'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">IBAN:</span>
                  <span className="font-medium">{formData.iban || 'Not set'}</span>
                </div>
              </div>
            </div>
            
            {Object.keys(errors).length > 0 && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600 text-sm font-medium">Please fix the following errors:</p>
                <ul className="mt-1 text-sm text-red-600 list-disc pl-5">
                  {Object.entries(errors).map(([field, message]) => (
                    <li key={field}>{message}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-green-50 to-emerald-100">
        <div className="max-w-md w-full text-center bg-white rounded-xl shadow-lg p-8">
          <div className="animate-bounce mb-6">
            <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto">
              <AiOutlineCheckCircle className="text-white text-4xl" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Registration Complete!</h1>
          <p className="text-gray-600 mb-6">
            Your seller account has been created successfully and is now <strong>pending admin approval</strong>.
            <br /><br />
            Your application will appear in the <strong>admin panel</strong> where it will be reviewed.
            <br /><br />
            We'll notify you via email once your account is approved (usually within 24-48 hours).
          </p>
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <p className="text-yellow-700 text-sm">
              <strong>Application ID:</strong> {formData.crNumber || 'Pending'}
              <br />
              <strong>Status:</strong> <span className="text-yellow-600">Awaiting Admin Review</span>
            </p>
          </div>
          <div className="mt-6 animate-pulse text-gray-500">
            <AiOutlineLoading className="animate-spin inline mr-2" />
            Redirecting to your dashboard...
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-2xl mx-auto px-4">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-900">Become a Seller</h1>
            {onBack && !isSubmitting && (
              <button
                onClick={onBack}
                className="flex items-center text-gray-600 hover:text-gray-800 text-sm"
                type="button"
                disabled={isSubmitting}
              >
                <AiOutlineArrowLeft className="mr-1" />
                Back
              </button>
            )}
          </div>
          
          <p className="text-gray-600">Complete all 4 steps to register as a seller</p>
        </div>

        {renderStepIndicator()}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm p-6">
            {renderStepContent()}

            {submitError && (
              <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600 text-sm font-medium">{submitError}</p>
                <p className="text-red-500 text-xs mt-1">
                  Please fix the errors above and try again
                </p>
              </div>
            )}

            <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
              <div>
                {currentStep > 1 && (
                  <button
                    type="button"
                    onClick={handlePrevious}
                    disabled={isSubmitting}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    ← Previous
                  </button>
                )}
              </div>

              <div>
                {currentStep < 4 ? (
                  <button
                    type="button"
                    onClick={handleNext}
                    className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={isSubmitting}
                  >
                    Next →
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-6 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                  >
                    {isSubmitting ? (
                      <>
                        <AiOutlineLoading className="animate-spin mr-2" />
                        Creating Account...
                      </>
                    ) : (
                      'Complete Registration'
                    )}
                  </button>
                )}
              </div>
            </div>
          </div>
        </form>

        <div className="mt-6 text-center text-sm text-gray-500">
          <p className="mb-2">Need help? Contact support: support@example.com</p>
          <p>Already have an account? <a href="/login" className="text-yellow-600 hover:underline">Log in here</a></p>
          <p className="mt-4 text-xs text-gray-400">
            By registering, you agree to our Terms of Service and Privacy Policy.
            Your data will be securely stored and only accessible to authorized administrators.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SellerRegistration;