import React, { useState, useEffect } from 'react';
import { X, ShoppingCart, Eye, Trash2 } from 'lucide-react';
import { supabase, Product } from '../lib/supabase';

interface ComparisonPanelProps {
  compareItems: string[];
  onRemoveItem: (productId: string) => void;
  onClearAll: () => void;
  onNavigate: (page: string) => void;
  onAddToCart: (productId: string) => void;
}

export const ComparisonPanel: React.FC<ComparisonPanelProps> = ({
  compareItems,
  onRemoveItem,
  onClearAll,
  onNavigate,
  onAddToCart
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (compareItems.length > 0) {
      fetchProducts();
    } else {
      setProducts([]);
      setLoading(false);
    }
  }, [compareItems]);

  const fetchProducts = async () => {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .in('id', compareItems);

    if (!error && data) {
      setProducts(data as Product[]);
    }
    setLoading(false);
  };

  if (compareItems.length === 0) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t-2 border-amber-500 shadow-2xl z-40 transform transition-transform">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <h3 className="font-bold text-lg">Compare Products ({compareItems.length}/4)</h3>
            {compareItems.length >= 2 && (
              <span className="text-sm text-green-600 bg-green-50 px-3 py-1 rounded-full">
                Ready to compare
              </span>
            )}
          </div>
          <button
            onClick={onClearAll}
            className="text-red-600 hover:text-red-700 font-medium text-sm flex items-center space-x-1"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear All</span>
          </button>
        </div>

        {loading ? (
          <div className="text-center py-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-500 mx-auto"></div>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {products.map((product) => (
              <div key={product.id} className="bg-gray-50 rounded-lg p-3 relative group">
                <button
                  onClick={() => onRemoveItem(product.id)}
                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-lg hover:bg-red-600 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>

                <img
                  src={product.images?.[0] || 'https://images.pexels.com/photos/1866149/pexels-photo-1866149.jpeg?auto=compress&cs=tinysrgb&w=200'}
                  alt={product.title}
                  className="w-full h-32 object-cover rounded-lg mb-2"
                />

                <h4 className="font-semibold text-sm mb-1 line-clamp-2">{product.title}</h4>
                <p className="text-amber-600 font-bold text-lg mb-2">{product.price} SR</p>

                <div className="space-y-1">
                  <button
                    onClick={() => onNavigate(`product-${product.id}`)}
                    className="w-full bg-amber-500 text-white py-2 rounded text-xs font-semibold hover:bg-amber-600 transition-colors flex items-center justify-center space-x-1"
                  >
                    <Eye className="w-3 h-3" />
                    <span>View</span>
                  </button>
                  <button
                    onClick={() => onAddToCart(product.id)}
                    className="w-full border border-amber-500 text-amber-500 py-2 rounded text-xs font-semibold hover:bg-amber-50 transition-colors flex items-center justify-center space-x-1"
                  >
                    <ShoppingCart className="w-3 h-3" />
                    <span>Add</span>
                  </button>
                </div>
              </div>
            ))}

            {compareItems.length < 4 && (
              <div className="bg-gray-100 rounded-lg p-3 flex items-center justify-center border-2 border-dashed border-gray-300">
                <p className="text-gray-500 text-sm text-center">
                  Add up to {4 - compareItems.length} more product{4 - compareItems.length !== 1 ? 's' : ''}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
