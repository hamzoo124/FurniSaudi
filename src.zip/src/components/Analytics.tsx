import React from 'react';

interface AnalyticsPageProps {
  onNavigate: (page: string) => void;
  onBack: () => void;
}

const AnalyticsPage: React.FC<AnalyticsPageProps> = ({ onNavigate, onBack }) => {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Analytics Dashboard</h1>
        <button 
          onClick={onBack}
          className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
        >
          Back to Dashboard
        </button>
      </div>
      <div className="bg-white p-6 rounded-lg shadow">
        <p>Analytics charts and data will be displayed here.</p>
      </div>
    </div>
  );
};

export default AnalyticsPage;