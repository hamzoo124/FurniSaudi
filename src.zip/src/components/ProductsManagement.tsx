// Create a new file: ProductsManagement.tsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ProductCard } from './SellerDashboard'; // Import the ProductCard component

const ProductsManagement: React.FC = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = () => {
    try {
      const storedProducts = localStorage.getItem('furnitureProducts');
      const currentSeller = JSON.parse(localStorage.getItem('currentSeller') || '{}');
      const sellerId = currentSeller.id || 'seller_demo_001';

      if (storedProducts) {
        const parsedProducts = JSON.parse(storedProducts);
        const sellerProducts = parsedProducts.filter((p: any) => 
          p.sellerId === sellerId || p.seller_id === sellerId
        );
        setProducts(sellerProducts);
      }
    } catch (error) {
      console.error('Error loading products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProduct = (productId: string) => {
    if (!window.confirm('Are you sure you want to delete this product?')) return;

    try {
      const storedProducts = localStorage.getItem('furnitureProducts');
      if (storedProducts) {
        const parsedProducts = JSON.parse(storedProducts);
        const updatedProducts = parsedProducts.filter((p: any) => p.id !== productId);
        localStorage.setItem('furnitureProducts', JSON.stringify(updatedProducts));
        loadProducts(); // Reload products
      }
    } catch (error) {
      console.error('Failed to delete product:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Products Management</h1>
            <p className="text-gray-600">Manage your product listings</p>
          </div>
          <button
            onClick={() => navigate('/seller/add-product')}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            Add New Product
          </button>
        </div>

        {/* Search and Filter */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="Search products..."
            className="w-full px-4 py-2 border border-gray-300 rounded-lg"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products
            .filter(product => 
              product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
              product.description?.toLowerCase().includes(searchQuery.toLowerCase())
            )
            .map(product => (
              <div key={product.id} className="bg-white rounded-lg shadow border p-4">
                <img 
                  src={product.images?.[0] || product.image} 
                  alt={product.name}
                  className="w-full h-48 object-cover rounded"
                />
                <h3 className="font-semibold mt-2">{product.name}</h3>
                <p className="text-gray-600 text-sm">{product.category}</p>
                <div className="flex justify-between items-center mt-2">
                  <span className="font-bold">SAR {product.price}</span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate(`/seller/edit-product/${product.id}`)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteProduct(product.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default ProductsManagement;