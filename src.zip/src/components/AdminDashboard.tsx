import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, Store, Package, ShoppingBag, DollarSign, TrendingUp, Check, X,
  Search, Eye, Ban, UserPlus, Bell, BarChart3, MessageSquare,
  Filter, Download, Upload, Settings, Shield, AlertTriangle, MessageCircle,
  PieChart, Calendar, Mail, FileText, Image, Tag, Megaphone, CreditCard,
  Archive, RefreshCw, MoreVertical, Edit, Trash2, Plus, Minus, Lock, Unlock,
  ChevronRight, ChevronDown, Home, Star, Grid3X3, Building2, TreePine,
  ArrowUp, ArrowDown, ShoppingCart, CreditCardIcon, Send, User, ShieldAlert,
  BarChart, MessageCircleWarning, Wallet, Receipt, ClipboardList, AlertCircle,
  FolderOpen, Layers, FileEdit, MessageCircleMore, Ticket, Palette,
  Globe, ShieldCheck, Truck, Percent, Languages,
  BookOpen, HelpCircle, FileCode, Database, Cpu, Zap, MessageSquareText,
  Smartphone, BarChart4, ShoppingBasket, FileSpreadsheet,
  UploadCloud, DownloadCloud, Grid, List,
  LayoutDashboard
} from 'lucide-react';

interface AdminDashboardProps {
  onNavigate?: (page: string) => void;
}

interface SellerType {
  id: string;
  user_id: string;
  business_name: string;
  email: string;
  contact_number: string;
  address: string;
  city: string;
  business_type: 'individual' | 'company';
  business_description: string;
  cr_number: string;
  cr_document_url: string | null;
  bank_name: string;
  account_number: string;
  iban: string;
  approval_status: 'pending' | 'approved' | 'rejected';
  status: 'active' | 'inactive' | 'pending_review' | 'rejected';
  is_active: boolean;
  suspended: boolean;
  blocked: boolean;
  wallet_balance: number;
  internal_notes: string | null;
  rejection_reason: string | null;
  approved_at: string | null;
  approved_by: string | null;
  created_at: string;
  updated_at: string;
  warning_count: number;
  last_warning_at: string | null;
  featured_seller: boolean;
  total_sales: number;
  total_products: number;
  total_revenue: number;
  avg_rating: number;
  kyc_status: 'pending' | 'verified' | 'rejected';
  kyc_documents: string[];
  store_rating: number;
  response_rate: number;
  completion_rate: number;
}

interface BuyerType {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  phone_number: string;
  avatar_url: string | null;
  is_active: boolean;
  is_banned: boolean;
  last_login: string | null;
  created_at: string;
  login_count: number;
  total_orders: number;
  total_spent: number;
  avg_order_value: number;
  favorite_categories: string[];
  shipping_addresses: any[];
  loyalty_points: number;
  membership_tier: 'basic' | 'premium' | 'vip';
}

interface ProductType {
  id: string;
  seller_id: string;
  seller_name: string;
  name: string;
  description: string;
  price: number;
  original_price: number;
  category: string;
  subcategory: string;
  images: string[];
  stock_quantity: number;
  status: 'active' | 'inactive' | 'pending_review' | 'rejected';
  approval_status: 'pending' | 'approved' | 'rejected';
  rejection_reason: string | null;
  tags: string[];
  specifications: {
    material: string;
    dimensions: { length: number; width: number; height: number; unit: string };
    color: string;
    warranty: string;
    brand: string;
    weight: number;
    custom_attributes: Record<string, any>;
  };
  created_at: string;
  updated_at: string;
  featured: boolean;
  trending: boolean;
  blocked: boolean;
  sales_count: number;
  view_count: number;
  rating: number;
  review_count: number;
  low_stock_alert: boolean;
  placement: 'indoor' | 'outdoor';
  variants: any[];
  shipping_info: any;
}

interface OrderType {
  id: string;
  order_number: string;
  buyer_id: string;
  buyer_name: string;
  buyer_email: string;
  seller_id: string;
  seller_name: string;
  items: Array<{
    product_id: string;
    product_name: string;
    quantity: number;
    price: number;
    image: string;
    customization: any;
  }>;
  total_amount: number;
  status: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
  payment_status: 'pending' | 'paid' | 'failed' | 'refunded';
  payment_method: 'card' | 'cod' | 'bank_transfer';
  shipping_address: {
    full_name: string;
    address: string;
    city: string;
    postal_code: string;
    phone: string;
  };
  tracking_number: string | null;
  estimated_delivery: string | null;
  created_at: string;
  updated_at: string;
  invoice_url: string | null;
  refund_amount: number | null;
  refund_reason: string | null;
}

interface CustomizationRequestType {
  id: string;
  buyer_id: string;
  buyer_name: string;
  buyer_email: string;
  seller_id: string | null;
  seller_name: string | null;
  category: string;
  description: string;
  budget_range: { min: number; max: number };
  timeline: string;
  reference_images: string[];
  status: 'pending' | 'assigned' | 'in_progress' | 'quote_provided' | 'approved' | 'completed' | 'cancelled';
  assigned_at: string | null;
  quote_amount: number | null;
  quote_details: string | null;
  created_at: string;
  updated_at: string;
  chat_messages: Array<{
    id: string;
    sender: 'buyer' | 'seller' | 'admin';
    message: string;
    timestamp: string;
    attachments: string[];
  }>;
}

interface AdCampaignType {
  id: string;
  seller_id: string;
  seller_name: string;
  name: string;
  platform: 'own-platform' | 'facebook' | 'instagram' | 'google' | 'twitter';
  budget: number;
  duration: number;
  target_audience: string[];
  furniture_type: 'customized' | 'ready-made' | 'both';
  ad_source: 'existing-listing' | 'new-listing';
  images: string[];
  status: 'draft' | 'pending_approval' | 'active' | 'paused' | 'completed' | 'rejected';
  start_date?: string;
  end_date?: string;
  impressions?: number;
  clicks?: number;
  conversions?: number;
  created_at: string;
  rejection_reason: string | null;
  pricing_tier: 'basic' | 'premium' | 'enterprise';
}

interface CategoryType {
  id: string;
  name: string;
  description: string;
  image_url: string | null;
  is_active: boolean;
  parent_id: string | null;
  sort_order: number;
  product_count: number;
  created_at: string;
  type: 'indoor' | 'outdoor' | 'general';
  sub_type: string;
  attributes: {
    materials: string[];
    colors: string[];
    brands: string[];
    dimensions: string[];
    custom_attributes: Array<{ name: string; type: 'text' | 'number' | 'select'; options: string[] }>;
  };
}

interface CMSPageType {
  id: string;
  title: string;
  slug: string;
  content: string;
  meta_title: string;
  meta_description: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  author: string;
}

interface SupportTicketType {
  id: string;
  user_id: string;
  user_name: string;
  user_type: 'buyer' | 'seller';
  subject: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  assigned_to: string | null;
  assigned_admin: string | null;
  category: 'technical' | 'billing' | 'product' | 'shipping' | 'general';
  created_at: string;
  updated_at: string;
  messages: Array<{
    id: string;
    sender: string;
    sender_type: 'user' | 'admin';
    message: string;
    timestamp: string;
    attachments: string[];
  }>;
}

interface NotificationType {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  target_audience: 'all' | 'sellers' | 'buyers' | 'specific';
  target_users: string[] | null;
  sent_at: string | null;
  created_by: string;
  created_at: string;
  delivery_method: 'push' | 'email' | 'sms' | 'all';
  is_sent: boolean;
}

interface SystemSettingsType {
  payment_gateways: {
    stripe: { enabled: boolean; publishable_key: string; secret_key: string };
    paypal: { enabled: boolean; client_id: string; client_secret: string };
    bank_transfer: { enabled: boolean; account_details: any };
  };
  shipping_providers: Array<{
    id: string;
    name: string;
    enabled: boolean;
    rates: any;
    tracking_url: string;
  }>;
  tax_settings: {
    enabled: boolean;
    rate: number;
    inclusive: boolean;
    countries: any[];
  };
  user_roles: Array<{
    id: string;
    name: string;
    permissions: string[];
    description: string;
  }>;
  language_settings: {
    default: 'en' | 'ar';
    available: Array<{ code: string; name: string; enabled: boolean }>;
  };
  commission_settings: {
    rate: number;
    minimum_payout: number;
    payout_schedule: 'weekly' | 'bi-weekly' | 'monthly';
    tax_rate: number;
  };
}

const SellerDetailModal: React.FC<{ 
  seller: SellerType; 
  onClose: () => void;
  onApprove: (sellerId: string) => Promise<void>;
  onReject: (seller: SellerType, reason: string) => Promise<void>;
  onSuspend: (sellerId: string, suspend: boolean) => Promise<void>;
  onAddNote: (sellerId: string, note: string) => Promise<void>;
  onIssueWarning: (sellerId: string, warning: string) => Promise<void>;
  onToggleFeatured: (sellerId: string, featured: boolean) => Promise<void>;
  onVerifyKYC: (sellerId: string, status: 'verified' | 'rejected') => Promise<void>;
  isProcessing: boolean;
}> = ({ 
  seller, 
  onClose, 
  onApprove, 
  onReject, 
  onSuspend, 
  onAddNote, 
  onIssueWarning, 
  onToggleFeatured,
  onVerifyKYC,
  isProcessing 
}) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [rejectionReason, setRejectionReason] = useState(seller.rejection_reason || '');

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-5xl mx-auto shadow-lg max-h-[85vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-200">
          <div>
            <h3 className="text-xl font-bold text-gray-900">Seller Details - {seller.business_name}</h3>
            <p className="text-gray-600 text-xs mt-0.5">Complete business and performance information</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        <div className="flex space-x-1 mb-6 bg-gray-50 p-1 rounded-lg">
          {['overview', 'documents', 'performance', 'products', 'payouts'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 px-3 rounded-md text-xs font-semibold transition-all duration-200 ${
                activeTab === tab
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3 text-sm">Business Information</h4>
                  <div className="space-y-2 text-xs">
                    <div>
                      <label className="text-xs font-medium text-gray-600">Business Name</label>
                      <p className="text-sm font-semibold text-gray-900">{seller.business_name}</p>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-600">Business Type</label>
                      <p className="text-gray-900 capitalize">{seller.business_type}</p>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-600">Contact Email</label>
                      <p className="text-gray-900">{seller.email}</p>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-600">Contact Number</label>
                      <p className="text-gray-900">{seller.contact_number}</p>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-600">City</label>
                      <p className="text-gray-900">{seller.city}</p>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-600">Address</label>
                      <p className="text-gray-900">{seller.address}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3 text-sm">Business Description</h4>
                  <p className="text-gray-700 bg-white p-3 rounded border border-gray-200 text-xs">
                    {seller.business_description}
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3 text-sm">Status & Verification</h4>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        seller.approval_status === 'approved' ? 'bg-green-100 text-green-800' :
                        seller.approval_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {seller.approval_status.toUpperCase()}
                      </span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        seller.status === 'active' ? 'bg-green-100 text-green-800' :
                        seller.status === 'pending_review' ? 'bg-yellow-100 text-yellow-800' :
                        seller.status === 'rejected' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        STATUS: {seller.status.toUpperCase()}
                      </span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        seller.kyc_status === 'verified' ? 'bg-green-100 text-green-800' :
                        seller.kyc_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        KYC: {seller.kyc_status.toUpperCase()}
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      {seller.suspended && (
                        <span className="px-2 py-1 bg-orange-100 text-orange-800 rounded-full text-xs font-medium">Suspended</span>
                      )}
                      {!seller.is_active && (
                        <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs font-medium">Inactive</span>
                      )}
                      {seller.featured_seller && (
                        <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs font-medium">Featured</span>
                      )}
                    </div>

                    <div className="space-y-1">
                      <p className="text-xs text-gray-600">
                        <span className="font-semibold">CR Number:</span> {seller.cr_number}
                      </p>
                      {seller.cr_document_url && (
                        <a 
                          href={seller.cr_document_url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 text-xs font-medium flex items-center space-x-1"
                        >
                          <FileText className="w-3 h-3" />
                          <span>View CR Document</span>
                        </a>
                      )}
                    </div>
                    
                    {seller.rejection_reason && (
                      <div className="bg-red-50 p-3 rounded border border-red-200">
                        <p className="text-xs font-semibold text-red-800 mb-0.5">Rejection Reason:</p>
                        <p className="text-xs text-red-700">{seller.rejection_reason}</p>
                      </div>
                    )}
                    
                    {seller.warning_count > 0 && (
                      <div className="bg-orange-50 p-3 rounded border border-orange-200">
                        <p className="text-xs font-semibold text-orange-800 mb-0.5">
                          Warnings: {seller.warning_count}
                        </p>
                        {seller.last_warning_at && (
                          <p className="text-xs text-orange-700">
                            Last warning: {new Date(seller.last_warning_at).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3 text-sm">Bank Information</h4>
                  <div className="space-y-2 text-xs">
                    <div>
                      <label className="text-xs font-medium text-gray-600">Bank Name</label>
                      <p className="text-gray-900">{seller.bank_name}</p>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-600">Account Number</label>
                      <p className="text-gray-900 font-mono">{seller.account_number}</p>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-600">IBAN</label>
                      <p className="text-gray-900 font-mono">{seller.iban}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3 text-sm">Performance Metrics</h4>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between items-center py-1 border-b border-gray-200">
                      <span className="text-gray-600">Store Rating</span>
                      <span className="font-semibold text-gray-900">{seller.store_rating}/5</span>
                    </div>
                    <div className="flex justify-between items-center py-1 border-b border-gray-200">
                      <span className="text-gray-600">Response Rate</span>
                      <span className="font-semibold text-gray-900">{seller.response_rate}%</span>
                    </div>
                    <div className="flex justify-between items-center py-1 border-b border-gray-200">
                      <span className="text-gray-600">Order Completion</span>
                      <span className="font-semibold text-gray-900">{seller.completion_rate}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'documents' && (
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-3 text-sm">KYC Documents</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {seller.kyc_documents && seller.kyc_documents.length > 0 ? (
                    seller.kyc_documents.map((doc, index) => (
                      <div key={index} className="border border-gray-200 rounded p-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium text-gray-900 text-xs">Document {index + 1}</span>
                          <a 
                            href={doc} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 text-xs"
                          >
                            View
                          </a>
                        </div>
                        <img 
                          src={doc} 
                          alt={`KYC Document ${index + 1}`}
                          className="w-full h-24 object-cover rounded border border-gray-200"
                        />
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 text-xs">No KYC documents uploaded</p>
                  )}
                </div>
                
                <div className="flex space-x-2 mt-3">
                  <button
                    onClick={() => onVerifyKYC(seller.id, 'verified')}
                    className="px-3 py-1.5 bg-green-500 text-white rounded-lg hover:bg-green-600 text-xs"
                  >
                    Verify KYC
                  </button>
                  <button
                    onClick={() => onVerifyKYC(seller.id, 'rejected')}
                    className="px-3 py-1.5 bg-red-500 text-white rounded-lg hover:bg-red-600 text-xs"
                  >
                    Reject KYC
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Rejection Reason Input */}
        {seller.approval_status === 'pending' && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <h4 className="font-semibold text-gray-900 mb-2 text-sm">Rejection Reason (Optional)</h4>
            <textarea
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Enter reason for rejection (this will be shown to the seller)"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
              rows={3}
            />
          </div>
        )}

        <div className="flex items-center justify-between pt-6 mt-6 border-t border-gray-200">
          <button
            onClick={onClose}
            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
          >
            Close
          </button>
          <div className="flex space-x-2 flex-wrap gap-1">
            <button
              onClick={() => {
                const note = prompt('Add internal note:');
                if (note) onAddNote(seller.id, note);
              }}
              className="px-4 py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 transition-all duration-200 font-semibold text-xs"
            >
              Add Note
            </button>
            
            <button
              onClick={() => {
                const warning = prompt('Enter warning message:');
                if (warning) onIssueWarning(seller.id, warning);
              }}
              className="px-4 py-2 border border-orange-600 text-orange-600 rounded-lg hover:bg-orange-50 transition-all duration-200 font-semibold text-xs"
            >
              Issue Warning
            </button>

            {seller.approval_status === 'pending' && (
              <>
                <button
                  onClick={() => onApprove(seller.id)}
                  disabled={isProcessing}
                  className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all duration-200 font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isProcessing ? 'Approving...' : 'Approve Seller'}
                </button>
                <button
                  onClick={() => onReject(seller, rejectionReason)}
                  disabled={isProcessing}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all duration-200 font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Reject Seller
                </button>
              </>
            )}
            
            {seller.approval_status === 'approved' && (
              <>
                <button
                  onClick={() => onSuspend(seller.id, !seller.suspended)}
                  className={`px-4 py-2 rounded-lg transition-all duration-200 font-semibold text-xs ${
                    seller.suspended 
                      ? 'bg-green-500 text-white hover:bg-green-600' 
                      : 'bg-orange-500 text-white hover:bg-orange-600'
                  }`}
                >
                  {seller.suspended ? 'Unsuspend Seller' : 'Suspend Seller'}
                </button>
                <button
                  onClick={() => onToggleFeatured(seller.id, !seller.featured_seller)}
                  className={`px-4 py-2 rounded-lg transition-all duration-200 font-semibold text-xs ${
                    seller.featured_seller
                      ? 'bg-gray-500 text-white hover:bg-gray-600'
                      : 'bg-purple-500 text-white hover:bg-purple-600'
                  }`}
                >
                  {seller.featured_seller ? 'Unfeature Seller' : 'Feature Seller'}
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const ProductDetailModal: React.FC<{ 
  product: ProductType; 
  onClose: () => void;
  onApprove: (productId: string) => Promise<void>;
  onReject: (product: ProductType, reason: string) => Promise<void>;
  onToggleFeatured: (productId: string, featured: boolean) => Promise<void>;
  onBlock: (productId: string, blocked: boolean) => Promise<void>;
  onEdit: (productId: string, updates: Partial<ProductType>) => Promise<void>;
  onDelete: (productId: string) => Promise<void>;
  isProcessing: boolean;
}> = ({ 
  product, 
  onClose, 
  onApprove, 
  onReject, 
  onToggleFeatured, 
  onBlock, 
  onEdit, 
  onDelete,
  isProcessing 
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedProduct, setEditedProduct] = useState(product);

  const handleSave = () => {
    onEdit(product.id, editedProduct);
    setIsEditing(false);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-3xl mx-auto shadow-lg max-h-[85vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-200">
          <div>
            <h3 className="text-xl font-bold text-gray-900">Product Details</h3>
            <p className="text-gray-600 text-xs mt-0.5">Complete information about the product</p>
          </div>
          <div className="flex items-center space-x-2">
            {!isEditing && (
              <button
                onClick={() => setIsEditing(true)}
                className="px-3 py-1.5 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 transition-all duration-200 font-semibold text-xs"
              >
                Edit
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-3 text-sm">Product Information</h4>
              <div className="space-y-2 text-xs">
                <div>
                  <label className="text-xs font-medium text-gray-600">Product Name</label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={editedProduct.name}
                      onChange={(e) => setEditedProduct(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
                    />
                  ) : (
                    <p className="text-sm font-semibold text-gray-900">{product.name}</p>
                  )}
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-600">Seller</label>
                  <p className="text-gray-900 text-xs">{product.seller_name}</p>
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-600">Price</label>
                  {isEditing ? (
                    <input
                      type="number"
                      value={editedProduct.price}
                      onChange={(e) => setEditedProduct(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
                    />
                  ) : (
                    <p className="text-lg font-bold text-green-600 text-sm">{product.price.toLocaleString()} SR</p>
                  )}
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-600">Category</label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={editedProduct.category}
                      onChange={(e) => setEditedProduct(prev => ({ ...prev, category: e.target.value }))}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
                    />
                  ) : (
                    <p className="text-gray-900 capitalize text-xs">{product.category}</p>
                  )}
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-600">Stock Quantity</label>
                  {isEditing ? (
                    <input
                      type="number"
                      value={editedProduct.stock_quantity}
                      onChange={(e) => setEditedProduct(prev => ({ ...prev, stock_quantity: parseInt(e.target.value) || 0 }))}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
                    />
                  ) : (
                    <p className="text-gray-900 text-xs">{product.stock_quantity}</p>
                  )}
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-3 text-sm">Product Description</h4>
              {isEditing ? (
                <textarea
                  value={editedProduct.description}
                  onChange={(e) => setEditedProduct(prev => ({ ...prev, description: e.target.value }))}
                  rows={3}
                  className="w-full px-2 py-1.5 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
                />
              ) : (
                <p className="text-gray-700 bg-white p-3 rounded border border-gray-200 text-xs">
                  {product.description}
                </p>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-3 text-sm">Status & Approval</h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    product.approval_status === 'approved' ? 'bg-green-100 text-green-800' :
                    product.approval_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {product.approval_status.toUpperCase()}
                  </span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    product.status === 'active' ? 'bg-green-100 text-green-800' :
                    product.status === 'inactive' ? 'bg-red-100 text-red-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {product.status.toUpperCase()}
                  </span>
                  {product.featured && (
                    <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs font-medium">
                      FEATURED
                    </span>
                  )}
                  {product.blocked && (
                    <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs font-medium">
                      BLOCKED
                    </span>
                  )}
                </div>
                {product.rejection_reason && (
                  <div className="bg-red-50 p-3 rounded border border-red-200">
                    <p className="text-xs font-semibold text-red-800 mb-0.5">Rejection Reason:</p>
                    <p className="text-xs text-red-700">{product.rejection_reason}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-3 text-sm">Product Images</h4>
              <div className="grid grid-cols-2 gap-3">
                {product.images && product.images.length > 0 ? (
                  product.images.map((image, index) => (
                    <img
                      key={index}
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-20 object-cover rounded border border-gray-200"
                    />
                  ))
                ) : (
                  <p className="text-gray-500 text-xs col-span-2">No images available</p>
                )}
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-3 text-sm">Product Analytics</h4>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center py-1 border-b border-gray-200">
                  <span className="text-gray-600">Sales Count</span>
                  <span className="font-semibold text-gray-900">{product.sales_count || 0}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-gray-200">
                  <span className="text-gray-600">View Count</span>
                  <span className="font-semibold text-gray-900">{product.view_count || 0}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-gray-200">
                  <span className="text-gray-600">Rating</span>
                  <span className="font-semibold text-gray-900">{product.rating || 0}/5</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-6 mt-6 border-t border-gray-200">
          <div className="flex space-x-2">
            {isEditing ? (
              <>
                <button
                  onClick={() => {
                    setIsEditing(false);
                    setEditedProduct(product);
                  }}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all duration-200 font-semibold text-xs"
                >
                  Save Changes
                </button>
              </>
            ) : (
              <button
                onClick={onClose}
                className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
              >
                Close
              </button>
            )}
          </div>
          
          <div className="flex space-x-2 flex-wrap gap-1">
            {product.approval_status === 'pending' && !isEditing && (
              <>
                <button
                  onClick={() => onApprove(product.id)}
                  disabled={isProcessing}
                  className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all duration-200 font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isProcessing ? 'Approving...' : 'Approve Product'}
                </button>
                <button
                  onClick={() => {
                    const reason = prompt('Enter rejection reason:');
                    if (reason) onReject(product, reason);
                  }}
                  disabled={isProcessing}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all duration-200 font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Reject Product
                </button>
              </>
            )}
            {product.approval_status === 'approved' && !isEditing && (
              <>
                <button
                  onClick={() => onToggleFeatured(product.id, !product.featured)}
                  className={`px-4 py-2 rounded-lg transition-all duration-200 font-semibold text-xs ${
                    product.featured 
                      ? 'bg-gray-500 text-white hover:bg-gray-600' 
                      : 'bg-purple-500 text-white hover:bg-purple-600'
                  }`}
                >
                  {product.featured ? 'Unfeature Product' : 'Feature Product'}
                </button>
                <button
                  onClick={() => onBlock(product.id, !product.blocked)}
                  className={`px-4 py-2 rounded-lg transition-all duration-200 font-semibold text-xs ${
                    product.blocked 
                      ? 'bg-green-500 text-white hover:bg-green-600' 
                      : 'bg-red-500 text-white hover:bg-red-600'
                  }`}
                >
                  {product.blocked ? 'Unblock Product' : 'Block Product'}
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('dashboard');
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [stats, setStats] = useState({
    totalSellers: 0,
    totalBuyers: 0,
    totalProducts: 0,
    pendingProducts: 0,
    totalOrders: 0,
    totalRevenue: 0,
    pendingApprovals: 0,
    pendingPayouts: 0,
    todayOrders: 0,
    monthlyRevenue: 0,
    activeDisputes: 0,
    pendingAds: 0,
    customizationRequests: 0,
    supportTickets: 0,
    lowStockAlerts: 0,
    approvedSellers: 0,
    approvedBuyers: 0,
    approvedProducts: 0
  });

  const [pendingSellers, setPendingSellers] = useState<SellerType[]>([]);
  const [allSellers, setAllSellers] = useState<SellerType[]>([]);
  const [allBuyers, setAllBuyers] = useState<BuyerType[]>([]);
  const [pendingProducts, setPendingProducts] = useState<ProductType[]>([]);
  const [allProducts, setAllProducts] = useState<ProductType[]>([]);
  const [allOrders, setAllOrders] = useState<OrderType[]>([]);
  const [customizationRequests, setCustomizationRequests] = useState<CustomizationRequestType[]>([]);
  const [adCampaigns, setAdCampaigns] = useState<AdCampaignType[]>([]);
  const [categories, setCategories] = useState<CategoryType[]>([]);
  const [cmsPages, setCmsPages] = useState<CMSPageType[]>([]);
  const [supportTickets, setSupportTickets] = useState<SupportTicketType[]>([]);
  const [notifications, setNotifications] = useState<NotificationType[]>([]);
  const [systemSettings, setSystemSettings] = useState<SystemSettingsType | null>(null);

  const [selectedSeller, setSelectedSeller] = useState<SellerType | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<ProductType | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<OrderType | null>(null);
  const [selectedCustomization, setSelectedCustomization] = useState<CustomizationRequestType | null>(null);
  const [selectedAd, setSelectedAd] = useState<AdCampaignType | null>(null);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicketType | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<CategoryType | null>(null);
  const [newCategory, setNewCategory] = useState({
    name: '',
    description: '',
    image_url: '',
    parent_id: '',
    sort_order: 0,
    type: 'general' as 'indoor' | 'outdoor' | 'general',
    sub_type: ''
  });

  const [showNotificationModal, setShowNotificationModal] = useState(false);
  const [newNotification, setNewNotification] = useState({
    title: '',
    message: '',
    type: 'info' as 'info' | 'warning' | 'success' | 'error',
    target_audience: 'all' as 'all' | 'sellers' | 'buyers' | 'specific',
    target_users: [] as string[],
    delivery_method: 'push' as 'push' | 'email' | 'sms' | 'all'
  });

  const [adminAlerts, setAdminAlerts] = useState<Array<{
    id: string;
    title: string;
    message: string;
    type: 'new_seller' | 'new_product' | 'new_order' | 'warning' | 'info';
    created_at: string;
    read: boolean;
  }>>([]);

  useEffect(() => {
    if (activeSection !== 'sellers' && activeSection !== 'products' && activeSection !== 'orders') {
      setSearchQuery('');
    }
  }, [activeSection]);

  useEffect(() => {
    fetchAdminData();
  }, []);

  const addAdminAlert = (alert: {
    title: string;
    message: string;
    type: 'new_seller' | 'new_product' | 'new_order' | 'warning' | 'info';
  }) => {
    const newAlert = {
      id: Date.now().toString(),
      ...alert,
      created_at: new Date().toISOString(),
      read: false
    };
    setAdminAlerts(prev => [newAlert, ...prev]);
  };

  const markAlertAsRead = (alertId: string) => {
    setAdminAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, read: true } : alert
    ));
  };

  const fetchAdminData = async () => {
    try {
      setLoading(true);
      
      // Mock data for demo purposes
      const mockSellers: SellerType[] = [
        {
          id: '1',
          user_id: 'user1',
          business_name: 'Furniture Masters',
          email: 'contact@furnituremasters.com',
          contact_number: '+1234567890',
          address: '123 Main St',
          city: 'Riyadh',
          business_type: 'company',
          business_description: 'Premium furniture manufacturer',
          cr_number: 'CR123456',
          cr_document_url: null,
          bank_name: 'Al Rajhi Bank',
          account_number: '1234567890',
          iban: 'SA1234567890123456789012',
          approval_status: 'approved',
          status: 'active',
          is_active: true,
          suspended: false,
          blocked: false,
          wallet_balance: 50000,
          internal_notes: null,
          rejection_reason: null,
          approved_at: new Date().toISOString(),
          approved_by: 'admin1',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          warning_count: 0,
          last_warning_at: null,
          featured_seller: true,
          total_sales: 150,
          total_products: 45,
          total_revenue: 250000,
          avg_rating: 4.5,
          kyc_status: 'verified',
          kyc_documents: [],
          store_rating: 4.7,
          response_rate: 95,
          completion_rate: 98
        },
        {
          id: '2',
          user_id: 'user2',
          business_name: 'Wood Crafts',
          email: 'info@woodcrafts.com',
          contact_number: '+0987654321',
          address: '456 Oak Ave',
          city: 'Jeddah',
          business_type: 'individual',
          business_description: 'Handcrafted wooden furniture',
          cr_number: 'CR789012',
          cr_document_url: null,
          bank_name: 'Saudi National Bank',
          account_number: '0987654321',
          iban: 'SA0987654321098765432109',
          approval_status: 'pending',
          status: 'pending_review',
          is_active: false,
          suspended: false,
          blocked: false,
          wallet_balance: 0,
          internal_notes: null,
          rejection_reason: null,
          approved_at: null,
          approved_by: null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          warning_count: 0,
          last_warning_at: null,
          featured_seller: false,
          total_sales: 0,
          total_products: 0,
          total_revenue: 0,
          avg_rating: 0,
          kyc_status: 'pending',
          kyc_documents: [],
          store_rating: 0,
          response_rate: 0,
          completion_rate: 0
        }
      ];

      const mockProducts: ProductType[] = [
        {
          id: '1',
          seller_id: '1',
          seller_name: 'Furniture Masters',
          name: 'Premium Leather Sofa',
          description: 'Luxury 3-seater leather sofa with wooden frame',
          price: 2500,
          original_price: 3000,
          category: 'Living Room',
          subcategory: 'Sofas',
          images: ['https://images.unsplash.com/photo-1540574163026-643ea20ade25?w=400'],
          stock_quantity: 15,
          status: 'active',
          approval_status: 'approved',
          rejection_reason: null,
          tags: ['leather', 'premium', 'comfort'],
          specifications: {
            material: 'Genuine Leather',
            dimensions: { length: 220, width: 95, height: 85, unit: 'cm' },
            color: 'Brown',
            warranty: '2 years',
            brand: 'Furniture Masters',
            weight: 75,
            custom_attributes: {}
          },
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          featured: true,
          trending: true,
          blocked: false,
          sales_count: 45,
          view_count: 320,
          rating: 4.8,
          review_count: 23,
          low_stock_alert: false,
          placement: 'indoor',
          variants: [],
          shipping_info: {}
        },
        {
          id: '2',
          seller_id: '2',
          seller_name: 'Wood Crafts',
          name: 'Oak Dining Table',
          description: 'Solid oak dining table with 6 chairs',
          price: 1800,
          original_price: 2200,
          category: 'Dining Room',
          subcategory: 'Dining Sets',
          images: ['https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?w-400'],
          stock_quantity: 8,
          status: 'pending_review',
          approval_status: 'pending',
          rejection_reason: null,
          tags: ['oak', 'dining', 'set'],
          specifications: {
            material: 'Solid Oak',
            dimensions: { length: 200, width: 100, height: 75, unit: 'cm' },
            color: 'Natural Wood',
            warranty: '1 year',
            brand: 'Wood Crafts',
            weight: 120,
            custom_attributes: {}
          },
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          featured: false,
          trending: false,
          blocked: false,
          sales_count: 0,
          view_count: 45,
          rating: 0,
          review_count: 0,
          low_stock_alert: false,
          placement: 'indoor',
          variants: [],
          shipping_info: {}
        }
      ];

      const mockOrders: OrderType[] = [
        {
          id: '1',
          order_number: 'ORD-001',
          buyer_id: 'buyer1',
          buyer_name: 'John Doe',
          buyer_email: 'john@example.com',
          seller_id: '1',
          seller_name: 'Furniture Masters',
          items: [
            {
              product_id: '1',
              product_name: 'Premium Leather Sofa',
              quantity: 1,
              price: 2500,
              image: 'https://images.unsplash.com/photo-1540574163026-643ea20ade25?w=400',
              customization: {}
            }
          ],
          total_amount: 2500,
          status: 'delivered',
          payment_status: 'paid',
          payment_method: 'card',
          shipping_address: {
            full_name: 'John Doe',
            address: '789 Pine St',
            city: 'Riyadh',
            postal_code: '12345',
            phone: '+966500000001'
          },
          tracking_number: 'TRK123456',
          estimated_delivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          invoice_url: null,
          refund_amount: null,
          refund_reason: null
        }
      ];

      const mockCategories: CategoryType[] = [
        {
          id: '1',
          name: 'Living Room',
          description: 'Furniture for living room spaces',
          image_url: null,
          is_active: true,
          parent_id: null,
          sort_order: 1,
          product_count: 25,
          created_at: new Date().toISOString(),
          type: 'indoor',
          sub_type: '',
          attributes: {
            materials: ['Wood', 'Leather', 'Fabric'],
            colors: ['Brown', 'Black', 'White', 'Gray'],
            brands: ['Brand A', 'Brand B'],
            dimensions: ['Small', 'Medium', 'Large'],
            custom_attributes: []
          }
        },
        {
          id: '2',
          name: 'Bedroom',
          description: 'Bedroom furniture and accessories',
          image_url: null,
          is_active: true,
          parent_id: null,
          sort_order: 2,
          product_count: 18,
          created_at: new Date().toISOString(),
          type: 'indoor',
          sub_type: '',
          attributes: {
            materials: ['Wood', 'Metal', 'Fabric'],
            colors: ['White', 'Brown', 'Gray'],
            brands: ['Brand C', 'Brand D'],
            dimensions: ['Single', 'Double', 'King'],
            custom_attributes: []
          }
        }
      ];

      const mockNotifications: NotificationType[] = [
        {
          id: '1',
          title: 'New Seller Registered',
          message: 'Wood Crafts has registered as a new seller',
          type: 'info',
          target_audience: 'all',
          target_users: null,
          sent_at: new Date().toISOString(),
          created_by: 'system',
          created_at: new Date().toISOString(),
          delivery_method: 'push',
          is_sent: true
        }
      ];

      setPendingSellers(mockSellers.filter(s => s.approval_status === 'pending'));
      setAllSellers(mockSellers);
      setAllBuyers([]);
      setPendingProducts(mockProducts.filter(p => p.approval_status === 'pending'));
      setAllProducts(mockProducts);
      setAllOrders(mockOrders);
      setCustomizationRequests([]);
      setAdCampaigns([]);
      setCategories(mockCategories);
      setCmsPages([]);
      setSupportTickets([]);
      setNotifications(mockNotifications);

      setStats({
        totalSellers: mockSellers.length,
        totalBuyers: 0,
        totalProducts: mockProducts.length,
        pendingProducts: mockProducts.filter(p => p.approval_status === 'pending').length,
        totalOrders: mockOrders.length,
        totalRevenue: 2500,
        pendingApprovals: mockSellers.filter(s => s.approval_status === 'pending').length,
        pendingPayouts: 0,
        todayOrders: 1,
        monthlyRevenue: 2500,
        activeDisputes: 0,
        pendingAds: 0,
        customizationRequests: 0,
        supportTickets: 0,
        lowStockAlerts: 0,
        approvedSellers: mockSellers.filter(s => s.approval_status === 'approved').length,
        approvedBuyers: 0,
        approvedProducts: mockProducts.filter(p => p.approval_status === 'approved').length
      });

    } catch (error) {
      console.error('Error fetching admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const approveSeller = async (sellerId: string) => {
    try {
      setIsProcessing(true);
      
      setPendingSellers(prev => prev.filter(s => s.id !== sellerId));
      setAllSellers(prev => prev.map(s => 
        s.id === sellerId ? { 
          ...s, 
          approval_status: 'approved', 
          status: 'active',
          is_active: true,
          approved_at: new Date().toISOString(),
          approved_by: 'admin'
        } : s
      ));

      setStats(prev => ({
        ...prev,
        approvedSellers: prev.approvedSellers + 1,
        pendingApprovals: prev.pendingApprovals - 1
      }));

      alert('Seller approved successfully!');
      setSelectedSeller(null);
    } catch (error) {
      console.error('Error approving seller:', error);
      alert('Error approving seller');
    } finally {
      setIsProcessing(false);
    }
  };

  const rejectSeller = async (seller: SellerType, reason: string) => {
    try {
      setIsProcessing(true);
      
      setPendingSellers(prev => prev.filter(s => s.id !== seller.id));
      setAllSellers(prev => prev.map(s => s.id === seller.id ? {
        ...s,
        approval_status: 'rejected',
        status: 'rejected',
        is_active: false,
        rejection_reason: reason
      } : s));

      setStats(prev => ({
        ...prev,
        pendingApprovals: prev.pendingApprovals - 1
      }));

      alert('Seller rejected successfully!');
      setSelectedSeller(null);
    } catch (error) {
      console.error('Error rejecting seller:', error);
      alert('Error rejecting seller');
    } finally {
      setIsProcessing(false);
    }
  };

  const verifyKYC = async (sellerId: string, status: 'verified' | 'rejected') => {
    try {
      setAllSellers(prev => prev.map(s => 
        s.id === sellerId ? { ...s, kyc_status: status } : s
      ));

      alert(`KYC ${status} successfully!`);
    } catch (error) {
      console.error('Error updating KYC status:', error);
      alert('Error updating KYC status');
    }
  };

  const approveProduct = async (productId: string) => {
    try {
      setIsProcessing(true);
      
      setPendingProducts(prev => prev.filter(p => p.id !== productId));
      setAllProducts(prev => prev.map(p => p.id === productId ? {
        ...p,
        approval_status: 'approved',
        status: 'active'
      } : p));

      setStats(prev => ({
        ...prev,
        approvedProducts: prev.approvedProducts + 1,
        pendingProducts: prev.pendingProducts - 1
      }));

      alert('Product approved successfully!');
    } catch (error) {
      console.error('Error approving product:', error);
      alert('Error approving product');
    } finally {
      setIsProcessing(false);
    }
  };

  const rejectProduct = async (product: ProductType, reason: string) => {
    try {
      setIsProcessing(true);
      
      setPendingProducts(prev => prev.filter(p => p.id !== product.id));
      setAllProducts(prev => prev.map(p => p.id === product.id ? {
        ...p,
        approval_status: 'rejected',
        status: 'inactive',
        rejection_reason: reason
      } : p));

      setStats(prev => ({
        ...prev,
        pendingProducts: prev.pendingProducts - 1
      }));

      alert('Product rejected successfully!');
    } catch (error) {
      console.error('Error rejecting product:', error);
      alert('Error rejecting product');
    } finally {
      setIsProcessing(false);
    }
  };

  const toggleProductFeatured = async (productId: string, featured: boolean) => {
    try {
      setAllProducts(prev => prev.map(p => p.id === productId ? {
        ...p,
        featured: featured
      } : p));

      alert(`Product ${featured ? 'featured' : 'unfeatured'} successfully!`);
    } catch (error) {
      console.error('Error updating product featured status:', error);
      alert('Error updating product status');
    }
  };

  const blockProduct = async (productId: string, blocked: boolean) => {
    try {
      setAllProducts(prev => prev.map(p => p.id === productId ? {
        ...p,
        blocked: blocked,
        status: blocked ? 'inactive' : 'active'
      } : p));

      alert(`Product ${blocked ? 'blocked' : 'unblocked'} successfully!`);
    } catch (error) {
      console.error('Error blocking product:', error);
      alert('Error blocking product');
    }
  };

  const editProduct = async (productId: string, updates: Partial<ProductType>) => {
    try {
      setAllProducts(prev => prev.map(p => p.id === productId ? {
        ...p,
        ...updates
      } : p));

      alert('Product updated successfully!');
    } catch (error) {
      console.error('Error updating product:', error);
      alert('Error updating product');
    }
  };

  const saveCategory = async () => {
    try {
      if (!newCategory.name.trim()) {
        alert('Please provide a category name');
        return;
      }

      if (editingCategory) {
        setCategories(prev => prev.map(c => c.id === editingCategory.id ? {
          ...c,
          ...newCategory
        } : c));

        alert('Category updated successfully!');
      } else {
        const newCat: CategoryType = {
          id: Date.now().toString(),
          ...newCategory,
          is_active: true,
          product_count: 0,
          created_at: new Date().toISOString(),
          attributes: {
            materials: [],
            colors: [],
            brands: [],
            dimensions: [],
            custom_attributes: []
          }
        };
        setCategories(prev => [...prev, newCat]);
        alert('Category created successfully!');
      }

      setShowCategoryModal(false);
      setEditingCategory(null);
      setNewCategory({
        name: '',
        description: '',
        image_url: '',
        parent_id: '',
        sort_order: 0,
        type: 'general',
        sub_type: ''
      });

    } catch (error) {
      console.error('Error saving category:', error);
      alert('Error saving category');
    }
  };

  const toggleCategoryStatus = async (categoryId: string, active: boolean) => {
    try {
      setCategories(prev => prev.map(c => c.id === categoryId ? {
        ...c,
        is_active: active
      } : c));

      alert(`Category ${active ? 'activated' : 'deactivated'} successfully!`);
    } catch (error) {
      console.error('Error updating category status:', error);
      alert('Error updating category status');
    }
  };

  const sendNotification = async (notificationData: any) => {
    try {
      if (!notificationData.title.trim() || !notificationData.message.trim()) {
        alert('Please provide both title and message');
        return;
      }

      const newNotif: NotificationType = {
        id: Date.now().toString(),
        title: notificationData.title,
        message: notificationData.message,
        type: notificationData.type,
        target_audience: notificationData.target_audience,
        target_users: notificationData.target_users,
        delivery_method: notificationData.delivery_method,
        sent_at: new Date().toISOString(),
        created_by: 'admin',
        created_at: new Date().toISOString(),
        is_sent: true
      };

      setNotifications(prev => [newNotif, ...prev]);

      setShowNotificationModal(false);
      setNewNotification({
        title: '',
        message: '',
        type: 'info',
        target_audience: 'all',
        target_users: [],
        delivery_method: 'push'
      });

      alert('Notification sent successfully!');

    } catch (error) {
      console.error('Error sending notification:', error);
      alert('Error sending notification');
    }
  };

  const renderDashboard = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {[
          { 
            label: 'Total Sellers', 
            value: stats.totalSellers, 
            icon: Store, 
            color: 'blue',
            subtitle: `${stats.approvedSellers} approved`,
            action: () => {
              setActiveSection('sellers');
              setSearchQuery('');
            }
          },
          { 
            label: 'Total Buyers', 
            value: stats.totalBuyers, 
            icon: Users, 
            color: 'green',
            subtitle: `${stats.approvedBuyers} active`,
            action: () => {
              setActiveSection('buyers');
              setSearchQuery('');
            }
          },
          { 
            label: 'Total Products', 
            value: stats.totalProducts, 
            icon: Package, 
            color: 'purple',
            subtitle: `${stats.approvedProducts} approved`,
            action: () => {
              setActiveSection('products');
              setSearchQuery('');
            }
          },
          { 
            label: 'Total Orders', 
            value: stats.totalOrders, 
            icon: ShoppingBag, 
            color: 'orange',
            subtitle: `${stats.todayOrders} today`,
            action: () => {
              setActiveSection('orders');
              setSearchQuery('');
            }
          },
          { 
            label: 'Pending Approvals', 
            value: stats.pendingApprovals, 
            icon: UserPlus, 
            color: 'red',
            subtitle: `${stats.pendingProducts} products`,
            action: () => {
              setActiveSection('sellers');
              setSearchQuery('pending');
            }
          },
        ].map((stat, index) => {
          const Icon = stat.icon;
          
          return (
            <button
              key={index}
              onClick={stat.action}
              className="bg-white rounded-lg p-4 border border-gray-200 shadow-sm hover:shadow transition-all duration-200 text-left w-full transform hover:-translate-y-0.5 active:scale-95 cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`p-2 rounded-lg ${stat.color === 'blue' ? 'bg-blue-50 group-hover:bg-blue-100' : stat.color === 'green' ? 'bg-green-50 group-hover:bg-green-100' : stat.color === 'purple' ? 'bg-purple-50 group-hover:bg-purple-100' : stat.color === 'orange' ? 'bg-orange-50 group-hover:bg-orange-100' : 'bg-red-50 group-hover:bg-red-100'}`}>
                  <Icon className={`w-5 h-5 ${stat.color === 'blue' ? 'text-blue-600 group-hover:text-blue-700' : stat.color === 'green' ? 'text-green-600 group-hover:text-green-700' : stat.color === 'purple' ? 'text-purple-600 group-hover:text-purple-700' : stat.color === 'orange' ? 'text-orange-600 group-hover:text-orange-700' : 'text-red-600 group-hover:text-red-700'}`} />
                </div>
                {stat.value > 0 && (
                  <span className={`text-xs font-semibold px-1.5 py-0.5 rounded-full ${stat.color === 'blue' ? 'bg-blue-100 text-blue-800 group-hover:bg-blue-200' : stat.color === 'green' ? 'bg-green-100 text-green-800 group-hover:bg-green-200' : stat.color === 'purple' ? 'bg-purple-100 text-purple-800 group-hover:bg-purple-200' : stat.color === 'orange' ? 'bg-orange-100 text-orange-800 group-hover:bg-orange-200' : 'bg-red-100 text-red-800 group-hover:bg-red-200'}`}>
                    {stat.label === 'Pending Approvals' && stat.value > 0 ? 'NEEDS ATTENTION' : 'LIVE'}
                  </span>
                )}
              </div>
              <p className="text-2xl font-bold text-gray-900 mb-0.5 group-hover:text-gray-950 transition-colors duration-200">
                {stat.value}
              </p>
              <p className="text-xs font-semibold text-gray-900 group-hover:text-gray-950 transition-colors duration-200">
                {stat.label}
              </p>
              <p className="text-xs text-gray-600 mt-0.5 group-hover:text-gray-700 transition-colors duration-200">
                {stat.subtitle}
              </p>
              <div className="mt-2 flex items-center text-xs text-blue-600 opacity-0 group-hover:opacity-100 transition-all duration-200">
                <span>Click to view details</span>
                <ChevronRight className="w-3 h-3 ml-0.5" />
              </div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { 
            label: 'Total Revenue', 
            value: `$${stats.totalRevenue.toLocaleString()}`, 
            icon: DollarSign, 
            color: 'green',
            subtitle: `${stats.monthlyRevenue.toLocaleString()} this month`,
            action: () => {
              setActiveSection('orders');
              setSearchQuery('paid');
            }
          },
          { 
            label: 'Open Tickets', 
            value: stats.supportTickets, 
            icon: Ticket, 
            color: 'red',
            subtitle: `${stats.activeDisputes} high priority`,
            action: async () => {
              alert(`Open Support Tickets: ${stats.supportTickets}\n\nHigh Priority: ${stats.activeDisputes}`);
            }
          },
          { 
            label: 'Custom Requests', 
            value: stats.customizationRequests, 
            icon: Palette, 
            color: 'purple',
            subtitle: 'Pending assignments',
            action: async () => {
              alert(`Pending Customization Requests: ${stats.customizationRequests}`);
            }
          },
          { 
            label: 'Low Stock', 
            value: stats.lowStockAlerts, 
            icon: AlertTriangle, 
            color: 'orange',
            subtitle: 'Products need restock',
            action: async () => {
              alert(`Low Stock Products: ${stats.lowStockAlerts}`);
            }
          },
        ].map((stat, index) => {
          const Icon = stat.icon;
          const numericValue = typeof stat.value === 'string' ? parseInt(stat.value.replace(/[$,]/g, '')) : stat.value;
          
          return (
            <button
              key={index}
              onClick={stat.action}
              className="bg-white rounded-lg p-4 border border-gray-200 shadow-sm hover:shadow transition-all duration-200 text-left w-full transform hover:-translate-y-0.5 active:scale-95 cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`p-2 rounded-lg ${stat.color === 'blue' ? 'bg-blue-50 group-hover:bg-blue-100' : stat.color === 'green' ? 'bg-green-50 group-hover:bg-green-100' : stat.color === 'purple' ? 'bg-purple-50 group-hover:bg-purple-100' : stat.color === 'orange' ? 'bg-orange-50 group-hover:bg-orange-100' : 'bg-red-50 group-hover:bg-red-100'}`}>
                  <Icon className={`w-5 h-5 ${stat.color === 'blue' ? 'text-blue-600 group-hover:text-blue-700' : stat.color === 'green' ? 'text-green-600 group-hover:text-green-700' : stat.color === 'purple' ? 'text-purple-600 group-hover:text-purple-700' : stat.color === 'orange' ? 'text-orange-600 group-hover:text-orange-700' : 'text-red-600 group-hover:text-red-700'}`} />
                </div>
                {numericValue > 0 && numericValue !== 0 && (
                  <span className={`text-xs font-semibold px-1.5 py-0.5 rounded-full ${stat.color === 'blue' ? 'bg-blue-100 text-blue-800 group-hover:bg-blue-200' : stat.color === 'green' ? 'bg-green-100 text-green-800 group-hover:bg-green-200' : stat.color === 'purple' ? 'bg-purple-100 text-purple-800 group-hover:bg-purple-200' : stat.color === 'orange' ? 'bg-orange-100 text-orange-800 group-hover:bg-orange-200' : 'bg-red-100 text-red-800 group-hover:bg-red-200'}`}>
                    {stat.label === 'Low Stock' && numericValue > 0 ? 'ATTENTION' : 'VIEW'}
                  </span>
                )}
              </div>
              <p className="text-xl font-bold text-gray-900 mb-0.5 group-hover:text-gray-950 transition-colors duration-200">
                {stat.value}
              </p>
              <p className="text-xs font-semibold text-gray-900 group-hover:text-gray-950 transition-colors duration-200">
                {stat.label}
              </p>
              <p className="text-xs text-gray-600 mt-0.5 group-hover:text-gray-700 transition-colors duration-200">
                {stat.subtitle}
              </p>
              <div className="mt-2 flex items-center text-xs text-blue-600 opacity-0 group-hover:opacity-100 transition-all duration-200">
                <span>Click to view details</span>
                <ChevronRight className="w-3 h-3 ml-0.5" />
              </div>
            </button>
          );
        })}
      </div>

      {adminAlerts.length > 0 && (
        <div className="bg-white rounded-lg p-4 border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Recent Activity Alerts</h3>
            <button 
              onClick={() => setAdminAlerts([])}
              className="text-xs text-gray-500 hover:text-gray-700"
            >
              Clear All
            </button>
          </div>
          <div className="space-y-2">
            {adminAlerts.slice(0, 5).map((alert) => (
              <div 
                key={alert.id} 
                className={`flex items-center space-x-3 p-3 rounded-lg border ${
                  alert.read 
                    ? 'bg-gray-50 border-gray-200' 
                    : 'bg-blue-50 border-blue-200'
                }`}
              >
                <div className={`p-1.5 rounded-md ${
                  alert.type === 'new_seller' ? 'bg-green-100' :
                  alert.type === 'new_product' ? 'bg-purple-100' :
                  alert.type === 'new_order' ? 'bg-blue-100' :
                  'bg-yellow-100'
                }`}>
                  {alert.type === 'new_seller' && <UserPlus className="w-4 h-4 text-green-600" />}
                  {alert.type === 'new_product' && <Package className="w-4 h-4 text-purple-600" />}
                  {alert.type === 'new_order' && <ShoppingBag className="w-4 h-4 text-blue-600" />}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <p className={`font-medium text-xs ${alert.read ? 'text-gray-700' : 'text-gray-900'}`}>
                      {alert.title}
                    </p>
                    <span className="text-xs text-gray-500">
                      {new Date(alert.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 mt-0.5">{alert.message}</p>
                </div>
                {!alert.read && (
                  <button
                    onClick={() => markAlertAsRead(alert.id)}
                    className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                  >
                    Mark as read
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg p-4 border border-gray-200 shadow-sm">
          <h3 className="text-base font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { 
                label: 'Review Seller Applications', 
                icon: UserPlus, 
                section: 'sellers', 
                badge: stats.pendingApprovals, 
                color: 'blue',
                description: 'Approve new sellers'
              },
              { 
                label: 'Approve Products', 
                icon: Package, 
                section: 'products', 
                badge: stats.pendingProducts, 
                color: 'orange',
                description: 'Review new products'
              },
              { 
                label: 'Manage Categories', 
                icon: Grid3X3, 
                section: 'categories', 
                badge: null, 
                color: 'green',
                description: 'Add/edit categories'
              },
              { 
                label: 'View All Orders', 
                icon: ShoppingBag, 
                section: 'orders', 
                badge: stats.totalOrders, 
                color: 'purple',
                description: 'Track orders'
              },
            ].map((action, index) => {
              const Icon = action.icon;
              
              return (
                <button 
                  key={index}
                  onClick={() => setActiveSection(action.section)}
                  className="p-3 border border-gray-200 rounded-lg hover:border-gray-300 hover:bg-gray-50 transition-all duration-200 text-left group"
                >
                  <div className="flex items-center space-x-2">
                    <div className={`p-1.5 rounded-md ${action.color === 'blue' ? 'bg-blue-50' : action.color === 'green' ? 'bg-green-50' : action.color === 'purple' ? 'bg-purple-50' : 'bg-orange-50'} group-hover:scale-105 transition-transform duration-200`}>
                      <Icon className={`w-4 h-4 ${action.color === 'blue' ? 'text-blue-600' : action.color === 'green' ? 'text-green-600' : action.color === 'purple' ? 'text-purple-600' : 'text-orange-600'}`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="font-semibold text-gray-700 text-xs group-hover:text-gray-900">{action.label}</p>
                        {action.badge !== null && action.badge > 0 && (
                          <span className="text-xs font-semibold px-1.5 py-0.5 rounded-full bg-red-100 text-red-800">
                            {action.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-600 mt-0.5">{action.description}</p>
                    </div>
                    <ChevronRight className="w-3 h-3 text-gray-400 group-hover:text-gray-600" />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-gray-900">Recent Orders</h3>
            <button 
              onClick={() => setActiveSection('orders')}
              className="text-xs text-blue-600 hover:text-blue-800 font-medium"
            >
              View All
            </button>
          </div>
          {allOrders.length === 0 ? (
            <div className="text-center py-4">
              <ShoppingBag className="w-10 h-10 text-gray-300 mx-auto mb-2" />
              <p className="text-gray-600 text-xs">No orders yet</p>
              <p className="text-xs text-gray-500 mt-0.5">Orders will appear here when customers make purchases</p>
            </div>
          ) : (
            <div className="space-y-2">
              {allOrders.slice(0, 5).map((order) => (
                <div key={order.id} className="flex items-center justify-between p-2 border border-gray-100 rounded hover:bg-gray-50 text-xs">
                  <div>
                    <p className="font-medium text-gray-900">#{order.order_number}</p>
                    <p className="text-gray-600">{order.buyer_name}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">${order.total_amount}</p>
                    <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                      order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                      order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {order.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-lg p-4 border border-gray-200 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-gray-900">Recent Products</h3>
          <button 
            onClick={() => setActiveSection('products')}
            className="text-xs text-blue-600 hover:text-blue-800 font-medium"
          >
            View All Products
          </button>
        </div>
        {allProducts.length === 0 ? (
          <div className="text-center py-4">
            <Package className="w-10 h-10 text-gray-300 mx-auto mb-2" />
            <p className="text-gray-600 text-xs">No products uploaded yet</p>
            <p className="text-xs text-gray-500 mt-0.5">Products will appear here when sellers upload them</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {allProducts.slice(0, 6).map((product) => (
              <div key={product.id} className="border border-gray-200 rounded-lg p-3 hover:shadow transition-shadow duration-200">
                <div className="flex items-start space-x-2">
                  {product.images && product.images.length > 0 ? (
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-12 h-12 object-cover rounded"
                    />
                  ) : (
                    <div className="w-12 h-12 bg-gray-100 rounded flex items-center justify-center">
                      <Package className="w-6 h-6 text-gray-400" />
                    </div>
                  )}
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 text-xs line-clamp-1">{product.name}</h4>
                    <p className="text-xs text-gray-600 mt-0.5">by {product.seller_name}</p>
                    <div className="flex items-center justify-between mt-1">
                      <span className="font-bold text-green-600 text-xs">${product.price}</span>
                      <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                        product.approval_status === 'approved' ? 'bg-green-100 text-green-800' :
                        product.approval_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {product.approval_status}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  const renderSellerManagement = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Seller Management</h2>
          <p className="text-gray-600 text-xs mt-0.5">
            {stats.totalSellers} Total Sellers • {stats.approvedSellers} Approved • {stats.pendingApprovals} Pending
          </p>
        </div>
        <div className="flex items-center space-x-3">
          {stats.pendingApprovals > 0 && (
            <span className="bg-red-100 text-red-800 text-xs font-semibold px-3 py-1 rounded-full">
              {stats.pendingApprovals} Pending Approval
            </span>
          )}
          <button
            onClick={fetchAdminData}
            className="flex items-center space-x-1.5 px-3 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {pendingSellers.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-base font-semibold text-gray-900">Pending Seller Approvals</h3>
            <p className="text-gray-600 text-xs mt-0.5">Review and approve new seller applications</p>
          </div>
          <div className="divide-y divide-gray-200">
            {pendingSellers.map((seller) => (
              <div key={seller.id} className="p-4 hover:bg-gray-50 transition-colors duration-200">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                      <Store className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 text-sm">{seller.business_name}</h4>
                      <p className="text-gray-600 text-xs">{seller.email}</p>
                      <div className="flex items-center space-x-1.5 mt-0.5">
                        <span className="bg-yellow-100 text-yellow-800 text-xs px-1.5 py-0.5 rounded-full">
                          Pending Review
                        </span>
                        <span className="text-xs text-gray-500">
                          Applied: {new Date(seller.created_at).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedSeller(seller)}
                      className="flex items-center space-x-1.5 px-2.5 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Details</span>
                    </button>
                    <button
                      onClick={() => approveSeller(seller.id)}
                      disabled={isProcessing}
                      className="flex items-center space-x-1.5 px-3 py-1.5 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all duration-200 font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve</span>
                    </button>
                    <button
                      onClick={() => setSelectedSeller(seller)}
                      disabled={isProcessing}
                      className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all duration-200 font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-gray-900">All Sellers ({allSellers.length})</h3>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                placeholder="Search sellers..."
                className="border border-gray-300 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 w-48"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        {allSellers.length === 0 ? (
          <div className="p-8 text-center">
            <Store className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-gray-900 mb-1.5">No sellers found</h3>
            <p className="text-gray-600 text-xs">Sellers will appear here when they register</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {allSellers
              .filter(seller => 
                seller.business_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                seller.email.toLowerCase().includes(searchQuery.toLowerCase())
              )
              .map((seller) => (
              <div key={seller.id} className="p-4 hover:bg-gray-50 transition-colors duration-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      seller.approval_status === 'approved' ? 'bg-gradient-to-br from-green-500 to-emerald-600' :
                      seller.approval_status === 'pending' ? 'bg-gradient-to-br from-yellow-500 to-orange-600' :
                      'bg-gradient-to-br from-red-500 to-pink-600'
                    }`}>
                      <Store className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 text-sm">{seller.business_name}</h4>
                      <p className="text-gray-600 text-xs">{seller.email}</p>
                      <div className="flex items-center space-x-1.5 mt-0.5">
                        <span className={`px-1.5 py-0.5 text-xs rounded-full ${
                          seller.approval_status === 'approved' ? 'bg-green-100 text-green-800' :
                          seller.approval_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {seller.approval_status.toUpperCase()}
                        </span>
                        <span className={`px-1.5 py-0.5 text-xs rounded-full ${
                          seller.status === 'active' ? 'bg-green-100 text-green-800' :
                          seller.status === 'pending_review' ? 'bg-yellow-100 text-yellow-800' :
                          seller.status === 'rejected' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {seller.status.toUpperCase()}
                        </span>
                        {seller.featured_seller && (
                          <span className="px-1.5 py-0.5 bg-purple-100 text-purple-800 text-xs rounded-full">
                            Featured
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-base font-bold text-green-600 text-sm">{seller.wallet_balance?.toLocaleString() || 0} SR</p>
                    <p className="text-xs text-gray-600">{seller.total_products || 0} Products</p>
                    <p className="text-xs text-gray-600">{seller.total_sales || 0} Sales</p>
                  </div>
                </div>

                <div className="mt-3 flex items-center space-x-2 flex-wrap gap-1">
                  <button
                    onClick={() => setSelectedSeller(seller)}
                    className="flex items-center space-x-1.5 px-2.5 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Details</span>
                  </button>
                  {seller.approval_status === 'approved' && (
                    <>
                      <button
                        onClick={async () => {
                          const suspend = !seller.suspended;
                          setAllSellers(prev => prev.map(s => 
                            s.id === seller.id ? { ...s, suspended: suspend } : s
                          ));
                          alert(`Seller ${suspend ? 'suspended' : 'unsuspended'} successfully!`);
                        }}
                        className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg transition-all duration-200 font-semibold text-xs ${
                          seller.suspended 
                            ? 'bg-green-500 text-white hover:bg-green-600' 
                            : 'bg-orange-500 text-white hover:bg-orange-600'
                        }`}
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>{seller.suspended ? 'Unsuspend' : 'Suspend'}</span>
                      </button>
                      <button
                        onClick={async () => {
                          const featured = !seller.featured_seller;
                          setAllSellers(prev => prev.map(s => 
                            s.id === seller.id ? { ...s, featured_seller: featured } : s
                          ));
                          alert(`Seller ${featured ? 'featured' : 'unfeatured'} successfully!`);
                        }}
                        className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg transition-all duration-200 font-semibold text-xs ${
                          seller.featured_seller
                            ? 'bg-gray-500 text-white hover:bg-gray-600'
                            : 'bg-purple-500 text-white hover:bg-purple-600'
                        }`}
                      >
                        <Star className="w-3.5 h-3.5" />
                        <span>{seller.featured_seller ? 'Unfeature' : 'Feature'}</span>
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedSeller && (
        <SellerDetailModal 
          seller={selectedSeller} 
          onClose={() => setSelectedSeller(null)}
          onApprove={approveSeller}
          onReject={rejectSeller}
          onSuspend={async (sellerId, suspend) => {
            setAllSellers(prev => prev.map(s => 
              s.id === sellerId ? { ...s, suspended: suspend } : s
            ));
          }}
          onAddNote={async (sellerId, note) => {
            alert('Note added successfully!');
          }}
          onIssueWarning={async (sellerId, warning) => {
            alert('Warning issued successfully!');
          }}
          onToggleFeatured={async (sellerId, featured) => {
            setAllSellers(prev => prev.map(s => 
              s.id === sellerId ? { ...s, featured_seller: featured } : s
            ));
          }}
          onVerifyKYC={verifyKYC}
          isProcessing={isProcessing}
        />
      )}
    </div>
  );

  const renderProductManagement = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Product Management</h2>
          <p className="text-gray-600 text-xs mt-0.5">
            {stats.totalProducts} Total Products • {stats.approvedProducts} Approved • {stats.pendingProducts} Pending
          </p>
        </div>
        <div className="flex items-center space-x-3">
          {stats.pendingProducts > 0 && (
            <span className="bg-red-100 text-red-800 text-xs font-semibold px-3 py-1 rounded-full">
              {stats.pendingProducts} Pending Approval
            </span>
          )}
          <button
            onClick={fetchAdminData}
            className="flex items-center space-x-1.5 px-3 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {pendingProducts.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-base font-semibold text-gray-900">Pending Product Approvals</h3>
            <p className="text-gray-600 text-xs mt-0.5">Review and approve new products</p>
          </div>
          <div className="divide-y divide-gray-200">
            {pendingProducts.map((product) => (
              <div key={product.id} className="p-4 hover:bg-gray-50 transition-colors duration-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {product.images && product.images.length > 0 ? (
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        className="w-12 h-12 object-cover rounded"
                      />
                    ) : (
                      <div className="w-12 h-12 bg-gray-100 rounded flex items-center justify-center">
                        <Package className="w-6 h-6 text-gray-400" />
                      </div>
                    )}
                    <div>
                      <h4 className="font-semibold text-gray-900 text-sm">{product.name}</h4>
                      <p className="text-gray-600 text-xs">by {product.seller_name}</p>
                      <div className="flex items-center space-x-1.5 mt-0.5">
                        <span className="bg-yellow-100 text-yellow-800 text-xs px-1.5 py-0.5 rounded-full">
                          Pending Review
                        </span>
                        <span className="text-xs text-gray-500">
                          ${product.price}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedProduct(product)}
                      className="flex items-center space-x-1.5 px-2.5 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Details</span>
                    </button>
                    <button
                      onClick={() => approveProduct(product.id)}
                      disabled={isProcessing}
                      className="flex items-center space-x-1.5 px-3 py-1.5 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all duration-200 font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve</span>
                    </button>
                    <button
                      onClick={() => {
                        const reason = prompt('Enter rejection reason:');
                        if (reason) rejectProduct(product, reason);
                      }}
                      disabled={isProcessing}
                      className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all duration-200 font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-gray-900">All Products ({allProducts.length})</h3>
            <div className="flex items-center space-x-2">
              <select 
                className="border border-gray-300 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                onChange={(e) => {
                  if (e.target.value === 'all') {
                    setSearchQuery('');
                  } else {
                    setSearchQuery(e.target.value);
                  }
                }}
              >
                <option value="all">All Products</option>
                <option value="approved">Approved</option>
                <option value="pending">Pending</option>
                <option value="featured">Featured</option>
              </select>
              <input
                type="text"
                placeholder="Search products..."
                className="border border-gray-300 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 w-48"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        {allProducts.length === 0 ? (
          <div className="p-8 text-center">
            <Package className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-gray-900 mb-1.5">No products found</h3>
            <p className="text-gray-600 text-xs">Products will appear here when sellers upload them</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {allProducts
              .filter(product => 
                product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                product.seller_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                (searchQuery === 'approved' && product.approval_status === 'approved') ||
                (searchQuery === 'pending' && product.approval_status === 'pending') ||
                (searchQuery === 'featured' && product.featured)
              )
              .map((product) => (
              <div key={product.id} className="p-4 hover:bg-gray-50 transition-colors duration-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {product.images && product.images.length > 0 ? (
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        className="w-12 h-12 object-cover rounded"
                      />
                    ) : (
                      <div className="w-12 h-12 bg-gray-100 rounded flex items-center justify-center">
                        <Package className="w-6 h-6 text-gray-400" />
                      </div>
                    )}
                    <div>
                      <h4 className="font-semibold text-gray-900 text-sm">{product.name}</h4>
                      <p className="text-gray-600 text-xs">by {product.seller_name}</p>
                      <div className="flex items-center space-x-1.5 mt-0.5">
                        <span className={`px-1.5 py-0.5 text-xs rounded-full ${
                          product.approval_status === 'approved' ? 'bg-green-100 text-green-800' :
                          product.approval_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {product.approval_status.toUpperCase()}
                        </span>
                        {product.featured && (
                          <span className="px-1.5 py-0.5 bg-purple-100 text-purple-800 text-xs rounded-full">
                            Featured
                          </span>
                        )}
                        {product.blocked && (
                          <span className="px-1.5 py-0.5 bg-red-100 text-red-800 text-xs rounded-full">
                            Blocked
                          </span>
                        )}
                        {product.low_stock_alert && (
                          <span className="px-1.5 py-0.5 bg-orange-100 text-orange-800 text-xs rounded-full">
                            Low Stock
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-base font-bold text-green-600 text-sm">${product.price}</p>
                    <p className="text-xs text-gray-600">{product.stock_quantity} in stock</p>
                    <p className="text-xs text-gray-600">{product.sales_count || 0} sales</p>
                  </div>
                </div>

                <div className="mt-3 flex items-center space-x-2 flex-wrap gap-1">
                  <button
                    onClick={() => setSelectedProduct(product)}
                    className="flex items-center space-x-1.5 px-2.5 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Details</span>
                  </button>
                  {product.approval_status === 'approved' && (
                    <>
                      <button
                        onClick={() => toggleProductFeatured(product.id, !product.featured)}
                        className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg transition-all duration-200 font-semibold text-xs ${
                          product.featured 
                            ? 'bg-gray-500 text-white hover:bg-gray-600' 
                            : 'bg-purple-500 text-white hover:bg-purple-600'
                        }`}
                      >
                        <Star className="w-3.5 h-3.5" />
                        <span>{product.featured ? 'Unfeature' : 'Feature'}</span>
                      </button>
                      <button
                        onClick={() => blockProduct(product.id, !product.blocked)}
                        className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg transition-all duration-200 font-semibold text-xs ${
                          product.blocked 
                            ? 'bg-green-500 text-white hover:bg-green-600' 
                            : 'bg-red-500 text-white hover:bg-red-600'
                        }`}
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>{product.blocked ? 'Unblock' : 'Block'}</span>
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedProduct && (
        <ProductDetailModal 
          product={selectedProduct} 
          onClose={() => setSelectedProduct(null)}
          onApprove={approveProduct}
          onReject={rejectProduct}
          onToggleFeatured={toggleProductFeatured}
          onBlock={blockProduct}
          onEdit={editProduct}
          onDelete={async (productId) => {
            if (confirm('Are you sure you want to delete this product?')) {
              setAllProducts(prev => prev.filter(p => p.id !== productId));
              alert('Product deleted successfully!');
            }
          }}
          isProcessing={isProcessing}
        />
      )}
    </div>
  );

  const renderBuyerManagement = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Buyer Management</h2>
          <p className="text-gray-600 text-xs mt-0.5">
            {stats.totalBuyers} Total Buyers • {stats.approvedBuyers} Active • {allBuyers.filter(b => b.is_banned).length} Banned
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={fetchAdminData}
            className="flex items-center space-x-1.5 px-3 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Buyers', value: stats.totalBuyers, icon: Users, color: 'blue' },
          { label: 'Active Buyers', value: stats.approvedBuyers, icon: User, color: 'green' },
          { label: 'Premium Members', value: allBuyers.filter(b => b.membership_tier === 'premium').length, icon: Star, color: 'yellow' },
          { label: 'Banned Users', value: allBuyers.filter(b => b.is_banned).length, icon: Ban, color: 'red' },
        ].map((stat, index) => {
          const Icon = stat.icon;
          
          return (
            <div key={index} className="bg-white rounded-lg p-4 border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-xs text-gray-600">{stat.label}</p>
                </div>
                <div className={`p-2 rounded-lg ${stat.color === 'blue' ? 'bg-blue-50' : stat.color === 'green' ? 'bg-green-50' : stat.color === 'yellow' ? 'bg-yellow-50' : 'bg-red-50'}`}>
                  <Icon className={`w-5 h-5 ${stat.color === 'blue' ? 'text-blue-600' : stat.color === 'green' ? 'text-green-600' : stat.color === 'yellow' ? 'text-yellow-600' : 'text-red-600'}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-gray-900">All Buyers ({allBuyers.length})</h3>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                placeholder="Search buyers..."
                className="border border-gray-300 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 w-48"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        {allBuyers.length === 0 ? (
          <div className="p-8 text-center">
            <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-gray-900 mb-1.5">No buyers found</h3>
            <p className="text-gray-600 text-xs">Buyers will appear here when they register</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {allBuyers
              .filter(buyer => 
                buyer.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                buyer.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
              )
              .map((buyer) => (
              <div key={buyer.id} className="p-4 hover:bg-gray-50 transition-colors duration-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      buyer.membership_tier === 'premium' ? 'bg-gradient-to-br from-yellow-500 to-orange-600' : 
                      buyer.membership_tier === 'vip' ? 'bg-gradient-to-br from-purple-500 to-pink-600' : 
                      'bg-gradient-to-br from-green-500 to-emerald-600'
                    }`}>
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 text-sm">{buyer.full_name || 'No Name'}</h4>
                      <p className="text-gray-600 text-xs">{buyer.email}</p>
                      <div className="flex items-center space-x-1.5 mt-0.5">
                        <span className={`px-1.5 py-0.5 text-xs rounded-full ${
                          buyer.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {buyer.is_active ? 'Active' : 'Inactive'}
                        </span>
                        {buyer.is_banned && (
                          <span className="px-1.5 py-0.5 bg-red-100 text-red-800 text-xs rounded-full">
                            Banned
                          </span>
                        )}
                        {buyer.membership_tier !== 'basic' && (
                          <span className={`px-1.5 py-0.5 text-xs rounded-full ${
                            buyer.membership_tier === 'premium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-purple-100 text-purple-800'
                          }`}>
                            {buyer.membership_tier.toUpperCase()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-base font-bold text-green-600 text-sm">${buyer.total_spent || 0}</p>
                    <p className="text-xs text-gray-600">{buyer.total_orders || 0} Orders</p>
                    <p className="text-xs text-gray-600">
                      Joined: {new Date(buyer.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="mt-3 flex items-center space-x-2 flex-wrap gap-1">
                  <button
                    onClick={() => {
                      alert(`Buyer Details:\n\nName: ${buyer.full_name}\nEmail: ${buyer.email}\nTotal Orders: ${buyer.total_orders}\nTotal Spent: $${buyer.total_spent}`);
                    }}
                    className="flex items-center space-x-1.5 px-2.5 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Details</span>
                  </button>
                  <button
                    onClick={async () => {
                      const ban = !buyer.is_banned;
                      setAllBuyers(prev => prev.map(b => 
                        b.id === buyer.id ? { ...b, is_banned: ban } : b
                      ));
                      alert(`Buyer ${ban ? 'banned' : 'unbanned'} successfully!`);
                    }}
                    className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg transition-all duration-200 font-semibold text-xs ${
                      buyer.is_banned 
                        ? 'bg-green-500 text-white hover:bg-green-600' 
                        : 'bg-red-500 text-white hover:bg-red-600'
                    }`}
                  >
                    <Ban className="w-3.5 h-3.5" />
                    <span>{buyer.is_banned ? 'Unban User' : 'Ban User'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  const renderOrderManagement = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Order Management</h2>
          <p className="text-gray-600 text-xs mt-0.5">
            {stats.totalOrders} Total Orders • ${stats.totalRevenue} Total Revenue • {stats.todayOrders} Today
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={fetchAdminData}
            className="flex items-center space-x-1.5 px-3 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Pending', value: allOrders.filter(o => o.status === 'pending').length, color: 'yellow' },
          { label: 'Processing', value: allOrders.filter(o => o.status === 'processing').length, color: 'blue' },
          { label: 'Shipped', value: allOrders.filter(o => o.status === 'shipped').length, color: 'purple' },
          { label: 'Delivered', value: allOrders.filter(o => o.status === 'delivered').length, color: 'green' },
        ].map((stat, index) => (
          <div key={index} className="bg-white rounded-lg p-4 border border-gray-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-xs text-gray-600">{stat.label} Orders</p>
              </div>
              <div className={`p-2 rounded-lg ${stat.color === 'yellow' ? 'bg-yellow-50' : stat.color === 'blue' ? 'bg-blue-50' : stat.color === 'purple' ? 'bg-purple-50' : 'bg-green-50'}`}>
                <Package className={`w-5 h-5 ${stat.color === 'yellow' ? 'text-yellow-600' : stat.color === 'blue' ? 'text-blue-600' : stat.color === 'purple' ? 'text-purple-600' : 'text-green-600'}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-gray-900">All Orders ({allOrders.length})</h3>
            <div className="flex items-center space-x-2">
              <select 
                className="border border-gray-300 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                onChange={(e) => {
                  if (e.target.value === 'all') {
                    setSearchQuery('');
                  } else {
                    setSearchQuery(e.target.value);
                  }
                }}
              >
                <option value="all">All Orders</option>
                <option value="pending">Pending</option>
                <option value="processing">Processing</option>
                <option value="shipped">Shipped</option>
                <option value="delivered">Delivered</option>
              </select>
              <input
                type="text"
                placeholder="Search orders..."
                className="border border-gray-300 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 w-48"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        {allOrders.length === 0 ? (
          <div className="p-8 text-center">
            <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-gray-900 mb-1.5">No orders found</h3>
            <p className="text-gray-600 text-xs">Orders will appear here when customers make purchases</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {allOrders
              .filter(order => 
                order.order_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
                order.buyer_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                order.buyer_email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                (searchQuery === 'pending' && order.status === 'pending') ||
                (searchQuery === 'processing' && order.status === 'processing') ||
                (searchQuery === 'shipped' && order.status === 'shipped') ||
                (searchQuery === 'delivered' && order.status === 'delivered')
              )
              .map((order) => (
              <div key={order.id} className="p-4 hover:bg-gray-50 transition-colors duration-200">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-semibold text-gray-900 text-sm">Order #{order.order_number}</h4>
                    <p className="text-gray-600 text-xs">
                      by {order.buyer_name} • {order.buyer_email}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-green-600 text-sm">${order.total_amount}</p>
                    <p className="text-xs text-gray-600">
                      {new Date(order.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-3 text-xs">
                  <div>
                    <span className="text-gray-600">Status: </span>
                    <span className={`font-semibold ${
                      order.status === 'delivered' ? 'text-green-600' :
                      order.status === 'pending' ? 'text-yellow-600' :
                      order.status === 'cancelled' ? 'text-red-600' :
                      'text-blue-600'
                    }`}>
                      {order.status}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-600">Payment: </span>
                    <span className={`font-semibold ${
                      order.payment_status === 'paid' ? 'text-green-600' :
                      order.payment_status === 'pending' ? 'text-yellow-600' :
                      'text-red-600'
                    }`}>
                      {order.payment_status}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-600">Seller: </span>
                    <span className="font-semibold text-gray-900">{order.seller_name}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Items: </span>
                    <span className="font-semibold text-gray-900">{order.items.length}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-2 mt-3 pt-3 border-t border-gray-200 flex-wrap gap-1">
                  <button
                    onClick={() => {
                      alert(`Order Details:\n\nOrder #: ${order.order_number}\nBuyer: ${order.buyer_name}\nTotal: $${order.total_amount}\nStatus: ${order.status}\nPayment: ${order.payment_status}`);
                    }}
                    className="flex items-center space-x-1.5 px-2.5 py-1.5 border border-blue-300 text-blue-700 rounded-lg hover:bg-blue-50 transition-all duration-200 font-semibold text-xs"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Details</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  const renderCategoriesManagement = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Categories Management</h2>
          <p className="text-gray-600 text-xs mt-0.5">Manage product categories and organize your catalog</p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => {
              setEditingCategory(null);
              setNewCategory({
                name: '',
                description: '',
                image_url: '',
                parent_id: '',
                sort_order: categories.length,
                type: 'general',
                sub_type: ''
              });
              setShowCategoryModal(true);
            }}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 font-semibold text-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Category</span>
          </button>
        </div>
      </div>

      {categories.length === 0 ? (
        <div className="bg-white rounded-lg p-8 text-center border border-gray-200 shadow-sm">
          <Grid3X3 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <h3 className="text-lg font-semibold text-gray-900 mb-1.5">No categories found</h3>
          <p className="text-gray-600 text-xs mb-4">Create your first category to organize products</p>
          <button
            onClick={() => {
              setEditingCategory(null);
              setNewCategory({
                name: '',
                description: '',
                image_url: '',
                parent_id: '',
                sort_order: 0,
                type: 'general',
                sub_type: ''
              });
              setShowCategoryModal(true);
            }}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 font-semibold text-xs"
          >
            Create First Category
          </button>
        </div>
      ) : (
        <>
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
            <div className="p-4 border-b border-gray-200">
              <h3 className="text-base font-semibold text-gray-900">Main Categories</h3>
              <p className="text-gray-600 text-xs mt-0.5">Primary product categories</p>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categories
                  .filter(cat => !cat.parent_id)
                  .map((category) => (
                  <div key={category.id} className="border border-gray-200 rounded-lg p-4 hover:shadow transition-all duration-200">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        {category.image_url ? (
                          <img
                            src={category.image_url}
                            alt={category.name}
                            className="w-10 h-10 object-cover rounded"
                          />
                        ) : (
                          <div className={`w-10 h-10 rounded flex items-center justify-center ${
                            category.type === 'indoor' ? 'bg-blue-100' :
                            category.type === 'outdoor' ? 'bg-green-100' :
                            'bg-gray-100'
                          }`}>
                            <Grid3X3 className={`w-5 h-5 ${
                              category.type === 'indoor' ? 'text-blue-600' :
                              category.type === 'outdoor' ? 'text-green-600' :
                              'text-gray-600'
                            }`} />
                          </div>
                        )}
                        <div>
                          <h4 className="font-semibold text-gray-900 text-sm">{category.name}</h4>
                          <div className="flex items-center space-x-1.5 mt-0.5">
                            <span className={`px-1.5 py-0.5 text-xs rounded-full ${
                              category.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                            }`}>
                              {category.is_active ? 'Active' : 'Inactive'}
                            </span>
                            {category.type && category.type !== 'general' && (
                              <span className={`px-1.5 py-0.5 text-xs rounded-full ${
                                category.type === 'indoor' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                              }`}>
                                {category.type}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1">
                        <button
                          onClick={() => {
                            setEditingCategory(category);
                            setNewCategory({
                              name: category.name,
                              description: category.description,
                              image_url: category.image_url || '',
                              parent_id: category.parent_id || '',
                              sort_order: category.sort_order,
                              type: category.type || 'general',
                              sub_type: category.sub_type || ''
                            });
                            setShowCategoryModal(true);
                          }}
                          className="p-1.5 hover:bg-gray-100 rounded transition-colors"
                          title="Edit"
                        >
                          <Edit className="w-3.5 h-3.5 text-gray-600" />
                        </button>
                        <button
                          onClick={() => toggleCategoryStatus(category.id, !category.is_active)}
                          className={`p-1.5 rounded transition-colors ${
                            category.is_active 
                              ? 'hover:bg-red-100 text-red-600' 
                              : 'hover:bg-green-100 text-green-600'
                          }`}
                          title={category.is_active ? 'Deactivate' : 'Activate'}
                        >
                          {category.is_active ? <Ban className="w-3.5 h-3.5" /> : <Check className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    <p className="text-gray-600 text-xs mb-3 line-clamp-2">{category.description}</p>

                    {categories.filter(sub => sub.parent_id === category.id).length > 0 && (
                      <div className="border-t border-gray-200 pt-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-gray-600">
                            {categories.filter(sub => sub.parent_id === category.id).length} subcategories
                          </span>
                          <button
                            onClick={() => {
                              setEditingCategory(null);
                              setNewCategory({
                                name: '',
                                description: '',
                                image_url: '',
                                parent_id: category.id,
                                sort_order: categories.filter(c => c.parent_id === category.id).length,
                                type: 'general',
                                sub_type: ''
                              });
                              setShowCategoryModal(true);
                            }}
                            className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                          >
                            Add Subcategory
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {categories.filter(cat => cat.parent_id).length > 0 && (
            <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
              <div className="p-4 border-b border-gray-200">
                <h3 className="text-base font-semibold text-gray-900">Subcategories</h3>
                <p className="text-gray-600 text-xs mt-0.5">Secondary product categories</p>
              </div>
              <div className="p-4">
                <div className="space-y-3">
                  {categories
                    .filter(cat => cat.parent_id)
                    .map((subcategory) => {
                      const parentCategory = categories.find(c => c.id === subcategory.parent_id);
                      return (
                        <div key={subcategory.id} className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 transition-colors duration-200">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className={`w-8 h-8 rounded flex items-center justify-center ${
                                subcategory.type === 'indoor' ? 'bg-blue-100' :
                                subcategory.type === 'outdoor' ? 'bg-green-100' :
                                'bg-gray-100'
                              }`}>
                                <Grid3X3 className={`w-3.5 h-3.5 ${
                                  subcategory.type === 'indoor' ? 'text-blue-600' :
                                  subcategory.type === 'outdoor' ? 'text-green-600' :
                                  'text-gray-600'
                                }`} />
                              </div>
                              <div>
                                <h4 className="font-medium text-gray-900 text-sm">{subcategory.name}</h4>
                                <div className="flex items-center space-x-1.5 mt-0.5">
                                  <span className="text-xs text-gray-600">
                                    Parent: {parentCategory?.name || 'Unknown'}
                                  </span>
                                  <span className={`px-1.5 py-0.5 text-xs rounded-full ${
                                    subcategory.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                  }`}>
                                    {subcategory.is_active ? 'Active' : 'Inactive'}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center space-x-1">
                              <button
                                onClick={() => {
                                  setEditingCategory(subcategory);
                                  setNewCategory({
                                    name: subcategory.name,
                                    description: subcategory.description,
                                    image_url: subcategory.image_url || '',
                                    parent_id: subcategory.parent_id || '',
                                    sort_order: subcategory.sort_order,
                                    type: subcategory.type || 'general',
                                    sub_type: subcategory.sub_type || ''
                                  });
                                  setShowCategoryModal(true);
                                }}
                                className="p-1.5 hover:bg-gray-100 rounded transition-colors"
                                title="Edit"
                              >
                                <Edit className="w-3.5 h-3.5 text-gray-600" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {showCategoryModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-xl mx-auto shadow-lg max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-900">
                {editingCategory ? 'Edit Category' : 'Add New Category'}
              </h3>
              <button
                onClick={() => setShowCategoryModal(false)}
                className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Category Name *
                </label>
                <input
                  type="text"
                  value={newCategory.name}
                  onChange={(e) => setNewCategory(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-xs"
                  placeholder="e.g., Living Room Furniture"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Description
                </label>
                <textarea
                  value={newCategory.description}
                  onChange={(e) => setNewCategory(prev => ({ ...prev, description: e.target.value }))}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-xs"
                  placeholder="Describe this category..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                    Category Type
                  </label>
                  <select
                    value={newCategory.parent_id ? 'subcategory' : 'main'}
                    onChange={(e) => {
                      if (e.target.value === 'main') {
                        setNewCategory(prev => ({ ...prev, parent_id: '' }));
                      }
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent text-xs"
                  >
                    <option value="main">Main Category</option>
                    <option value="subcategory">Subcategory</option>
                  </select>
                </div>

                {newCategory.parent_id === '' && (
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                      Furniture Type
                    </label>
                    <select
                      value={newCategory.type}
                      onChange={(e) => setNewCategory(prev => ({ ...prev, type: e.target.value as any }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent text-xs"
                    >
                      <option value="general">General</option>
                      <option value="indoor">Indoor</option>
                      <option value="outdoor">Outdoor</option>
                    </select>
                  </div>
                )}

                {newCategory.parent_id !== '' && (
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                      Parent Category
                    </label>
                    <select
                      value={newCategory.parent_id}
                      onChange={(e) => setNewCategory(prev => ({ ...prev, parent_id: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent text-xs"
                    >
                      <option value="">Select Parent Category</option>
                      {categories
                        .filter(cat => !cat.parent_id)
                        .map((category) => (
                        <option key={category.id} value={category.id}>
                          {category.name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                    Sort Order
                  </label>
                  <input
                    type="number"
                    value={newCategory.sort_order}
                    onChange={(e) => setNewCategory(prev => ({ ...prev, sort_order: parseInt(e.target.value) || 0 }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                    Image URL (Optional)
                  </label>
                  <input
                    type="text"
                    value={newCategory.image_url}
                    onChange={(e) => setNewCategory(prev => ({ ...prev, image_url: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-xs"
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <button
                  onClick={() => setShowCategoryModal(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={saveCategory}
                  disabled={!newCategory.name.trim()}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {editingCategory ? 'Update Category' : 'Create Category'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderNotificationSystem = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Notification System</h2>
          <p className="text-gray-600 text-xs mt-0.5">Send notifications to users</p>
        </div>
        <button
          onClick={() => setShowNotificationModal(true)}
          className="flex items-center space-x-1.5 px-3 py-1.5 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 font-semibold text-xs"
        >
          <Bell className="w-3.5 h-3.5" />
          <span>Send New Notification</span>
        </button>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200">
          <h3 className="text-base font-semibold text-gray-900">Notification History</h3>
          <p className="text-gray-600 text-xs mt-0.5">Previously sent notifications</p>
        </div>

        {notifications.length === 0 ? (
          <div className="p-8 text-center">
            <Bell className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-gray-900 mb-1.5">No notifications sent</h3>
            <p className="text-gray-600 text-xs">Send your first notification to get started</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {notifications.map((notification) => (
              <div key={notification.id} className="p-4 hover:bg-gray-50 transition-colors duration-200">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="font-semibold text-gray-900 text-sm">{notification.title}</h4>
                    <p className="text-gray-600 text-xs mt-0.5">{notification.message}</p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                    notification.type === 'success' ? 'bg-green-100 text-green-800' :
                    notification.type === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                    notification.type === 'error' ? 'bg-red-100 text-red-800' :
                    'bg-blue-100 text-blue-800'
                  }`}>
                    {notification.type.toUpperCase()}
                  </span>
                </div>
                
                <div className="flex items-center justify-between text-xs text-gray-600">
                  <div className="flex items-center space-x-3">
                    <span>Target: {notification.target_audience}</span>
                    {notification.sent_at && (
                      <span>Sent: {new Date(notification.sent_at).toLocaleDateString()}</span>
                    )}
                    <span>Method: {notification.delivery_method}</span>
                  </div>
                  <span>By: {notification.created_by}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showNotificationModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-xl mx-auto shadow-lg max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-900">Send Notification</h3>
              <button
                onClick={() => setShowNotificationModal(false)}
                className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Notification Title *
                </label>
                <input
                  type="text"
                  value={newNotification.title}
                  onChange={(e) => setNewNotification(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-xs"
                  placeholder="Enter notification title..."
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Message *
                </label>
                <textarea
                  value={newNotification.message}
                  onChange={(e) => setNewNotification(prev => ({ ...prev, message: e.target.value }))}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-xs"
                  placeholder="Enter notification message..."
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                    Type
                  </label>
                  <select
                    value={newNotification.type}
                    onChange={(e) => setNewNotification(prev => ({ ...prev, type: e.target.value as any }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent text-xs"
                  >
                    <option value="info">Information</option>
                    <option value="success">Success</option>
                    <option value="warning">Warning</option>
                    <option value="error">Error</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                    Target Audience
                  </label>
                  <select
                    value={newNotification.target_audience}
                    onChange={(e) => setNewNotification(prev => ({ ...prev, target_audience: e.target.value as any }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent text-xs"
                  >
                    <option value="all">All Users</option>
                    <option value="buyers">Buyers Only</option>
                    <option value="sellers">Sellers Only</option>
                    <option value="specific">Specific Users</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Delivery Method
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { value: 'push', label: 'Push Notification', icon: Smartphone },
                    { value: 'email', label: 'Email', icon: Mail },
                    { value: 'sms', label: 'SMS', icon: MessageCircle },
                    { value: 'all', label: 'All Methods', icon: Bell },
                  ].map((method) => {
                    const Icon = method.icon;
                    return (
                      <button
                        key={method.value}
                        onClick={() => setNewNotification(prev => ({ ...prev, delivery_method: method.value as any }))}
                        className={`p-3 border rounded-lg text-center transition-all duration-200 text-xs ${
                          newNotification.delivery_method === method.value
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <Icon className="w-5 h-5 text-gray-600 mx-auto mb-1.5" />
                        <span className="font-semibold text-gray-900">{method.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <button
                  onClick={() => setShowNotificationModal(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => sendNotification(newNotification)}
                  disabled={!newNotification.title.trim() || !newNotification.message.trim()}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Send Notification
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">System Settings</h2>
          <p className="text-gray-600 text-xs mt-0.5">Configure platform settings and preferences</p>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200">
          <h3 className="text-base font-semibold text-gray-900">General Settings</h3>
          <p className="text-gray-600 text-xs mt-0.5">Basic platform configuration</p>
        </div>
        
        <div className="p-4 space-y-4">
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-900 text-sm">Commission Settings</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                  Commission Rate (%)
                </label>
                <input
                  type="number"
                  defaultValue="10"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                  Minimum Payout (SR)
                </label>
                <input
                  type="number"
                  defaultValue="100"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
                />
              </div>
            </div>
          </div>

          <div className="space-y-3 pt-3 border-t border-gray-200">
            <h4 className="font-semibold text-gray-900 text-sm">Tax Settings</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                  Tax Rate (%)
                </label>
                <input
                  type="number"
                  defaultValue="15"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
                />
              </div>
              <div className="flex items-center space-x-1.5">
                <input
                  type="checkbox"
                  id="taxEnabled"
                  defaultChecked
                  className="w-3.5 h-3.5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <label htmlFor="taxEnabled" className="text-xs text-gray-700">
                  Enable Tax Calculation
                </label>
              </div>
            </div>
          </div>

          <div className="space-y-2 pt-3 border-t border-gray-200">
            <h4 className="font-semibold text-gray-900 text-sm">Platform Settings</h4>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900 text-xs">Enable New Seller Registration</p>
                  <p className="text-xs text-gray-600">Allow new sellers to register on the platform</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" defaultChecked className="sr-only peer" />
                  <div className="w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900 text-xs">Auto-Approve Products</p>
                  <p className="text-xs text-gray-600">Automatically approve products from trusted sellers</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" />
                  <div className="w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900 text-xs">Enable Email Notifications</p>
                  <p className="text-xs text-gray-600">Send email notifications for important events</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" defaultChecked className="sr-only peer" />
                  <div className="w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-gray-200">
            <button className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 font-semibold text-xs">
              Save Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const navigationTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'sellers', label: 'Sellers', icon: Store, badge: stats.pendingApprovals },
    { id: 'buyers', label: 'Buyers', icon: Users },
    { id: 'products', label: 'Products', icon: Package, badge: stats.pendingProducts },
    { id: 'orders', label: 'Orders', icon: ShoppingBag },
    { id: 'categories', label: 'Categories', icon: Grid3X3 },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-3"></div>
          <p className="text-gray-600 text-sm font-medium">Loading Admin Dashboard...</p>
          <p className="text-xs text-gray-500 mt-1">Fetching data from database...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition-all duration-200"
              >
                HomeDecor Admin
              </button>
              
              <div className="flex items-center space-x-0.5 bg-gray-100 p-0.5 rounded-lg">
                {navigationTabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveSection(tab.id)}
                      className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all duration-200 ${
                        activeSection === tab.id
                          ? 'bg-white text-gray-900 shadow-sm'
                          : 'text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{tab.label}</span>
                      {tab.badge && tab.badge > 0 && (
                        <span className="bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full min-w-4 text-center">
                          {tab.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="text-right">
                <p className="text-xs font-semibold text-gray-900">Admin</p>
                <p className="text-xs text-gray-600">admin@homedecor.com</p>
              </div>
              
              <button 
                onClick={fetchAdminData}
                className="p-2 hover:bg-gray-100 rounded-lg transition-all duration-200 group"
                title="Refresh Data"
              >
                <RefreshCw className="w-4 h-4 text-gray-600 group-hover:text-gray-900 transition-colors" />
              </button>
              
              <button className="p-2 hover:bg-gray-100 rounded-lg relative transition-all duration-200 group">
                <Bell className="w-4 h-4 text-gray-600 group-hover:text-gray-900 transition-colors" />
                {(adminAlerts.filter(a => !a.read).length > 0) && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-semibold shadow-sm">
                    {adminAlerts.filter(a => !a.read).length}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="p-6">
        {activeSection === 'dashboard' && renderDashboard()}
        {activeSection === 'sellers' && renderSellerManagement()}
        {activeSection === 'buyers' && renderBuyerManagement()}
        {activeSection === 'products' && renderProductManagement()}
        {activeSection === 'orders' && renderOrderManagement()}
        {activeSection === 'categories' && renderCategoriesManagement()}
        {activeSection === 'notifications' && renderNotificationSystem()}
        {activeSection === 'settings' && renderSettings()}
      </main>
    </div>
  );
};

export default AdminDashboard;