import React, { createContext, useContext, useState, useEffect } from "react";
import { supabase } from "../lib/supabase";

interface AuthContextType {
  user: any;
  userRole: "buyer" | "seller" | "admin" | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<any>;
  signUp: (
    email: string,
    password: string,
    name: string,
    role: string,
    phone?: string,
    city?: string,
    businessName?: string
  ) => Promise<any>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  userRole: null,
  isLoading: true,
  signIn: async () => {},
  signUp: async () => {},
  signOut: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<any>(null);
  const [userRole, setUserRole] = useState<"buyer" | "seller" | "admin" | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load session on start
  useEffect(() => {
    const loadSession = async () => {
      const { data } = await supabase.auth.getSession();

      if (data.session?.user) {
        setUser(data.session.user);

        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", data.session.user.id)
          .single();

        if (profile?.role) setUserRole(profile.role as any);
      }

      setIsLoading(false);
    };

    loadSession();

    // Listen for login/logout changes
    supabase.auth.onAuthStateChange(async (_, session) => {
      if (session?.user) {
        setUser(session.user);

        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", session.user.id)
          .single();

        setUserRole(profile?.role || null);
      } else {
        setUser(null);
        setUserRole(null);
      }
    });
  }, []);

  // Sign-in function
  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) return { error: error.message };

    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", data.user.id)
      .single();

    setUser(data.user);
    setUserRole(profile?.role || null);

    return { error: null };
  };

  // Sign-up function
  const signUp = async (
    email: string,
    password: string,
    name: string,
    role: string,
    phone?: string,
    city?: string,
    businessName?: string
  ) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error || !data.user) return { error: error?.message || "Signup failed" };

    // Insert into profiles table
    await supabase.from("profiles").insert({
      id: data.user.id,
      name,
      role,
      phone,
      city,
      business_name: businessName,
      email,
    });

    setUser(data.user);
    setUserRole(role as any);

    return { error: null };
  };

  // Sign-out function
  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setUserRole(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userRole,
        isLoading,
        signIn,
        signUp,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
