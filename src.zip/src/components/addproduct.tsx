import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import {
  ArrowLeft, Upload, Image as ImageIcon, Video, Trash2, Save,
  Plus, X, Check, DollarSign, Hash, Package, Truck,
  Shield, Ruler, Palette, Tag, FileText, Info, Box,
  Clock, MapPin, Layers, Repeat, Barcode, Settings,
  Warehouse, Building, Truck as TruckIcon, Home
} from 'lucide-react';

interface Variant {
  id: string;
  type: string;
  option: string;
  color?: string;
  size?: string;
  material?: string;
  price: string;
  stock: number;
  sku: string;
  barcode?: string;
  image?: string;
}

interface CityDelivery {
  city: string;
  available: boolean;
  freeDelivery: boolean;
  deliveryCost: string;
  deliveryTime: string;
  shippingCompany?: string;
}

interface ReturnPolicy {
  allowed: boolean;
  period: string;
  fee: string;
  conditions: string[];
}

interface ProductFormData {
  id: string;
  productType: 'ready' | 'customized';
  location: 'indoor' | 'outdoor';
  name: string;
  description: string;
  shortDescription: string;
  mainCategory: string;
  subCategory: string;
  displaySection: string;
  // Store as temporary IDs, not base64 data
  images: string[];
  mainImage: string;
  videoUrl: string;
  dimensions: {
    length: string;
    width: string;
    height: string;
    unit: string;
  };
  weight: string;
  primaryColor: string;
  availableColors: string[];
  finishType: string;
  warrantyType: string;
  warrantyDuration: string;
  material: string;
  hasVariants: boolean;
  variants: Variant[];
  sellingPrice: string;
  discountedPrice: string;
  stockQuantity: number;
  skuCode: string;
  barcode: string;
  availableCities: CityDelivery[];
  shippingOptions: {
    withinCity: {
      available: boolean;
      cost: string;
      time: string;
    };
    outsideCity: {
      available: boolean;
      cost: string;
      time: string;
    };
  };
  installationAvailable: boolean;
  installationFee: string;
  returnPolicy: ReturnPolicy;
  customizationTime: string;
  materialsUsed: string[];
  sellerId: string;
  sellerName: string;
  status: 'draft' | 'active' | 'inactive';
}

// Interface for temporary image storage
interface TempImageStorage {
  [key: string]: string; // imageId: base64Data
}

const AddProduct: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [activeStep, setActiveStep] = useState(1);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  
  // Store images separately to avoid localStorage overflow
  const [tempImages, setTempImages] = useState<TempImageStorage>({});
  const [tempVideo, setTempVideo] = useState<string>('');

  const [formData, setFormData] = useState<ProductFormData>({
    id: `prod_${Date.now()}`,
    productType: 'ready',
    location: 'indoor',
    name: '',
    description: '',
    shortDescription: '',
    mainCategory: '',
    subCategory: '',
    displaySection: '',
    images: [], // Will store image IDs, not base64
    mainImage: '',
    videoUrl: '',
    dimensions: {
      length: '',
      width: '',
      height: '',
      unit: 'cm'
    },
    weight: '',
    primaryColor: '#FFFFFF',
    availableColors: ['#FFFFFF', '#F5F5F5'],
    finishType: 'Glossy',
    warrantyType: 'Manufacturer',
    warrantyDuration: '1 year',
    material: 'Wood',
    hasVariants: false,
    variants: [],
    sellingPrice: '',
    discountedPrice: '',
    stockQuantity: 10,
    skuCode: `SKU${Date.now().toString().slice(-6)}`,
    barcode: '',
    availableCities: [
      {
        city: 'Riyadh',
        available: true,
        freeDelivery: true,
        deliveryCost: '0',
        deliveryTime: '3-5 days',
        shippingCompany: 'Aramex'
      }
    ],
    shippingOptions: {
      withinCity: {
        available: true,
        cost: '0',
        time: '1-2 days'
      },
      outsideCity: {
        available: true,
        cost: '50',
        time: '3-5 days'
      }
    },
    installationAvailable: false,
    installationFee: '0',
    returnPolicy: {
      allowed: true,
      period: '30 days',
      fee: '0',
      conditions: [
        'Product must be in original condition',
        'Original packaging required',
        'Proof of purchase needed'
      ]
    },
    customizationTime: '2-3 weeks',
    materialsUsed: ['Wood', 'Metal'],
    sellerId: user?.id || 'seller_001',
    sellerName: user?.name || user?.email || 'Sample Seller',
    status: 'draft'
  });

  const mainCategories = {
    ready: {
      indoor: [
        'Kitchen', 'Bedroom', 'Living Room', 'Dining Room', 
        'Bathroom', 'Office', 'Storage', 'Kids Room'
      ],
      outdoor: [
        'Garden', 'Patio', 'Balcony', 'Poolside', 
        'Terrace', 'Gazebo', 'Outdoor Kitchen'
      ]
    },
    customized: {
      indoor: [
        'Modular Kitchen', 'Custom Wardrobe', 'Living Room Set',
        'Office Furniture', 'Entertainment Unit', 'Custom Storage'
      ],
      outdoor: [
        'Custom Outdoor Seating', 'Garden Furniture', 'Patio Set',
        'Outdoor Kitchen Unit', 'Custom Gazebo'
      ]
    }
  };

  const subCategories: Record<string, string[]> = {
    'Kitchen': ['Kitchen Cabinet', 'Kitchen Island', 'Countertop', 'Pantry', 'Stool'],
    'Bedroom': ['Bed', 'Wardrobe', 'Dresser', 'Nightstand', 'Mirror'],
    'Living Room': ['Sofa', 'Armchair', 'Coffee Table', 'TV Stand', 'Bookshelf'],
    'Dining Room': ['Dining Table', 'Dining Chair', 'Buffet', 'Sideboard'],
    'Bathroom': ['Vanity', 'Cabinet', 'Shelves', 'Stool'],
    'Office': ['Desk', 'Office Chair', 'Filing Cabinet', 'Bookcase'],
    'Garden': ['Bench', 'Table Set', 'Sunbed', 'Swing'],
    'Patio': ['Lounge Set', 'Dining Set', 'Umbrella', 'Fire Pit']
  };

  const displaySections = [
    'Featured Products',
    'New Arrivals',
    'Best Sellers',
    'Clearance Sale',
    'Premium Collection',
    'Budget Friendly'
  ];

  const finishTypes = [
    'Glossy', 'Matte', 'Natural', 'Satin', 'Textured',
    'Polished', 'Distressed', 'Painted', 'Stained'
  ];

  const warrantyTypes = [
    'Manufacturer', 'Seller', 'No Warranty',
    'Extended Warranty', 'Lifetime'
  ];

  const warrantyDurations = [
    '30 days', '3 months', '6 months', '1 year',
    '2 years', '3 years', '5 years', 'Lifetime'
  ];

  const materials = [
    'Wood', 'Metal', 'Glass', 'Plastic', 'Fabric',
    'Leather', 'Marble', 'Granite', 'Bamboo', 'Rattan',
    'Wicker', 'MDF', 'Plywood', 'Particle Board'
  ];

  const saudiCities = [
    'Riyadh', 'Jeddah', 'Dammam', 'Mecca', 'Medina',
    'Khobar', 'Dhahran', 'Abha', 'Tabuk', 'Taif',
    'Buraidah', 'Khamis Mushait', 'Al Hofuf', 'Najran'
  ];

  const shippingCompanies = [
    'Aramex', 'SMSA', 'Naqel', 'DHL', 'FedEx',
    'UPS', 'Zajil', 'Self Delivery', 'Other'
  ];

  const colorOptions = [
    { name: 'White', value: '#FFFFFF' },
    { name: 'White Smoke', value: '#F5F5F5' },
    { name: 'Snow', value: '#FFFAFA' },
    { name: 'Ghost White', value: '#F8F8FF' },
    { name: 'Ivory', value: '#FFFFF0' }
  ];

  useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        sellerId: user.id || 'seller_001',
        sellerName: user.name || user.email || 'Sample Seller'
      }));
    }
  }, [user]);

  // Function to compress image
  const compressImage = (file: File, maxSizeMB = 1): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          // Calculate new dimensions
          const maxDimension = 1200;
          if (width > height && width > maxDimension) {
            height = (height * maxDimension) / width;
            width = maxDimension;
          } else if (height > maxDimension) {
            width = (width * maxDimension) / height;
            height = maxDimension;
          }
          
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          // Get compressed data URL
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.7);
          
          // Check size
          const sizeInMB = (compressedDataUrl.length * 3) / (4 * 1024 * 1024);
          if (sizeInMB > maxSizeMB) {
            // Further compress if needed
            canvas.toBlob(
              (blob) => {
                const newReader = new FileReader();
                newReader.onload = (e) => resolve(e.target?.result as string);
                newReader.onerror = reject;
                newReader.readAsDataURL(blob as Blob);
              },
              'image/jpeg',
              0.5
            );
          } else {
            resolve(compressedDataUrl);
          }
        };
        img.onerror = reject;
        img.src = event.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setErrors(prev => ({ ...prev, [name]: '' }));
    
    if (name === 'sellingPrice' || name === 'discountedPrice' || name === 'weight') {
      if (value === '' || /^\d*\.?\d*$/.test(value)) {
        setFormData(prev => ({ ...prev, [name]: value }));
      }
    } else if (name === 'stockQuantity') {
      const intValue = parseInt(value);
      if (!isNaN(intValue) && intValue >= 0) {
        setFormData(prev => ({ ...prev, [name]: intValue }));
      } else if (value === '') {
        setFormData(prev => ({ ...prev, [name]: 0 }));
      }
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleProductTypeChange = (type: 'ready' | 'customized') => {
    setFormData(prev => ({
      ...prev,
      productType: type,
      mainCategory: '',
      subCategory: ''
    }));
  };

  const handleLocationChange = (location: 'indoor' | 'outdoor') => {
    setFormData(prev => ({
      ...prev,
      location,
      mainCategory: '',
      subCategory: ''
    }));
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    const maxImages = formData.productType === 'customized' ? 5 : 10;
    if (formData.images.length + files.length > maxImages) {
      setErrors(prev => ({ ...prev, images: `Maximum ${maxImages} images allowed` }));
      return;
    }
    
    for (const file of Array.from(files)) {
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
      if (!validTypes.includes(file.type)) {
        alert(`Invalid file type: ${file.name}. Please upload JPEG, PNG, or WebP images.`);
        continue;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        alert(`File "${file.name}" exceeds 5MB limit. Compressing...`);
      }
      
      try {
        // Compress image before storing
        const compressedDataUrl = await compressImage(file, 0.5); // Compress to max 0.5MB
        
        const imageId = `img_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        // Store compressed image in temporary state
        setTempImages(prev => ({ ...prev, [imageId]: compressedDataUrl }));
        
        // Store only image ID in form data
        setFormData(prev => {
          const updatedImages = [...prev.images, imageId];
          if (prev.mainImage === '') {
            return { ...prev, images: updatedImages, mainImage: imageId };
          }
          return { ...prev, images: updatedImages };
        });
        
      } catch (error) {
        console.error('Error processing image:', error);
        alert(`Failed to process image: ${file.name}`);
      }
    }
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const validTypes = ['video/mp4', 'video/webm', 'video/ogg'];
    if (!validTypes.includes(file.type)) {
      alert('Please upload MP4, WebM, or OGG video files.');
      return;
    }
    
    if (file.size > 10 * 1024 * 1024) {
      alert('Video file exceeds 10MB limit. Please upload a smaller video.');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setTempVideo(dataUrl);
        setFormData(prev => ({ ...prev, videoUrl: `video_${formData.id}` }));
      }
    };
    reader.readAsDataURL(file);
    
    if (videoInputRef.current) {
      videoInputRef.current.value = '';
    }
  };

  const removeImage = (imageId: string) => {
    setFormData(prev => {
      const updatedImages = prev.images.filter(id => id !== imageId);
      let newMainImage = prev.mainImage;
      
      if (imageId === prev.mainImage) {
        newMainImage = updatedImages[0] || '';
      }
      
      return { ...prev, images: updatedImages, mainImage: newMainImage };
    });
    
    // Remove from temp storage
    setTempImages(prev => {
      const newTemp = { ...prev };
      delete newTemp[imageId];
      return newTemp;
    });
  };

  const setAsMainImage = (imageId: string) => {
    setFormData(prev => ({ ...prev, mainImage: imageId }));
  };

  const addVariant = () => {
    const newVariant: Variant = {
      id: `var_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type: '',
      option: '',
      price: formData.sellingPrice || '0',
      stock: formData.stockQuantity || 0,
      sku: `SKU${Date.now().toString().slice(-6)}_${Math.random().toString(36).substr(2, 3)}`,
      barcode: ''
    };
    
    setFormData(prev => ({
      ...prev,
      variants: [...prev.variants, newVariant]
    }));
  };

  const updateVariant = (id: string, field: keyof Variant, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      variants: prev.variants.map(variant =>
        variant.id === id ? { ...variant, [field]: value } : variant
      )
    }));
  };

  const removeVariant = (id: string) => {
    setFormData(prev => ({
      ...prev,
      variants: prev.variants.filter(variant => variant.id !== id)
    }));
  };

  const toggleCityDelivery = (city: string) => {
    setFormData(prev => {
      const existingCity = prev.availableCities.find(c => c.city === city);
      if (existingCity) {
        return {
          ...prev,
          availableCities: prev.availableCities.filter(c => c.city !== city)
        };
      } else {
        const newCity: CityDelivery = {
          city,
          available: true,
          freeDelivery: true,
          deliveryCost: '0',
          deliveryTime: '3-5 days',
          shippingCompany: 'Aramex'
        };
        return {
          ...prev,
          availableCities: [...prev.availableCities, newCity]
        };
      }
    });
  };

  const updateCityDelivery = (city: string, field: keyof CityDelivery, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      availableCities: prev.availableCities.map(c =>
        c.city === city ? { ...c, [field]: value } : c
      )
    }));
  };

  const handleNextStep = () => {
    const newErrors: Record<string, string> = {};
    
    switch (activeStep) {
      case 1:
        if (!formData.name.trim()) newErrors.name = 'Product name is required';
        if (!formData.mainCategory) newErrors.mainCategory = 'Main category is required';
        if (!formData.displaySection) newErrors.displaySection = 'Display section is required';
        break;
      case 2:
        if (formData.images.length < 3) {
          newErrors.images = 'At least 3 images are required';
        }
        if (!formData.mainImage) {
          newErrors.mainImage = 'Please select a main image';
        }
        break;
      case 5:
        if (!formData.sellingPrice) newErrors.sellingPrice = 'Selling price is required';
        if (parseFloat(formData.sellingPrice) <= 0) {
          newErrors.sellingPrice = 'Selling price must be greater than 0';
        }
        if (!formData.stockQuantity && formData.stockQuantity !== 0) {
          newErrors.stockQuantity = 'Stock quantity is required';
        }
        if (!formData.skuCode) newErrors.skuCode = 'SKU code is required';
        break;
    }
    
    setErrors(newErrors);
    if (Object.keys(newErrors).length === 0) {
      setActiveStep(prev => Math.min(7, prev + 1));
    }
  };

  const handlePrevStep = () => {
    setActiveStep(prev => Math.max(1, prev - 1));
  };

  const saveAsDraft = () => {
    // Create product without base64 images for draft
    const draftData = {
      ...formData,
      // Store image metadata only
      imageCount: formData.images.length,
      hasMainImage: !!formData.mainImage,
      hasVideo: !!tempVideo,
      status: 'draft',
      updatedAt: new Date().toISOString(),
      createdAt: new Date().toISOString()
    };

    try {
      const existingDrafts = JSON.parse(localStorage.getItem('productDrafts') || '[]');
      localStorage.setItem('productDrafts', JSON.stringify([...existingDrafts, draftData]));
      
      // Store compressed images separately if there's space
      try {
        const existingTempImages = JSON.parse(localStorage.getItem('tempImages') || '{}');
        const updatedTempImages = { ...existingTempImages, ...tempImages };
        if (tempVideo) {
          updatedTempImages[`video_${formData.id}`] = tempVideo;
        }
        localStorage.setItem('tempImages', JSON.stringify(updatedTempImages));
      } catch (imageError) {
        console.warn('Could not save images to draft:', imageError);
        // Continue without images
      }
      
      alert('Product saved as draft!');
      navigate('/seller/dashboard');
    } catch (error) {
      alert('Failed to save draft. Please try again.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Validation
      if (!formData.name.trim()) {
        setActiveStep(1);
        throw new Error('Product name is required');
      }
      
      if (formData.images.length < 3) {
        setActiveStep(2);
        throw new Error('At least 3 images are required');
      }
      
      if (!formData.sellingPrice || parseFloat(formData.sellingPrice) <= 0) {
        setActiveStep(5);
        throw new Error('Valid selling price is required');
      }

      if (typeof localStorage === 'undefined') {
        throw new Error('Local storage is not available in this browser.');
      }

      // Create clean product data WITHOUT base64 images
      const cleanFormData = {
        ...formData,
        // Store only image metadata, not base64
        imageCount: formData.images.length,
        hasMainImage: !!formData.mainImage,
        hasVideo: !!tempVideo,
        // Convert numeric values
        sellingPrice: parseFloat(formData.sellingPrice).toString(),
        discountedPrice: formData.discountedPrice ? parseFloat(formData.discountedPrice).toString() : '',
        stockQuantity: formData.stockQuantity || 0,
        sellerId: user?.id || 'seller_001',
        sellerName: user?.name || user?.email || 'Sample Seller',
        updatedAt: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        status: 'active',
        rating: 0,
        orders: 0,
        reviews: [],
        isTopSeller: false
      };

      try {
        // Save product metadata
        const existingProducts = JSON.parse(localStorage.getItem('furnitureProducts') || '[]');
        const updatedProducts = [...existingProducts, cleanFormData];
        localStorage.setItem('furnitureProducts', JSON.stringify(updatedProducts));

        // Try to save compressed images separately (optional)
        try {
          const existingMedia = JSON.parse(localStorage.getItem('productMedia') || '{}');
          
          // Store only first 3 compressed images to save space
          const imagesToSave: TempImageStorage = {};
          formData.images.slice(0, 3).forEach(imageId => {
            if (tempImages[imageId]) {
              imagesToSave[imageId] = tempImages[imageId];
            }
          });
          
          // Store main image if different
          if (formData.mainImage && tempImages[formData.mainImage]) {
            imagesToSave[formData.mainImage] = tempImages[formData.mainImage];
          }
          
          // Store video if exists
          if (tempVideo) {
            imagesToSave[`video_${formData.id}`] = tempVideo;
          }
          
          const updatedMedia = {
            ...existingMedia,
            [formData.id]: imagesToSave
          };
          
          localStorage.setItem('productMedia', JSON.stringify(updatedMedia));
        } catch (mediaError) {
          console.warn('Could not save media files:', mediaError);
          // Product is still saved without media
        }

        // Clean up drafts
        const existingDrafts = JSON.parse(localStorage.getItem('productDrafts') || '[]');
        const remainingDrafts = existingDrafts.filter((draft: any) => draft.id !== formData.id);
        localStorage.setItem('productDrafts', JSON.stringify(remainingDrafts));

        alert(`Product "${formData.name}" added successfully!`);
        navigate('/seller/dashboard');

      } catch (storageError: any) {
        console.error('Storage error:', storageError);
        
        if (storageError.name === 'QuotaExceededError') {
          // Try to save without images
          const cleanFormDataNoImages = {
            ...cleanFormData,
            images: [],
            mainImage: '',
            videoUrl: ''
          };
          
          const existingProducts = JSON.parse(localStorage.getItem('furnitureProducts') || '[]');
          localStorage.setItem('furnitureProducts', JSON.stringify([...existingProducts, cleanFormDataNoImages]));
          
          alert(`Product "${formData.name}" added without images due to storage limits.`);
          navigate('/seller/dashboard');
        } else {
          throw new Error('Failed to save product. Please try again.');
        }
      }

    } catch (error: any) {
      console.error('Submit error:', error);
      alert(error.message || 'Failed to add product. Please check all required fields.');
    } finally {
      setLoading(false);
    }
  };

  // Helper function to get image URL from temp storage
  const getImageUrl = (imageId: string) => {
    return tempImages[imageId] || '';
  };

  const renderStep1 = () => (
    <div className="space-y-8">
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center space-x-2 text-gray-700 mb-4">
          <Info className="w-5 h-5" />
          <span className="font-medium text-base">Basic Product Information</span>
        </div>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Product Type *
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => handleProductTypeChange('ready')}
              className={`p-4 border-2 rounded-xl text-center transition-all text-sm ${
                formData.productType === 'ready'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <Package className={`w-10 h-10 mx-auto mb-2 ${
                formData.productType === 'ready' ? 'text-blue-600' : 'text-gray-400'
              }`} />
              <h3 className="font-semibold text-base mb-1">Ready Made Product</h3>
              <p className="text-xs text-gray-600">Pre-built furniture items</p>
            </button>
            
            <button
              type="button"
              onClick={() => handleProductTypeChange('customized')}
              className={`p-4 border-2 rounded-xl text-center transition-all text-sm ${
                formData.productType === 'customized'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <Settings className={`w-10 h-10 mx-auto mb-2 ${
                formData.productType === 'customized' ? 'text-blue-600' : 'text-gray-400'
              }`} />
              <h3 className="font-semibold text-base mb-1">Customized Product</h3>
              <p className="text-xs text-gray-600">Custom built furniture</p>
            </button>
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Product Location *
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => handleLocationChange('indoor')}
              className={`p-4 border-2 rounded-xl text-center transition-all text-sm ${
                formData.location === 'indoor'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <Home className={`w-10 h-10 mx-auto mb-2 ${
                formData.location === 'indoor' ? 'text-blue-600' : 'text-gray-400'
              }`} />
              <h3 className="font-semibold text-base mb-1">Indoor Furniture</h3>
              <p className="text-xs text-gray-600">For indoor use</p>
            </button>
            
            <button
              type="button"
              onClick={() => handleLocationChange('outdoor')}
              className={`p-4 border-2 rounded-xl text-center transition-all text-sm ${
                formData.location === 'outdoor'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <Building className={`w-10 h-10 mx-auto mb-2 ${
                formData.location === 'outdoor' ? 'text-blue-600' : 'text-gray-400'
              }`} />
              <h3 className="font-semibold text-base mb-1">Outdoor Furniture</h3>
              <p className="text-xs text-gray-600">For outdoor use</p>
            </button>
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Product Name *
          </label>
          <input
            type="text"
            name="name"
            required
            className={`w-full px-4 py-2 border rounded-lg focus:ring-1 focus:ring-blue-500 focus:border-transparent text-sm ${
              errors.name ? 'border-red-500' : 'border-gray-300'
            }`}
            value={formData.name}
            onChange={handleInputChange}
            placeholder="Enter product name"
          />
          {errors.name && <p className="mt-1 text-xs text-red-500">{errors.name}</p>}
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Short Description *
          </label>
          <textarea
            name="shortDescription"
            required
            rows={2}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-1 focus:ring-blue-500 focus:border-transparent text-sm"
            value={formData.shortDescription}
            onChange={handleInputChange}
            placeholder="Brief description for product listings"
            maxLength={200}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Full Description *
          </label>
          <textarea
            name="description"
            required
            rows={3}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-1 focus:ring-blue-500 focus:border-transparent text-sm"
            value={formData.description}
            onChange={handleInputChange}
            placeholder="Detailed product description"
          />
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center space-x-2 text-gray-700 mb-6">
          <Layers className="w-5 h-5" />
          <span className="font-medium text-base">Product Categories</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Main Category *
            </label>
            <select
              name="mainCategory"
              required
              className={`w-full px-3 py-2 border rounded-lg focus:ring-1 focus:ring-blue-500 focus:border-transparent text-sm ${
                errors.mainCategory ? 'border-red-500' : 'border-gray-300'
              }`}
              value={formData.mainCategory}
              onChange={handleInputChange}
            >
              <option value="">Select Category</option>
              {mainCategories[formData.productType][formData.location]?.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
            {errors.mainCategory && <p className="mt-1 text-xs text-red-500">{errors.mainCategory}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Sub Category
            </label>
            <select
              name="subCategory"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-1 focus:ring-blue-500 focus:border-transparent text-sm"
              value={formData.subCategory}
              onChange={handleInputChange}
              disabled={!formData.mainCategory}
            >
              <option value="">Select Sub-category</option>
              {formData.mainCategory && subCategories[formData.mainCategory]?.map(sub => (
                <option key={sub} value={sub}>{sub}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Display Section *
            </label>
            <select
              name="displaySection"
              required
              className={`w-full px-3 py-2 border rounded-lg focus:ring-1 focus:ring-blue-500 focus:border-transparent text-sm ${
                errors.displaySection ? 'border-red-500' : 'border-gray-300'
              }`}
              value={formData.displaySection}
              onChange={handleInputChange}
            >
              <option value="">Select Section</option>
              {displaySections.map(section => (
                <option key={section} value={section}>{section}</option>
              ))}
            </select>
            {errors.displaySection && <p className="mt-1 text-xs text-red-500">{errors.displaySection}</p>}
          </div>
        </div>
      </div>

      {formData.productType === 'customized' && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 text-yellow-700 mb-4">
            <Clock className="w-5 h-5" />
            <span className="font-medium text-sm">Customization Details</span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Customization Time *
              </label>
              <select
                name="customizationTime"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-1 focus:ring-blue-500 focus:border-transparent text-sm"
                value={formData.customizationTime}
                onChange={handleInputChange}
              >
                <option value="1-2 weeks">1-2 weeks</option>
                <option value="2-3 weeks">2-3 weeks</option>
                <option value="3-4 weeks">3-4 weeks</option>
                <option value="1-2 months">1-2 months</option>
                <option value="Custom">Custom</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Materials Used *
              </label>
              <select
                multiple
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-1 focus:ring-blue-500 focus:border-transparent text-sm"
                value={formData.materialsUsed}
                onChange={(e) => {
                  const selected = Array.from(e.target.selectedOptions, option => option.value);
                  setFormData(prev => ({ ...prev, materialsUsed: selected }));
                }}
                size={2}
              >
                {materials.map(mat => (
                  <option key={mat} value={mat}>{mat}</option>
                ))}
              </select>
              <p className="text-xs text-gray-500 mt-1">Hold Ctrl/Cmd to select multiple</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-8">
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center space-x-2 text-gray-700 mb-4">
          <ImageIcon className="w-5 h-5" />
          <span className="font-medium text-base">Product Media</span>
        </div>
        <p className="text-xs text-gray-600 mb-6">
          Add product images and video. Minimum 3 images required. Images are compressed to save space.
        </p>

        <div className="mb-8">
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Upload Images *
            <span className="ml-2 text-gray-500 text-xs">
              ({formData.images.length}/{formData.productType === 'customized' ? 5 : 10} images)
            </span>
          </label>
          
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border border-dashed border-gray-300 rounded-xl p-6 text-center cursor-pointer hover:border-blue-500 transition-colors"
          >
            <Upload className="w-10 h-10 text-gray-400 mx-auto mb-4" />
            <p className="text-base font-medium text-gray-700 mb-2">
              Click to upload images
            </p>
            <p className="text-xs text-gray-500 mb-4">
              Upload JPEG, PNG, or WebP images (max 5MB each, will be compressed)
            </p>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
          
          {errors.images && (
            <p className="mt-2 text-xs text-red-500">{errors.images}</p>
          )}
        </div>

        {formData.images.length > 0 && (
          <div className="mb-8">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Select Main Image *
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
              {formData.images.map((imageId, index) => {
                const imageUrl = getImageUrl(imageId);
                return (
                  <div key={imageId} className="relative group">
                    <div
                      className={`relative w-full h-20 rounded-lg overflow-hidden cursor-pointer border ${
                        formData.mainImage === imageId ? 'border-blue-500 ring-1 ring-blue-200' : 'border-gray-200'
                      }`}
                      onClick={() => setAsMainImage(imageId)}
                    >
                      {imageUrl ? (
                        <img
                          src={imageUrl}
                          alt={`Product ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                          <ImageIcon className="w-6 h-6 text-gray-400" />
                        </div>
                      )}
                      {formData.mainImage === imageId && (
                        <div className="absolute inset-0 bg-blue-500 bg-opacity-20 flex items-center justify-center">
                          <Check className="w-6 h-6 text-white" />
                        </div>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => removeImage(imageId)}
                      className="absolute -top-1 -right-1 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                    {formData.mainImage === imageId && (
                      <div className="absolute bottom-1 left-1 bg-blue-500 text-white text-xs px-1 py-0.5 rounded">
                        Main
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            {errors.mainImage && (
              <p className="mt-2 text-xs text-red-500">{errors.mainImage}</p>
            )}
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Product Video (Optional)
          </label>
          
          {tempVideo ? (
            <div className="relative">
              <video
                src={tempVideo}
                controls
                className="w-full rounded-lg"
              />
              <button
                type="button"
                onClick={() => {
                  setTempVideo('');
                  setFormData(prev => ({ ...prev, videoUrl: '' }));
                }}
                className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          ) : (
            <div 
              onClick={() => videoInputRef.current?.click()}
              className="border border-dashed border-gray-300 rounded-xl p-6 text-center cursor-pointer hover:border-blue-500 transition-colors"
            >
              <Video className="w-10 h-10 text-gray-400 mx-auto mb-4" />
              <p className="text-base font-medium text-gray-700 mb-2">
                Click to upload video
              </p>
              <p className="text-xs text-gray-500 mb-4">
                Upload MP4, WebM, or OGG videos (max 10MB)
              </p>
              <input
                ref={videoInputRef}
                type="file"
                accept="video/*"
                onChange={handleVideoUpload}
                className="hidden"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-8">
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center space-x-2 text-gray-700 mb-4">
          <Ruler className="w-5 h-5" />
          <span className="font-medium text-base">Technical Specifications</span>
        </div>

        <div className="mb-8">
          <h4 className="font-medium text-gray-700 mb-4 text-sm">Dimensions</h4>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-2">Length</label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                value={formData.dimensions.length}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  dimensions: { ...prev.dimensions, length: e.target.value }
                }))}
                placeholder="0.0"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-2">Width</label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                value={formData.dimensions.width}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  dimensions: { ...prev.dimensions, width: e.target.value }
                }))}
                placeholder="0.0"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-2">Height</label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                value={formData.dimensions.height}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  dimensions: { ...prev.dimensions, height: e.target.value }
                }))}
                placeholder="0.0"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-2">Unit</label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                value={formData.dimensions.unit}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  dimensions: { ...prev.dimensions, unit: e.target.value }
                }))}
              >
                <option value="cm">cm</option>
                <option value="m">m</option>
                <option value="inch">inch</option>
                <option value="ft">ft</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-2">Weight (kg)</label>
              <input
                type="text"
                name="weight"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                value={formData.weight}
                onChange={handleInputChange}
                placeholder="0.0"
              />
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h4 className="font-medium text-gray-700 mb-4 text-sm flex items-center">
            <Palette className="w-4 h-4 mr-2" />
            Colors
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-2">Primary Color</label>
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <input
                    type="color"
                    className="w-12 h-12 cursor-pointer rounded-lg border border-gray-300"
                    value={formData.primaryColor}
                    onChange={(e) => setFormData(prev => ({ ...prev, primaryColor: e.target.value }))}
                  />
                  <div className="absolute -bottom-6 left-0 right-0 text-xs text-center">
                    {colorOptions.find(c => c.value === formData.primaryColor)?.name || 'Custom'}
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium">{formData.primaryColor}</p>
                  <p className="text-xs text-gray-500">Click to change</p>
                </div>
              </div>
            </div>
            
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-2">Available Colors</label>
              <div className="flex flex-wrap gap-2">
                {colorOptions.map((color) => (
                  <button
                    key={color.value}
                    type="button"
                    onClick={() => {
                      if (!formData.availableColors.includes(color.value)) {
                        setFormData(prev => ({
                          ...prev,
                          availableColors: [...prev.availableColors, color.value]
                        }));
                      }
                    }}
                    className="relative group"
                  >
                    <div
                      className="w-8 h-8 rounded-lg border border-gray-300"
                      style={{ backgroundColor: color.value }}
                      title={color.name}
                    />
                    <div className="absolute -bottom-6 left-0 right-0 text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                      {color.name}
                    </div>
                  </button>
                ))}
                {formData.availableColors.map((color, index) => (
                  <div key={index} className="relative group">
                    <div
                      className="w-8 h-8 rounded-lg border border-gray-300"
                      style={{ backgroundColor: color }}
                    />
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({
                        ...prev,
                        availableColors: prev.availableColors.filter((_, i) => i !== index)
                      }))}
                      className="absolute -top-1 -right-1 bg-red-500 text-white p-0.5 rounded-full opacity-0 group-hover:opacity-100"
                    >
                      <X className="w-2 h-2" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">
              Material
            </label>
            <select
              name="material"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              value={formData.material}
              onChange={handleInputChange}
            >
              <option value="">Select Material</option>
              {materials.map(mat => (
                <option key={mat} value={mat}>{mat}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">
              Finish Type
            </label>
            <select
              name="finishType"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              value={formData.finishType}
              onChange={handleInputChange}
            >
              <option value="">Select Finish</option>
              {finishTypes.map(finish => (
                <option key={finish} value={finish}>{finish}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">Warranty Type</label>
            <select
              name="warrantyType"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              value={formData.warrantyType}
              onChange={handleInputChange}
            >
              {warrantyTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">Warranty Duration</label>
            <select
              name="warrantyDuration"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              value={formData.warrantyDuration}
              onChange={handleInputChange}
            >
              {warrantyDurations.map(duration => (
                <option key={duration} value={duration}>{duration}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-8">
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center space-x-2 text-gray-700 mb-4">
          <Layers className="w-5 h-5" />
          <span className="font-medium text-base">Product Variants</span>
        </div>

        <div className="mb-6">
          <label className="flex items-center space-x-3 cursor-pointer">
            <div className="relative">
              <input
                type="checkbox"
                checked={formData.hasVariants}
                onChange={(e) => setFormData(prev => ({ ...prev, hasVariants: e.target.checked }))}
                className="sr-only"
              />
              <div className={`block w-12 h-6 rounded-full transition-colors ${
                formData.hasVariants ? 'bg-blue-600' : 'bg-gray-300'
              }`} />
              <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${
                formData.hasVariants ? 'transform translate-x-6' : ''
              }`} />
            </div>
            <span className="text-gray-700 font-medium text-sm">This product has variants</span>
          </label>
        </div>

        {formData.hasVariants && (
          <div className="space-y-4">
            {formData.variants.length === 0 ? (
              <div className="text-center py-6 border border-dashed border-gray-300 rounded-lg">
                <Package className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500 text-sm">No variants added yet</p>
                <p className="text-xs text-gray-400 mt-1">Add variants to create different options</p>
              </div>
            ) : (
              formData.variants.map((variant, index) => (
                <div key={variant.id} className="border border-gray-200 rounded-lg p-3 bg-gray-50">
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="font-medium text-gray-700 text-sm">Variant #{index + 1}</h4>
                    <button
                      type="button"
                      onClick={() => removeVariant(variant.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Type</label>
                      <select
                        value={variant.type}
                        onChange={(e) => updateVariant(variant.id, 'type', e.target.value)}
                        className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                      >
                        <option value="">Select Type</option>
                        <option value="Color">Color</option>
                        <option value="Size">Size</option>
                        <option value="Material">Material</option>
                        <option value="Style">Style</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Option</label>
                      <input
                        type="text"
                        value={variant.option}
                        onChange={(e) => updateVariant(variant.id, 'option', e.target.value)}
                        className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                        placeholder="e.g., Red, Large, Wood"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Price (SAR)</label>
                      <input
                        type="text"
                        value={variant.price}
                        onChange={(e) => updateVariant(variant.id, 'price', e.target.value)}
                        className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                        placeholder="0.00"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Stock</label>
                      <input
                        type="number"
                        value={variant.stock}
                        onChange={(e) => updateVariant(variant.id, 'stock', parseInt(e.target.value))}
                        className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                        min="0"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">SKU</label>
                      <input
                        type="text"
                        value={variant.sku}
                        onChange={(e) => updateVariant(variant.id, 'sku', e.target.value)}
                        className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Barcode (Optional)</label>
                      <input
                        type="text"
                        value={variant.barcode || ''}
                        onChange={(e) => updateVariant(variant.id, 'barcode', e.target.value)}
                        className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>
                </div>
              ))
            )}
            
            <button
              type="button"
              onClick={addVariant}
              className="w-full py-2 border border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors text-sm"
            >
              <Plus className="w-4 h-4 inline mr-2" />
              Add New Variant
            </button>
          </div>
        )}
      </div>
    </div>
  );

  const renderStep5 = () => (
    <div className="space-y-8">
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center space-x-2 text-gray-700 mb-4">
          <DollarSign className="w-5 h-5" />
          <span className="font-medium text-base">Pricing & Inventory</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">
              Selling Price (SAR) *
            </label>
            <input
              type="text"
              name="sellingPrice"
              required
              className={`w-full px-3 py-2 border rounded-lg text-sm ${
                errors.sellingPrice ? 'border-red-500' : 'border-gray-300'
              }`}
              value={formData.sellingPrice}
              onChange={handleInputChange}
              placeholder="0.00"
            />
            {errors.sellingPrice && <p className="mt-1 text-xs text-red-500">{errors.sellingPrice}</p>}
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">
              Discounted Price (SAR) - Optional
            </label>
            <input
              type="text"
              name="discountedPrice"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              value={formData.discountedPrice}
              onChange={handleInputChange}
              placeholder="0.00"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">
              Stock Quantity *
            </label>
            <input
              type="number"
              name="stockQuantity"
              required
              min="0"
              className={`w-full px-3 py-2 border rounded-lg text-sm ${
                errors.stockQuantity ? 'border-red-500' : 'border-gray-300'
              }`}
              value={formData.stockQuantity}
              onChange={handleInputChange}
            />
            {errors.stockQuantity && <p className="mt-1 text-xs text-red-500">{errors.stockQuantity}</p>}
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">
              SKU Code *
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                name="skuCode"
                required
                className={`w-full px-3 py-2 border rounded-lg text-sm ${
                  errors.skuCode ? 'border-red-500' : 'border-gray-300'
                }`}
                value={formData.skuCode}
                onChange={handleInputChange}
              />
              <button
                type="button"
                onClick={() => setFormData(prev => ({
                  ...prev,
                  skuCode: `SKU${Date.now().toString().slice(-6)}`
                }))}
                className="px-2 py-1.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-xs"
              >
                Generate
              </button>
            </div>
            {errors.skuCode && <p className="mt-1 text-xs text-red-500">{errors.skuCode}</p>}
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-gray-700 mb-2">
              Barcode (Optional)
            </label>
            <div className="flex items-center space-x-3">
              <Barcode className="w-5 h-5 text-gray-400" />
              <input
                type="text"
                name="barcode"
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm"
                value={formData.barcode}
                onChange={handleInputChange}
                placeholder="Enter barcode number"
              />
            </div>
          </div>
        </div>

        {formData.discountedPrice && parseFloat(formData.discountedPrice) < parseFloat(formData.sellingPrice) && (
          <div className="mt-6 bg-green-50 border border-green-200 rounded-lg p-3">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <span className="text-gray-600 text-sm">Original Price:</span>
                <span className="ml-2 text-gray-500 line-through text-sm">{formData.sellingPrice} SAR</span>
              </div>
              <div>
                <span className="text-gray-600 text-sm">Discounted Price:</span>
                <span className="ml-2 font-bold text-green-600 text-sm">{formData.discountedPrice} SAR</span>
              </div>
              <div className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs">
                {Math.round((1 - parseFloat(formData.discountedPrice) / parseFloat(formData.sellingPrice)) * 100)}% OFF
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const renderStep6 = () => (
    <div className="space-y-8">
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center space-x-2 text-gray-700 mb-6">
          <MapPin className="w-5 h-5" />
          <span className="font-medium text-base">Available Cities & Delivery</span>
        </div>

        <div className="mb-8">
          <h4 className="font-medium text-gray-700 mb-4 text-sm">Select Available Cities</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
            {saudiCities.map(city => {
              const isSelected = formData.availableCities.some(c => c.city === city);
              return (
                <button
                  key={city}
                  type="button"
                  onClick={() => toggleCityDelivery(city)}
                  className={`px-3 py-2 rounded-lg border text-center transition-colors text-sm ${
                    isSelected
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {city}
                  {isSelected && (
                    <Check className="w-3 h-3 inline ml-1" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {formData.availableCities.length > 0 && (
          <div className="mb-8">
            <h4 className="font-medium text-gray-700 mb-4 text-sm">Delivery Details by City</h4>
            <div className="space-y-3">
              {formData.availableCities.map((city, index) => (
                <div key={city.city} className="border border-gray-200 rounded-lg p-3 bg-gray-50">
                  <h5 className="font-medium text-gray-700 mb-2 text-sm">{city.city}</h5>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    <div>
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={city.available}
                          onChange={(e) => updateCityDelivery(city.city, 'available', e.target.checked)}
                          className="text-sm"
                        />
                        <span className="text-xs text-gray-700">Available</span>
                      </label>
                    </div>
                    
                    <div>
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={city.freeDelivery}
                          onChange={(e) => updateCityDelivery(city.city, 'freeDelivery', e.target.checked)}
                          className="text-sm"
                        />
                        <span className="text-xs text-gray-700">Free Delivery</span>
                      </label>
                    </div>
                    
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Delivery Cost (SAR)</label>
                      <input
                        type="text"
                        value={city.deliveryCost}
                        onChange={(e) => updateCityDelivery(city.city, 'deliveryCost', e.target.value)}
                        className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                        disabled={city.freeDelivery}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Delivery Time</label>
                      <input
                        type="text"
                        value={city.deliveryTime}
                        onChange={(e) => updateCityDelivery(city.city, 'deliveryTime', e.target.value)}
                        className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                        placeholder="e.g., 3-5 days"
                      />
                    </div>
                  </div>
                  
                  <div className="mt-2">
                    <label className="block text-xs font-medium text-gray-700 mb-1">Shipping Company</label>
                    <select
                      value={city.shippingCompany || ''}
                      onChange={(e) => updateCityDelivery(city.city, 'shippingCompany', e.target.value)}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                    >
                      <option value="">Select Company</option>
                      {shippingCompanies.map(company => (
                        <option key={company} value={company}>{company}</option>
                      ))}
                    </select>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mb-8">
          <h4 className="font-medium text-gray-700 mb-4 text-sm">Shipping Options</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-gray-200 rounded-lg p-3">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <TruckIcon className="w-4 h-4 text-blue-600" />
                  <h5 className="font-medium text-sm">Within City Delivery</h5>
                </div>
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.shippingOptions.withinCity.available}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      shippingOptions: {
                        ...prev.shippingOptions,
                        withinCity: {
                          ...prev.shippingOptions.withinCity,
                          available: e.target.checked
                        }
                      }
                    }))}
                    className="text-sm"
                  />
                  <span className="text-xs text-gray-600">Available</span>
                </label>
              </div>
              
              <div className="space-y-2">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Cost (SAR)</label>
                  <input
                    type="text"
                    value={formData.shippingOptions.withinCity.cost}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      shippingOptions: {
                        ...prev.shippingOptions,
                        withinCity: {
                          ...prev.shippingOptions.withinCity,
                          cost: e.target.value
                        }
                      }
                    }))}
                    className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                    disabled={!formData.shippingOptions.withinCity.available}
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Delivery Time</label>
                  <input
                    type="text"
                    value={formData.shippingOptions.withinCity.time}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      shippingOptions: {
                        ...prev.shippingOptions,
                        withinCity: {
                          ...prev.shippingOptions.withinCity,
                          time: e.target.value
                        }
                      }
                    }))}
                    className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                    disabled={!formData.shippingOptions.withinCity.available}
                    placeholder="e.g., 1-2 days"
                  />
                </div>
              </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-3">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Truck className="w-4 h-4 text-blue-600" />
                  <h5 className="font-medium text-sm">Outside City Delivery</h5>
                </div>
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.shippingOptions.outsideCity.available}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      shippingOptions: {
                        ...prev.shippingOptions,
                        outsideCity: {
                          ...prev.shippingOptions.outsideCity,
                          available: e.target.checked
                        }
                      }
                    }))}
                    className="text-sm"
                  />
                  <span className="text-xs text-gray-600">Available</span>
                </label>
              </div>
              
              <div className="space-y-2">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Cost (SAR)</label>
                  <input
                    type="text"
                    value={formData.shippingOptions.outsideCity.cost}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      shippingOptions: {
                        ...prev.shippingOptions,
                        outsideCity: {
                          ...prev.shippingOptions.outsideCity,
                          cost: e.target.value
                        }
                      }
                    }))}
                    className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                    disabled={!formData.shippingOptions.outsideCity.available}
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Delivery Time</label>
                  <input
                    type="text"
                    value={formData.shippingOptions.outsideCity.time}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      shippingOptions: {
                        ...prev.shippingOptions,
                        outsideCity: {
                          ...prev.shippingOptions.outsideCity,
                          time: e.target.value
                        }
                      }
                    }))}
                    className="w-full px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                    disabled={!formData.shippingOptions.outsideCity.available}
                    placeholder="e.g., 3-5 days"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border border-gray-200 rounded-lg p-3 bg-gray-50">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <Settings className="w-4 h-4 text-blue-600" />
              <h5 className="font-medium text-sm">Installation Service</h5>
            </div>
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.installationAvailable}
                onChange={(e) => setFormData(prev => ({ ...prev, installationAvailable: e.target.checked }))}
                className="text-sm"
              />
              <span className="text-xs text-gray-600">Available</span>
            </label>
          </div>
          
          {formData.installationAvailable && (
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Installation Fee (SAR)</label>
              <input
                type="text"
                value={formData.installationFee}
                onChange={(e) => setFormData(prev => ({ ...prev, installationFee: e.target.value }))}
                className="w-full md:w-1/3 px-2 py-1.5 border border-gray-300 rounded-lg text-sm"
                placeholder="0.00"
              />
              <p className="text-xs text-gray-500 mt-1">Enter 0 for free installation</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderStep7 = () => (
    <div className="space-y-8">
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center space-x-2 text-gray-700 mb-6">
          <Shield className="w-5 h-5" />
          <span className="font-medium text-base">Return Policy & Warranty</span>
        </div>

        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-medium text-gray-700 text-sm">Return Policy</h4>
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.returnPolicy.allowed}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  returnPolicy: {
                    ...prev.returnPolicy,
                    allowed: e.target.checked
                  }
                }))}
                className="text-sm"
              />
              <span className="text-xs text-gray-600">Returns Allowed</span>
            </label>
          </div>

          {formData.returnPolicy.allowed && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-2">Return Period</label>
                <select
                  value={formData.returnPolicy.period}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    returnPolicy: {
                      ...prev.returnPolicy,
                      period: e.target.value
                    }
                  }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                >
                  <option value="7 days">7 days</option>
                  <option value="14 days">14 days</option>
                  <option value="30 days">30 days</option>
                  <option value="60 days">60 days</option>
                  <option value="No returns">No returns</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-2">Return Fee (SAR)</label>
                <input
                  type="text"
                  value={formData.returnPolicy.fee}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    returnPolicy: {
                      ...prev.returnPolicy,
                      fee: e.target.value
                    }
                  }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  placeholder="0.00"
                />
                <p className="text-xs text-gray-500 mt-1">Enter 0 for free returns</p>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-2">Return Conditions</label>
                <div className="space-y-2">
                  {formData.returnPolicy.conditions.map((condition, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-gray-50 border border-gray-200 rounded">
                      <span className="text-xs">{condition}</span>
                      <button
                        type="button"
                        onClick={() => setFormData(prev => ({
                          ...prev,
                          returnPolicy: {
                            ...prev.returnPolicy,
                            conditions: prev.returnPolicy.conditions.filter((_, i) => i !== index)
                          }
                        }))}
                        className="text-red-500 hover:text-red-700"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => {
                      const newCondition = prompt('Enter a new return condition:');
                      if (newCondition) {
                        setFormData(prev => ({
                          ...prev,
                          returnPolicy: {
                            ...prev.returnPolicy,
                            conditions: [...prev.returnPolicy.conditions, newCondition]
                          }
                        }));
                      }
                    }}
                    className="w-full py-2 border border-dashed border-gray-300 rounded hover:border-blue-500 text-gray-500 hover:text-blue-500 text-xs"
                  >
                    <Plus className="w-3 h-3 inline mr-1" />
                    Add Condition
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 text-yellow-700 mb-4">
            <Shield className="w-4 h-4" />
            <span className="font-medium text-sm">Warranty Details</span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-xs font-medium text-gray-700">Warranty Type</p>
              <p className="text-sm font-semibold mt-1">{formData.warrantyType}</p>
            </div>
            
            <div>
              <p className="text-xs font-medium text-gray-700">Warranty Duration</p>
              <p className="text-sm font-semibold mt-1">{formData.warrantyDuration}</p>
            </div>
          </div>
          
          <div className="mt-3">
            <p className="text-xs text-gray-600">
              {formData.warrantyType === 'No Warranty' 
                ? 'This product is sold without any warranty.'
                : `This product comes with ${formData.warrantyType.toLowerCase()} warranty for ${formData.warrantyDuration}.`}
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderStepContent = () => {
    switch (activeStep) {
      case 1:
        return renderStep1();
      case 2:
        return renderStep2();
      case 3:
        return renderStep3();
      case 4:
        return renderStep4();
      case 5:
        return renderStep5();
      case 6:
        return renderStep6();
      case 7:
        return renderStep7();
      default:
        return renderStep1();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => navigate('/seller/dashboard')}
              className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 text-sm"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="font-medium">Back to Dashboard</span>
            </button>
            <div className="text-xs text-gray-500">
              Seller: <span className="font-medium">{formData.sellerName}</span>
              <span className="ml-3 px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">
                {formData.productType === 'customized' ? 'Customized' : 'Ready Made'} - {formData.location}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-800">Add New Product</h1>
          <p className="text-gray-600 mt-1 text-sm">
            Complete all sections to add your product. Fields marked with * are required.
            Images are compressed to save storage space.
          </p>
        </div>

        <div className="mb-6 overflow-x-auto">
          <div className="flex items-center justify-between min-w-max">
            {[
              { num: 1, label: 'Basic Info' },
              { num: 2, label: 'Media' },
              { num: 3, label: 'Specifications' },
              { num: 4, label: 'Variants' },
              { num: 5, label: 'Pricing' },
              { num: 6, label: 'Delivery' },
              { num: 7, label: 'Policy' }
            ].map((step) => (
              <React.Fragment key={step.num}>
                <div className="flex items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold border text-sm ${
                      activeStep >= step.num
                        ? 'bg-blue-600 border-blue-600 text-white'
                        : 'bg-white border-gray-300 text-gray-400'
                    }`}
                  >
                    {step.num}
                  </div>
                  <div className="ml-2">
                    <div className={`font-medium text-xs ${activeStep >= step.num ? 'text-gray-800' : 'text-gray-400'}`}>
                      {step.label}
                    </div>
                  </div>
                </div>
                {step.num < 7 && (
                  <div
                    className={`h-0.5 mx-3 w-12 ${
                      activeStep > step.num ? 'bg-blue-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-6">
          <form onSubmit={handleSubmit}>
            <div className="p-4">
              {renderStepContent()}
            </div>

            <div className="border-t bg-gray-50 px-4 py-3">
              <div className="flex items-center justify-between">
                <div>
                  {activeStep > 1 && (
                    <button
                      type="button"
                      onClick={handlePrevStep}
                      className="px-4 py-1.5 border border-gray-300 text-gray-700 rounded hover:bg-gray-100 font-medium text-sm"
                    >
                      Previous
                    </button>
                  )}
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={saveAsDraft}
                    className="px-4 py-1.5 border border-gray-300 text-gray-700 rounded hover:bg-gray-100 font-medium text-sm"
                  >
                    Save as Draft
                  </button>

                  {activeStep < 7 ? (
                    <button
                      type="button"
                      onClick={handleNextStep}
                      className="px-4 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium text-sm"
                    >
                      Next Step
                    </button>
                  ) : (
                    <button
                      type="submit"
                      disabled={loading}
                      className="px-4 py-1.5 bg-green-600 text-white rounded hover:bg-green-700 font-medium text-sm disabled:bg-gray-400 flex items-center space-x-2"
                    >
                      {loading ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          <span className="text-sm">Adding Product...</span>
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4" />
                          <span className="text-sm">Add Product to Marketplace</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </form>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-3">
            <div className="flex items-center space-x-2">
              <div className="bg-blue-100 p-1.5 rounded-lg">
                <FileText className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <div className="text-xs text-gray-500">Product Type</div>
                <div className="font-semibold text-sm capitalize">{formData.productType}</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-3">
            <div className="flex items-center space-x-2">
              <div className="bg-green-100 p-1.5 rounded-lg">
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <div className="text-xs text-gray-500">Price</div>
                <div className="font-semibold text-sm">
                  {formData.sellingPrice ? `${formData.sellingPrice} SAR` : 'Not set'}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-3">
            <div className="flex items-center space-x-2">
              <div className="bg-purple-100 p-1.5 rounded-lg">
                <ImageIcon className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <div className="text-xs text-gray-500">Images</div>
                <div className="font-semibold text-sm">
                  {formData.images.length} / {formData.productType === 'customized' ? 5 : 10}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-3">
            <div className="flex items-center space-x-2">
              <div className="bg-orange-100 p-1.5 rounded-lg">
                <MapPin className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <div className="text-xs text-gray-500">Available Cities</div>
                <div className="font-semibold text-sm">{formData.availableCities.length}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddProduct;