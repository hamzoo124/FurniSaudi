import React, { useState, useEffect } from 'react';
import {
  AiOutlineArrowLeft,
  AiOutlineDownload,
  AiOutlinePrinter,
  AiOutlineMail,
  AiOutlineEdit,
  AiOutlineCheck,
  AiOutlineClose,
  AiOutlineFilePdf,
  AiOutlineCalendar,
  AiOutlineDollar,
  AiOutlineUser,
  AiOutlineBuild,
  AiOutlinePhone,
  AiOutlineEnvironment,
  AiOutlineSafetyCertificate,
  AiOutlineFileText,
  AiOutlineSignature,
  AiOutlineShoppingCart,
  AiOutlineHome,
  AiOutlineSave,
  AiOutlinePlus,
  AiOutlineMinus
} from 'react-icons/ai';

interface ContractProps {
  onBack: () => void;
  onNavigate?: (page: string) => void;
  contractData?: Contract;
  productData?: any; // Product data from product detail page
}

interface Contract {
  id: string;
  contractNumber: string;
  status: 'draft' | 'sent' | 'accepted' | 'completed' | 'cancelled';
  createdAt: string;
  lastUpdated: string;
  contractType: 'b2b' | 'b2c';
  seller: CompanyInfo;
  buyer: CustomerInfo;
  products: ProductItem[];
  paymentTerms: PaymentTerms;
  delivery: DeliveryInfo;
  warranty: WarrantyInfo;
  terms: TermsAndConditions;
  signatures: Signatures;
}

interface CustomerInfo {
  type: 'b2b' | 'b2c';
  name: string;
  email: string;
  phone: string;
  companyName?: string;
  crNumber?: string;
  taxNumber?: string;
  address: string;
  representative?: string;
  position?: string;
}

interface CompanyInfo {
  type: 'b2b' | 'b2c';
  name: string;
  crNumber: string;
  taxNumber: string;
  address: string;
  phone: string;
  email: string;
  representative: string;
  position: string;
}

interface ProductItem {
  id: string;
  name: string;
  image: string;
  description: string;
  materials: string[];
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  specifications: {
    dimensions: string;
    weight: string;
    color: string;
    material: string;
  };
}

interface PaymentTerms {
  totalAmount: number;
  currency: string;
  deposit: number;
  depositDueDate: string;
  finalPaymentDue: string;
  paymentMethod: string;
  installmentPlan?: Installment[];
}

interface Installment {
  amount: number;
  dueDate: string;
  percentage: number;
}

interface DeliveryInfo {
  address: string;
  estimatedDate: string;
  installationIncluded: boolean;
  shippingCost: number;
  notes: string;
}

interface WarrantyInfo {
  duration: string;
  coverage: string[];
  limitations: string[];
}

interface TermsAndConditions {
  cancellationPolicy: string;
  returnPolicy: string;
  liability: string;
  governingLaw: string;
  forceMajeure: string;
}

interface Signatures {
  sellerSigned: boolean;
  buyerSigned: boolean;
  sellerSignature?: string;
  buyerSignature?: string;
  signedDate?: string;
}

// Default company data (Seller - Giga Home)
const defaultCompany: CompanyInfo = {
  type: 'b2b',
  name: 'Giga Home Furniture',
  crNumber: '1010567890',
  taxNumber: '310456789012345',
  address: '123 Business District, Riyadh 11564, Saudi Arabia',
  phone: '+966 11 123 4567',
  email: 'contracts@gigahome.com',
  representative: 'Ahmed Al-Rashid',
  position: 'Sales Manager'
};

// Default contract data
const defaultContract: Contract = {
  id: 'CT-2024-001',
  contractNumber: 'GH-CONTRACT-2024-001',
  status: 'draft',
  createdAt: '2024-01-15',
  lastUpdated: '2024-01-15',
  contractType: 'b2b',
  seller: defaultCompany,
  buyer: {
    type: 'b2b',
    name: '',
    email: '',
    phone: '',
    companyName: '',
    crNumber: '',
    taxNumber: '',
    address: '',
    representative: '',
    position: ''
  },
  products: [],
  paymentTerms: {
    totalAmount: 0,
    currency: 'SAR',
    deposit: 0,
    depositDueDate: '',
    finalPaymentDue: '',
    paymentMethod: 'Bank Transfer',
    installmentPlan: []
  },
  delivery: {
    address: '',
    estimatedDate: '',
    installationIncluded: false,
    shippingCost: 0,
    notes: ''
  },
  warranty: {
    duration: '24 months',
    coverage: [
      'Manufacturing defects',
      'Structural integrity',
      'Material quality',
      'Hardware functionality'
    ],
    limitations: [
      'Normal wear and tear',
      'Damage from improper use',
      'Modifications by third parties',
      'Commercial misuse'
    ]
  },
  terms: {
    cancellationPolicy: 'Orders can be cancelled within 7 days with full refund. After 7 days, 50% cancellation fee applies.',
    returnPolicy: 'Products can be returned within 14 days if unused and in original packaging. Return shipping costs borne by buyer.',
    liability: 'Seller liability limited to product replacement or repair. Not liable for consequential damages.',
    governingLaw: 'Laws of the Kingdom of Saudi Arabia',
    forceMajeure: 'Neither party liable for delays due to circumstances beyond reasonable control.'
  },
  signatures: {
    sellerSigned: false,
    buyerSigned: false
  }
};

const Contracts: React.FC<ContractProps> = ({ onBack, onNavigate, contractData, productData }) => {
  const [currentContract, setCurrentContract] = useState<Contract>(contractData || defaultContract);
  const [isEditing, setIsEditing] = useState(contractData?.status === 'draft');
  const [products, setProducts] = useState<any[]>([]);

  // Load products from localStorage on component mount
  useEffect(() => {
    const loadProducts = () => {
      try {
        const savedProducts = localStorage.getItem('furnitureProducts');
        if (savedProducts) {
          const parsedProducts = JSON.parse(savedProducts);
          setProducts(parsedProducts);
          
          // If productData is provided (from product detail page), add it to contract
          if (productData && !contractData) {
            const productItem: ProductItem = {
              id: productData.id,
              name: productData.name,
              image: productData.image || productData.images?.[0] || 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400',
              description: productData.description || productData.shortDescription,
              materials: productData.materials || [productData.material || 'Solid Wood'],
              quantity: 1,
              unitPrice: parseFloat(productData.price) || 0,
              totalPrice: parseFloat(productData.price) || 0,
              specifications: {
                dimensions: productData.dimensions ? 
                  `${productData.dimensions.length} × ${productData.dimensions.width} × ${productData.dimensions.height} ${productData.dimensions.unit}` 
                  : 'N/A',
                weight: productData.weight || 'N/A',
                color: productData.primaryColor || 'N/A',
                material: productData.material || 'N/A'
              }
            };

            setCurrentContract(prev => ({
              ...prev,
              products: [productItem],
              paymentTerms: {
                ...prev.paymentTerms,
                totalAmount: parseFloat(productData.price) || 0,
                deposit: (parseFloat(productData.price) || 0) * 0.5
              }
            }));
          }
        }
      } catch (error) {
        console.error('Error loading products:', error);
      }
    };

    loadProducts();
  }, [productData, contractData]);

  // Update total amount when products change
  useEffect(() => {
    const totalAmount = currentContract.products.reduce((sum, product) => sum + product.totalPrice, 0);
    const deposit = totalAmount * 0.5;
    
    setCurrentContract(prev => ({
      ...prev,
      paymentTerms: {
        ...prev.paymentTerms,
        totalAmount,
        deposit
      }
    }));
  }, [currentContract.products]);

  const handleSendContract = () => {
    setCurrentContract(prev => ({ ...prev, status: 'sent' }));
    setIsEditing(false);
    // API call to send contract
  };

  const handleAcceptContract = () => {
    setCurrentContract(prev => ({ 
      ...prev, 
      status: 'accepted',
      signatures: {
        ...prev.signatures,
        buyerSigned: true,
        signedDate: new Date().toISOString().split('T')[0]
      }
    }));
  };

  const handleSaveContract = () => {
    setCurrentContract(prev => ({ 
      ...prev, 
      lastUpdated: new Date().toISOString().split('T')[0]
    }));
    setIsEditing(false);
    // Save to localStorage or API
    saveContractToStorage();
  };

  const saveContractToStorage = () => {
    try {
      const existingContracts = JSON.parse(localStorage.getItem('contracts') || '[]');
      const updatedContracts = existingContracts.filter((c: Contract) => c.id !== currentContract.id);
      localStorage.setItem('contracts', JSON.stringify([...updatedContracts, currentContract]));
    } catch (error) {
      console.error('Error saving contract:', error);
    }
  };

  const handleEditToggle = () => {
    setIsEditing(!isEditing);
  };

  const handleAddProduct = () => {
    if (products.length > 0) {
      const product = products[0]; // For demo, add first product. In real app, show selection modal
      const productItem: ProductItem = {
        id: product.id,
        name: product.name,
        image: product.image,
        description: product.description,
        materials: [product.material || 'Solid Wood'],
        quantity: 1,
        unitPrice: parseFloat(product.price) || 0,
        totalPrice: parseFloat(product.price) || 0,
        specifications: {
          dimensions: 'N/A',
          weight: 'N/A',
          color: 'N/A',
          material: product.material || 'N/A'
        }
      };

      setCurrentContract(prev => ({
        ...prev,
        products: [...prev.products, productItem]
      }));
    }
  };

  const handleRemoveProduct = (productId: string) => {
    setCurrentContract(prev => ({
      ...prev,
      products: prev.products.filter(p => p.id !== productId)
    }));
  };

  const handleProductQuantityChange = (productId: string, newQuantity: number) => {
    if (newQuantity < 1) return;

    setCurrentContract(prev => ({
      ...prev,
      products: prev.products.map(product => 
        product.id === productId 
          ? {
              ...product,
              quantity: newQuantity,
              totalPrice: product.unitPrice * newQuantity
            }
          : product
      )
    }));
  };

  const handleBuyerFieldChange = (field: keyof CustomerInfo, value: string) => {
    setCurrentContract(prev => ({
      ...prev,
      buyer: {
        ...prev.buyer,
        [field]: value
      }
    }));
  };

  const handleContractTypeChange = (type: 'b2b' | 'b2c') => {
    setCurrentContract(prev => ({
      ...prev,
      contractType: type,
      buyer: {
        ...prev.buyer,
        type: type
      }
    }));
  };

  const handleDeliveryFieldChange = (field: keyof DeliveryInfo, value: any) => {
    setCurrentContract(prev => ({
      ...prev,
      delivery: {
        ...prev.delivery,
        [field]: value
      }
    }));
  };

  const handlePaymentFieldChange = (field: keyof PaymentTerms, value: any) => {
    setCurrentContract(prev => ({
      ...prev,
      paymentTerms: {
        ...prev.paymentTerms,
        [field]: value
      }
    }));
  };

  const handleDownloadPDF = () => {
    console.log('Downloading PDF contract...');
  };

  const handlePrint = () => {
    window.print();
  };

  const getStatusColor = (status: string) => {
    const colors = {
      draft: 'bg-gray-100 text-gray-700 border border-gray-300',
      sent: 'bg-blue-100 text-blue-700 border border-blue-300',
      accepted: 'bg-green-100 text-green-700 border border-green-300',
      completed: 'bg-green-100 text-green-700 border border-green-300',
      cancelled: 'bg-red-100 text-red-700 border border-red-300'
    };
    return colors[status as keyof typeof colors] || colors.draft;
  };

  const formatCurrency = (amount: number, currency: string) => {
    return new Intl.NumberFormat('en-SA', {
      style: 'currency',
      currency: currency
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <button
              onClick={onBack}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-700 transition-colors bg-white p-3 rounded-xl border border-gray-200 hover:border-gray-300"
            >
              <AiOutlineArrowLeft size={20} />
            </button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Contract Agreement</h1>
              <p className="text-gray-600 mt-1">Furniture Supply Contract - {currentContract.contractNumber}</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <span className={`px-4 py-2 rounded-full text-sm font-semibold ${getStatusColor(currentContract.status)}`}>
              {currentContract.status.charAt(0).toUpperCase() + currentContract.status.slice(1)}
            </span>
            
            {isEditing ? (
              <>
                <button
                  onClick={handleSaveContract}
                  className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                >
                  <AiOutlineSave size={18} />
                  <span>Save</span>
                </button>
                <button
                  onClick={() => setIsEditing(false)}
                  className="flex items-center space-x-2 bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  <AiOutlineClose size={18} />
                  <span>Cancel</span>
                </button>
              </>
            ) : (
              <>
                {currentContract.status === 'draft' && (
                  <button
                    onClick={handleEditToggle}
                    className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <AiOutlineEdit size={18} />
                    <span>Edit</span>
                  </button>
                )}
                <button
                  onClick={handleDownloadPDF}
                  className="flex items-center space-x-2 bg-white text-gray-700 border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <AiOutlineDownload size={18} />
                  <span>PDF</span>
                </button>
                <button
                  onClick={handlePrint}
                  className="flex items-center space-x-2 bg-white text-gray-700 border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <AiOutlinePrinter size={18} />
                  <span>Print</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Contract Container */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
          {/* Contract Header */}
          <div className="bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200 p-8">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center">
                    <AiOutlineFileText className="text-white text-xl" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Furniture Supply Agreement</h2>
                    <p className="text-gray-600">Contract #{currentContract.contractNumber}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Created:</span>
                    <span className="ml-2 text-gray-900 font-medium">
                      {formatDate(currentContract.createdAt)}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">Last Updated:</span>
                    <span className="ml-2 text-gray-900 font-medium">
                      {formatDate(currentContract.lastUpdated)}
                    </span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-gray-900">
                  {formatCurrency(currentContract.paymentTerms.totalAmount, currentContract.paymentTerms.currency)}
                </div>
                <div className="text-gray-600">Total Contract Value</div>
              </div>
            </div>
          </div>

          {/* Contract Type Selection */}
          <div className="p-8 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <AiOutlineFileText className="mr-2 text-blue-600" />
              Contract Type
            </h3>
            <div className="flex space-x-4">
              <label className="flex items-center space-x-2">
                <input
                  type="radio"
                  name="contractType"
                  value="b2b"
                  checked={currentContract.contractType === 'b2b'}
                  onChange={(e) => handleContractTypeChange('b2b')}
                  disabled={!isEditing}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="text-gray-700">Business to Business (B2B)</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="radio"
                  name="contractType"
                  value="b2c"
                  checked={currentContract.contractType === 'b2c'}
                  onChange={(e) => handleContractTypeChange('b2c')}
                  disabled={!isEditing}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="text-gray-700">Business to Consumer (B2C)</span>
              </label>
            </div>
          </div>

          {/* Parties Information */}
          <div className="p-8 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
              <AiOutlineBuild className="mr-2 text-blue-600" />
              Parties Information
            </h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Seller Info - Read Only */}
              <div className="bg-gray-50 rounded-xl p-6">
                <h4 className="font-semibold text-gray-900 mb-4 text-blue-600">SELLER (COMPANY PROVIDER)</h4>
                <div className="space-y-3">
                  <div>
                    <p className="font-bold text-gray-900 text-lg">{currentContract.seller.name}</p>
                    <p className="text-gray-600">Represented by: {currentContract.seller.representative}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">CR Number:</span>
                      <p className="font-medium text-gray-900">{currentContract.seller.crNumber}</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Tax Number:</span>
                      <p className="font-medium text-gray-900">{currentContract.seller.taxNumber}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <AiOutlineEnvironment />
                    <span>{currentContract.seller.address}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <AiOutlinePhone />
                    <span>{currentContract.seller.phone}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <AiOutlineMail />
                    <span>{currentContract.seller.email}</span>
                  </div>
                </div>
              </div>

              {/* Buyer Info - Editable */}
              <div className="bg-gray-50 rounded-xl p-6">
                <h4 className="font-semibold text-gray-900 mb-4 text-green-600">BUYER (CUSTOMER)</h4>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Customer Name *</label>
                      <input
                        type="text"
                        value={currentContract.buyer.name}
                        onChange={(e) => handleBuyerFieldChange('name', e.target.value)}
                        disabled={!isEditing}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:text-gray-500"
                        placeholder="Enter customer name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                      <input
                        type="email"
                        value={currentContract.buyer.email}
                        onChange={(e) => handleBuyerFieldChange('email', e.target.value)}
                        disabled={!isEditing}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:text-gray-500"
                        placeholder="Enter email address"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
                    <input
                      type="tel"
                      value={currentContract.buyer.phone}
                      onChange={(e) => handleBuyerFieldChange('phone', e.target.value)}
                      disabled={!isEditing}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:text-gray-500"
                      placeholder="Enter phone number"
                    />
                  </div>

                  {currentContract.contractType === 'b2b' && (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
                          <input
                            type="text"
                            value={currentContract.buyer.companyName || ''}
                            onChange={(e) => handleBuyerFieldChange('companyName', e.target.value)}
                            disabled={!isEditing}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:text-gray-500"
                            placeholder="Enter company name"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">CR Number</label>
                          <input
                            type="text"
                            value={currentContract.buyer.crNumber || ''}
                            onChange={(e) => handleBuyerFieldChange('crNumber', e.target.value)}
                            disabled={!isEditing}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:text-gray-500"
                            placeholder="Enter CR number"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Tax Number</label>
                          <input
                            type="text"
                            value={currentContract.buyer.taxNumber || ''}
                            onChange={(e) => handleBuyerFieldChange('taxNumber', e.target.value)}
                            disabled={!isEditing}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:text-gray-500"
                            placeholder="Enter tax number"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Representative</label>
                          <input
                            type="text"
                            value={currentContract.buyer.representative || ''}
                            onChange={(e) => handleBuyerFieldChange('representative', e.target.value)}
                            disabled={!isEditing}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:text-gray-500"
                            placeholder="Enter representative name"
                          />
                        </div>
                      </div>
                    </>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Address *</label>
                    <textarea
                      value={currentContract.buyer.address}
                      onChange={(e) => handleBuyerFieldChange('address', e.target.value)}
                      disabled={!isEditing}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:text-gray-500 resize-none"
                      placeholder="Enter complete address"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Products Section */}
          <div className="p-8 border-b border-gray-200">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <AiOutlineShoppingCart className="mr-2 text-blue-600" />
                Products & Specifications
              </h3>
              {isEditing && (
                <button
                  onClick={handleAddProduct}
                  className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <AiOutlinePlus size={16} />
                  <span>Add Product</span>
                </button>
              )}
            </div>

            {currentContract.products.length === 0 ? (
              <div className="text-center py-8 bg-gray-50 rounded-xl">
                <AiOutlineShoppingCart className="mx-auto text-gray-400 text-4xl mb-4" />
                <p className="text-gray-600">No products added to this contract</p>
                {isEditing && (
                  <button
                    onClick={handleAddProduct}
                    className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Add First Product
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-6">
                {currentContract.products.map((product, index) => (
                  <div key={product.id} className="bg-gray-50 rounded-xl p-6 relative">
                    {isEditing && (
                      <button
                        onClick={() => handleRemoveProduct(product.id)}
                        className="absolute top-4 right-4 bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
                      >
                        <AiOutlineClose size={16} />
                      </button>
                    )}
                    
                    <div className="flex flex-col lg:flex-row gap-6">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full lg:w-48 h-48 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h4 className="font-bold text-gray-900 text-lg">{product.name}</h4>
                            <p className="text-gray-600 mt-1">{product.description}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-2xl font-bold text-gray-900">
                              {formatCurrency(product.unitPrice, currentContract.paymentTerms.currency)}
                            </p>
                            <p className="text-gray-600">per unit</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <h5 className="font-semibold text-gray-900 mb-3">Specifications</h5>
                            <div className="space-y-2 text-sm">
                              <div className="flex justify-between">
                                <span className="text-gray-500">Dimensions:</span>
                                <span className="font-medium text-gray-900">{product.specifications.dimensions}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-500">Weight:</span>
                                <span className="font-medium text-gray-900">{product.specifications.weight}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-500">Color:</span>
                                <span className="font-medium text-gray-900">{product.specifications.color}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-500">Material:</span>
                                <span className="font-medium text-gray-900">{product.specifications.material}</span>
                              </div>
                            </div>
                          </div>

                          <div>
                            <h5 className="font-semibold text-gray-900 mb-3">Order Details</h5>
                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <span className="text-gray-500">Quantity:</span>
                                <div className="flex items-center space-x-2">
                                  {isEditing ? (
                                    <>
                                      <button
                                        onClick={() => handleProductQuantityChange(product.id, product.quantity - 1)}
                                        className="w-8 h-8 border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors flex items-center justify-center"
                                        disabled={product.quantity <= 1}
                                      >
                                        <AiOutlineMinus size={14} />
                                      </button>
                                      <span className="w-12 text-center font-semibold">{product.quantity}</span>
                                      <button
                                        onClick={() => handleProductQuantityChange(product.id, product.quantity + 1)}
                                        className="w-8 h-8 border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors flex items-center justify-center"
                                      >
                                        <AiOutlinePlus size={14} />
                                      </button>
                                    </>
                                  ) : (
                                    <span className="font-bold text-gray-900">{product.quantity} units</span>
                                  )}
                                </div>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-500">Total:</span>
                                <span className="font-bold text-gray-900">
                                  {formatCurrency(product.totalPrice, currentContract.paymentTerms.currency)}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500 block mb-2">Materials Used:</span>
                                <div className="flex flex-wrap gap-2">
                                  {product.materials.map((material, matIndex) => (
                                    <span
                                      key={matIndex}
                                      className="px-3 py-1 bg-white border border-gray-300 rounded-full text-xs text-gray-700"
                                    >
                                      {material}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Payment Terms */}
          <div className="p-8 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
              <AiOutlineDollar className="mr-2 text-blue-600" />
              Payment Terms
            </h3>
            <div className="bg-gray-50 rounded-xl p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-900">
                    {formatCurrency(currentContract.paymentTerms.totalAmount, currentContract.paymentTerms.currency)}
                  </p>
                  <p className="text-gray-600">Total Amount</p>
                </div>
                <div className="text-center">
                  {isEditing ? (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Deposit</label>
                      <input
                        type="number"
                        value={currentContract.paymentTerms.deposit}
                        onChange={(e) => handlePaymentFieldChange('deposit', parseFloat(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-center text-xl font-bold"
                      />
                    </div>
                  ) : (
                    <>
                      <p className="text-2xl font-bold text-gray-900">
                        {formatCurrency(currentContract.paymentTerms.deposit, currentContract.paymentTerms.currency)}
                      </p>
                      <p className="text-gray-600">Deposit ({Math.round((currentContract.paymentTerms.deposit / currentContract.paymentTerms.totalAmount) * 100)}%)</p>
                    </>
                  )}
                </div>
                <div className="text-center">
                  {isEditing ? (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
                      <select
                        value={currentContract.paymentTerms.paymentMethod}
                        onChange={(e) => handlePaymentFieldChange('paymentMethod', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-center"
                      >
                        <option value="Bank Transfer">Bank Transfer</option>
                        <option value="Credit Card">Credit Card</option>
                        <option value="Cash">Cash</option>
                        <option value="Check">Check</option>
                      </select>
                    </div>
                  ) : (
                    <>
                      <p className="text-xl font-bold text-gray-900">{currentContract.paymentTerms.paymentMethod}</p>
                      <p className="text-gray-600">Payment Method</p>
                    </>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Deposit Due Date</label>
                  {isEditing ? (
                    <input
                      type="date"
                      value={currentContract.paymentTerms.depositDueDate}
                      onChange={(e) => handlePaymentFieldChange('depositDueDate', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  ) : (
                    <p className="font-medium text-gray-900">
                      {currentContract.paymentTerms.depositDueDate ? formatDate(currentContract.paymentTerms.depositDueDate) : 'Not set'}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Final Payment Due</label>
                  {isEditing ? (
                    <input
                      type="date"
                      value={currentContract.paymentTerms.finalPaymentDue}
                      onChange={(e) => handlePaymentFieldChange('finalPaymentDue', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  ) : (
                    <p className="font-medium text-gray-900">
                      {currentContract.paymentTerms.finalPaymentDue ? formatDate(currentContract.paymentTerms.finalPaymentDue) : 'Not set'}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Delivery & Warranty */}
          <div className="p-8 border-b border-gray-200">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Delivery Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <AiOutlineCalendar className="mr-2 text-blue-600" />
                  Delivery Information
                </h3>
                <div className="bg-gray-50 rounded-xl p-6 space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Address</label>
                    {isEditing ? (
                      <textarea
                        value={currentContract.delivery.address}
                        onChange={(e) => handleDeliveryFieldChange('address', e.target.value)}
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                        placeholder="Enter delivery address"
                      />
                    ) : (
                      <p className="font-medium text-gray-900">{currentContract.delivery.address || 'Not specified'}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Estimated Delivery Date</label>
                    {isEditing ? (
                      <input
                        type="date"
                        value={currentContract.delivery.estimatedDate}
                        onChange={(e) => handleDeliveryFieldChange('estimatedDate', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    ) : (
                      <p className="font-medium text-gray-900">
                        {currentContract.delivery.estimatedDate ? formatDate(currentContract.delivery.estimatedDate) : 'Not set'}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Installation Included</span>
                    {isEditing ? (
                      <input
                        type="checkbox"
                        checked={currentContract.delivery.installationIncluded}
                        onChange={(e) => handleDeliveryFieldChange('installationIncluded', e.target.checked)}
                        className="w-4 h-4 text-blue-500 rounded focus:ring-blue-500"
                      />
                    ) : (
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        currentContract.delivery.installationIncluded 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {currentContract.delivery.installationIncluded ? 'Yes' : 'No'}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Shipping Cost</span>
                    {isEditing ? (
                      <input
                        type="number"
                        value={currentContract.delivery.shippingCost}
                        onChange={(e) => handleDeliveryFieldChange('shippingCost', parseFloat(e.target.value))}
                        className="w-32 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    ) : (
                      <span className="font-bold text-gray-900">
                        {currentContract.delivery.shippingCost === 0 
                          ? 'Free' 
                          : formatCurrency(currentContract.delivery.shippingCost, currentContract.paymentTerms.currency)
                        }
                      </span>
                    )}
                  </div>
                  {currentContract.delivery.notes && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Notes</label>
                      {isEditing ? (
                        <textarea
                          value={currentContract.delivery.notes}
                          onChange={(e) => handleDeliveryFieldChange('notes', e.target.value)}
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                        />
                      ) : (
                        <p className="text-sm text-gray-700">{currentContract.delivery.notes}</p>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Warranty Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <AiOutlineSafetyCertificate className="mr-2 text-blue-600" />
                  Warranty Information
                </h3>
                <div className="bg-gray-50 rounded-xl p-6 space-y-4">
                  <div>
                    <span className="text-gray-500 block mb-1">Warranty Duration</span>
                    <p className="font-bold text-gray-900 text-lg">{currentContract.warranty.duration}</p>
                  </div>
                  
                  <div>
                    <span className="text-gray-500 block mb-2">Coverage Includes:</span>
                    <ul className="space-y-1">
                      {currentContract.warranty.coverage.map((item, index) => (
                        <li key={index} className="flex items-center text-sm text-gray-700">
                          <AiOutlineCheck className="text-green-500 mr-2 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <span className="text-gray-500 block mb-2">Limitations:</span>
                    <ul className="space-y-1">
                      {currentContract.warranty.limitations.map((item, index) => (
                        <li key={index} className="flex items-center text-sm text-gray-700">
                          <AiOutlineClose className="text-red-500 mr-2 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Signatures */}
          <div className="p-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
              <AiOutlineSignature className="mr-2 text-blue-600" />
              Signatures
            </h3>
            <div className="bg-gray-50 rounded-xl p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="text-center">
                  <div className="h-32 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center mb-4">
                    {currentContract.signatures.sellerSigned ? (
                      <div className="text-green-600">
                        <AiOutlineCheck className="text-4xl mx-auto mb-2" />
                        <p className="font-semibold">Signed</p>
                      </div>
                    ) : (
                      <p className="text-gray-500">Seller Signature Pending</p>
                    )}
                  </div>
                  <p className="font-semibold text-gray-900">{currentContract.seller.representative}</p>
                  <p className="text-gray-600">{currentContract.seller.position}</p>
                  <p className="text-sm text-gray-500 mt-1">{currentContract.seller.name}</p>
                </div>

                <div className="text-center">
                  <div className="h-32 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center mb-4">
                    {currentContract.signatures.buyerSigned ? (
                      <div className="text-green-600">
                        <AiOutlineCheck className="text-4xl mx-auto mb-2" />
                        <p className="font-semibold">Signed</p>
                      </div>
                    ) : (
                      <p className="text-gray-500">Buyer Signature Pending</p>
                    )}
                  </div>
                  <p className="font-semibold text-gray-900">
                    {currentContract.buyer.representative || currentContract.buyer.name}
                  </p>
                  {currentContract.buyer.position && (
                    <p className="text-gray-600">{currentContract.buyer.position}</p>
                  )}
                  {currentContract.buyer.companyName && (
                    <p className="text-sm text-gray-500 mt-1">{currentContract.buyer.companyName}</p>
                  )}
                </div>
              </div>

              {currentContract.signatures.signedDate && (
                <div className="text-center mt-6 pt-6 border-t border-gray-200">
                  <p className="text-gray-600">
                    Contract signed on {formatDate(currentContract.signatures.signedDate)}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end space-x-4 mt-8">
          {currentContract.status === 'draft' && !isEditing && (
            <button
              onClick={handleEditToggle}
              className="bg-blue-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors"
            >
              Edit Contract
            </button>
          )}
          {currentContract.status === 'draft' && isEditing && (
            <button
              onClick={handleSaveContract}
              className="bg-green-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-green-700 transition-colors"
            >
              Save Contract
            </button>
          )}
          {currentContract.status === 'sent' && (
            <button
              onClick={handleAcceptContract}
              className="bg-green-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-green-700 transition-colors"
            >
              Accept & Sign Contract
            </button>
          )}
          <button
            onClick={onBack}
            className="bg-white text-gray-700 border border-gray-300 px-8 py-3 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};

export default Contracts;