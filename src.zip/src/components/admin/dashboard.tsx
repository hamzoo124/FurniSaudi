import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import {
  Users, Store, Package, ShoppingBag, DollarSign, Check, X,
  Search, Eye, Ban, UserPlus, Bell, RefreshCw,
  Settings, AlertTriangle, Star, Grid3X3,
  ChevronRight, TrendingUp, MessageCircle,
  LayoutDashboard, FileText, Edit, Trash2, Plus,
  Mail, Smartphone, BarChart3, ShoppingCart,
  CreditCard, Calendar, PieChart, BarChart
} from 'lucide-react';

// Hooks
import { useDashboardData } from '@/hooks/useDashboardData';
import { useSellers } from '@/hooks/useSellers';
import { useProducts } from '@/hooks/useProducts';
import { useOrders } from '@/hooks/useOrders';

// Components
import { StatsCard } from '@/components/admin/dashboard/StatsCards';
import { RecentActivity } from '@/components/admin/dashboard/RecentActivity';
import { QuickActions } from '@/components/admin/dashboard/QuickActions';

// Types
interface AdminAlert {
  id: string;
  title: string;
  message: string;
  type: 'new_seller' | 'new_product' | 'new_order' | 'warning' | 'info';
  created_at: string;
  read: boolean;
}

const AdminDashboard: React.FC = () => {
  const router = useRouter();
  const [activeSection, setActiveSection] = useState('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [adminAlerts, setAdminAlerts] = useState<AdminAlert[]>([]);

  // Data hooks
  const { stats, loading: statsLoading, error: statsError, refetch: refetchStats } = useDashboardData();
  const { sellers, pendingSellers, loading: sellersLoading, refetch: refetchSellers } = useSellers();
  const { products, pendingProducts, loading: productsLoading, refetch: refetchProducts } = useProducts();
  const { orders, loading: ordersLoading, refetch: refetchOrders } = useOrders();

  // Refresh all data
  const refreshAll = () => {
    refetchStats();
    refetchSellers();
    refetchProducts();
    refetchOrders();
  };

  // Add alert function
  const addAdminAlert = (alert: {
    title: string;
    message: string;
    type: 'info' | 'warning' | 'success';
  }) => {
    const newAlert: AdminAlert = {
      id: Date.now().toString(),
      ...alert,
      type: alert.type === 'success' ? 'info' : alert.type === 'warning' ? 'warning' : 'info',
      created_at: new Date().toISOString(),
      read: false
    };
    setAdminAlerts(prev => [newAlert, ...prev.slice(0, 9)]);
  };

  const markAlertAsRead = (alertId: string) => {
    setAdminAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, read: true } : alert
    ));
  };

  const clearAllAlerts = () => {
    setAdminAlerts([]);
  };

  // Navigation tabs
  const navigationTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'sellers', label: 'Sellers', icon: Store, badge: stats?.pendingApprovals || 0 },
    { id: 'products', label: 'Products', icon: Package, badge: stats?.pendingProducts || 0 },
    { id: 'orders', label: 'Orders', icon: ShoppingBag },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'categories', label: 'Categories', icon: Grid3X3 },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  // Quick actions
  const quickActions = [
    { 
      label: 'Review Seller Applications', 
      icon: UserPlus, 
      section: 'sellers', 
      badge: stats?.pendingApprovals || null, 
      color: 'blue' as const,
      description: 'Approve new sellers'
    },
    { 
      label: 'Approve Products', 
      icon: Package, 
      section: 'products', 
      badge: stats?.pendingProducts || null, 
      color: 'orange' as const,
      description: 'Review new products'
    },
    { 
      label: 'Manage Categories', 
      icon: Grid3X3, 
      section: 'categories', 
      badge: null, 
      color: 'green' as const,
      description: 'Add/edit categories'
    },
    { 
      label: 'View All Orders', 
      icon: ShoppingBag, 
      section: 'orders', 
      badge: stats?.totalOrders || null, 
      color: 'purple' as const,
      description: 'Track orders'
    },
  ];

  // Loading state
  if (statsLoading && !stats) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-3"></div>
          <p className="text-gray-600 text-sm font-medium">Loading Admin Dashboard...</p>
          <p className="text-xs text-gray-500 mt-1">Fetching real-time data...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (statsError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center max-w-md">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-3" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Failed to load dashboard</h3>
          <p className="text-gray-600 text-sm mb-4">{statsError}</p>
          <button
            onClick={refreshAll}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 font-medium text-sm"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => router.push('/')}
                className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition-all duration-200"
              >
                HomeDecor Admin
              </button>
              
              <div className="flex items-center space-x-0.5 bg-gray-100 p-0.5 rounded-lg">
                {navigationTabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveSection(tab.id)}
                      className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all duration-200 ${
                        activeSection === tab.id
                          ? 'bg-white text-gray-900 shadow-sm'
                          : 'text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{tab.label}</span>
                      {tab.badge && tab.badge > 0 && (
                        <span className="bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full min-w-4 text-center">
                          {tab.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="text-right">
                <p className="text-xs font-semibold text-gray-900">Admin</p>
                <p className="text-xs text-gray-600">admin@homedecor.com</p>
              </div>
              
              <button 
                onClick={refreshAll}
                disabled={statsLoading}
                className="p-2 hover:bg-gray-100 rounded-lg transition-all duration-200 group disabled:opacity-50"
                title="Refresh Data"
              >
                <RefreshCw className={`w-4 h-4 text-gray-600 group-hover:text-gray-900 transition-colors ${statsLoading ? 'animate-spin' : ''}`} />
              </button>
              
              <button className="p-2 hover:bg-gray-100 rounded-lg relative transition-all duration-200 group">
                <Bell className="w-4 h-4 text-gray-600 group-hover:text-gray-900 transition-colors" />
                {(adminAlerts.filter(a => !a.read).length > 0) && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-semibold shadow-sm">
                    {adminAlerts.filter(a => !a.read).length}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="p-6">
        {/* Dashboard Section */}
        {activeSection === 'dashboard' && stats && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
              <StatsCard
                label="Total Sellers"
                value={stats.totalSellers}
                subtitle={`${stats.approvedSellers} approved`}
                icon={Store}
                color="blue"
                onClick={() => setActiveSection('sellers')}
              />
              <StatsCard
                label="Total Buyers"
                value={stats.totalBuyers}
                subtitle={`${stats.approvedBuyers} active`}
                icon={Users}
                color="green"
                onClick={() => setActiveSection('users')}
              />
              <StatsCard
                label="Total Products"
                value={stats.totalProducts}
                subtitle={`${stats.approvedProducts} approved`}
                icon={Package}
                color="purple"
                onClick={() => setActiveSection('products')}
              />
              <StatsCard
                label="Total Orders"
                value={stats.totalOrders}
                subtitle={`${stats.todayOrders} today`}
                icon={ShoppingBag}
                color="orange"
                onClick={() => setActiveSection('orders')}
              />
              <StatsCard
                label="Pending Approvals"
                value={stats.pendingApprovals}
                subtitle={`${stats.pendingProducts} products`}
                icon={UserPlus}
                color="red"
                onClick={() => setActiveSection('sellers')}
              />
            </div>

            {/* Revenue & Alerts Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatsCard
                label="Total Revenue"
                value={`$${stats.totalRevenue.toLocaleString()}`}
                subtitle={`${stats.monthlyRevenue.toLocaleString()} this month`}
                icon={DollarSign}
                color="green"
                onClick={() => setActiveSection('orders')}
              />
              <StatsCard
                label="Low Stock"
                value={stats.lowStockAlerts}
                subtitle="Products need restock"
                icon={Package}
                color="orange"
                onClick={() => alert(`Low Stock Products: ${stats.lowStockAlerts}`)}
              />
              <StatsCard
                label="Wallet Balance"
                value={`$${stats.walletBalance.toLocaleString()}`}
                subtitle="Platform earnings"
                icon={CreditCard}
                color="purple"
                onClick={() => setActiveSection('wallet')}
              />
              <StatsCard
                label="Avg Rating"
                value={stats.averageRating.toFixed(1)}
                subtitle="Overall store rating"
                icon={Star}
                color="blue"
                onClick={() => setActiveSection('reviews')}
              />
            </div>

            {/* Recent Activity */}
            <RecentActivity
              alerts={adminAlerts}
              onMarkAsRead={markAlertAsRead}
              onClearAll={clearAllAlerts}
            />

            {/* Quick Actions & Recent Orders */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <QuickActions
                actions={quickActions}
                onActionClick={setActiveSection}
              />

              <div className="bg-white rounded-lg p-4 border border-gray-200 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-semibold text-gray-900">Recent Orders</h3>
                  <button 
                    onClick={() => setActiveSection('orders')}
                    className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                  >
                    View All
                  </button>
                </div>
                {(!orders || orders.length === 0) ? (
                  <div className="text-center py-4">
                    <ShoppingBag className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                    <p className="text-gray-600 text-xs">No orders yet</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {orders.slice(0, 5).map((order) => (
                      <div key={order.id} className="flex items-center justify-between p-2 border border-gray-100 rounded hover:bg-gray-50 text-xs">
                        <div>
                          <p className="font-medium text-gray-900">#{order.order_number}</p>
                          <p className="text-gray-600">{order.buyer_name}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-gray-900">${order.total_amount}</p>
                          <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                            order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                            order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {order.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Recent Products */}
            <div className="bg-white rounded-lg p-4 border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-semibold text-gray-900">Recent Products</h3>
                <button 
                  onClick={() => setActiveSection('products')}
                  className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                >
                  View All Products
                </button>
              </div>
              {(!products || products.length === 0) ? (
                <div className="text-center py-4">
                  <Package className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-600 text-xs">No products uploaded yet</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {products.slice(0, 6).map((product) => (
                    <div key={product.id} className="border border-gray-200 rounded-lg p-3 hover:shadow transition-shadow duration-200">
                      <div className="flex items-start space-x-2">
                        {product.images && product.images.length > 0 ? (
                          <img
                            src={product.images[0]}
                            alt={product.name}
                            className="w-12 h-12 object-cover rounded"
                          />
                        ) : (
                          <div className="w-12 h-12 bg-gray-100 rounded flex items-center justify-center">
                            <Package className="w-6 h-6 text-gray-400" />
                          </div>
                        )}
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900 text-xs line-clamp-1">{product.name}</h4>
                          <p className="text-xs text-gray-600 mt-0.5">by {product.seller?.business_name}</p>
                          <div className="flex items-center justify-between mt-1">
                            <span className="font-bold text-green-600 text-xs">${product.price}</span>
                            <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                              product.approval_status === 'approved' ? 'bg-green-100 text-green-800' :
                              product.approval_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {product.approval_status}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Sellers Section */}
        {activeSection === 'sellers' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Seller Management</h2>
                <p className="text-gray-600 text-xs mt-0.5">
                  {stats?.totalSellers || 0} Total Sellers • {stats?.approvedSellers || 0} Approved • {stats?.pendingApprovals || 0} Pending
                </p>
              </div>
              <div className="flex items-center space-x-3">
                {stats?.pendingApprovals && stats.pendingApprovals > 0 && (
                  <span className="bg-red-100 text-red-800 text-xs font-semibold px-3 py-1 rounded-full">
                    {stats.pendingApprovals} Pending Approval
                  </span>
                )}
                <button
                  onClick={refreshAll}
                  disabled={sellersLoading}
                  className="flex items-center space-x-1.5 px-3 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${sellersLoading ? 'animate-spin' : ''}`} />
                  <span>Refresh</span>
                </button>
              </div>
            </div>

            {/* Pending Sellers */}
            {pendingSellers && pendingSellers.length > 0 && (
              <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
                <div className="p-4 border-b border-gray-200">
                  <h3 className="text-base font-semibold text-gray-900">Pending Seller Approvals</h3>
                  <p className="text-gray-600 text-xs mt-0.5">Review and approve new seller applications</p>
                </div>
                <div className="divide-y divide-gray-200">
                  {pendingSellers.map((seller) => (
                    <div key={seller.id} className="p-4 hover:bg-gray-50 transition-colors duration-200">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                            <Store className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-900 text-sm">{seller.business_name}</h4>
                            <p className="text-gray-600 text-xs">{seller.email}</p>
                            <div className="flex items-center space-x-1.5 mt-0.5">
                              <span className="bg-yellow-100 text-yellow-800 text-xs px-1.5 py-0.5 rounded-full">
                                Pending Review
                              </span>
                              <span className="text-xs text-gray-500">
                                Applied: {new Date(seller.created_at).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => {
                              // Navigate to seller detail page or open modal
                              router.push(`/admin/sellers/${seller.id}`);
                            }}
                            className="flex items-center space-x-1.5 px-2.5 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>View Details</span>
                          </button>
                          <button
                            onClick={() => {
                              // Handle approve logic
                              addAdminAlert({
                                title: 'Seller Approved',
                                message: `${seller.business_name} has been approved`,
                                type: 'success'
                              });
                            }}
                            className="flex items-center space-x-1.5 px-3 py-1.5 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all duration-200 font-semibold text-xs"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Approve</span>
                          </button>
                          <button
                            onClick={() => {
                              const reason = prompt('Enter rejection reason:');
                              if (reason) {
                                addAdminAlert({
                                  title: 'Seller Rejected',
                                  message: `${seller.business_name} has been rejected`,
                                  type: 'warning'
                                });
                              }
                            }}
                            className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all duration-200 font-semibold text-xs"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* All Sellers */}
            <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
              <div className="p-4 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold text-gray-900">All Sellers ({sellers?.length || 0})</h3>
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      placeholder="Search sellers..."
                      className="border border-gray-300 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 w-48"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {(!sellers || sellers.length === 0) ? (
                <div className="p-8 text-center">
                  <Store className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-1.5">No sellers found</h3>
                  <p className="text-gray-600 text-xs">Sellers will appear here when they register</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-200">
                  {sellers
                    .filter(seller => 
                      seller.business_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      seller.email.toLowerCase().includes(searchQuery.toLowerCase())
                    )
                    .map((seller) => (
                    <div key={seller.id} className="p-4 hover:bg-gray-50 transition-colors duration-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                            seller.approval_status === 'approved' ? 'bg-gradient-to-br from-green-500 to-emerald-600' :
                            seller.approval_status === 'pending' ? 'bg-gradient-to-br from-yellow-500 to-orange-600' :
                            'bg-gradient-to-br from-red-500 to-pink-600'
                          }`}>
                            <Store className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-900 text-sm">{seller.business_name}</h4>
                            <p className="text-gray-600 text-xs">{seller.email}</p>
                            <div className="flex items-center space-x-1.5 mt-0.5">
                              <span className={`px-1.5 py-0.5 text-xs rounded-full ${
                                seller.approval_status === 'approved' ? 'bg-green-100 text-green-800' :
                                seller.approval_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-red-100 text-red-800'
                              }`}>
                                {seller.approval_status.toUpperCase()}
                              </span>
                              {seller.featured_seller && (
                                <span className="px-1.5 py-0.5 bg-purple-100 text-purple-800 text-xs rounded-full">
                                  Featured
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <p className="text-base font-bold text-green-600 text-sm">{seller.wallet_balance?.toLocaleString() || 0} SR</p>
                          <p className="text-xs text-gray-600">{seller.total_products || 0} Products</p>
                          <p className="text-xs text-gray-600">{seller.total_sales || 0} Sales</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Products Section */}
        {activeSection === 'products' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Product Management</h2>
                <p className="text-gray-600 text-xs mt-0.5">
                  {stats?.totalProducts || 0} Total Products • {stats?.approvedProducts || 0} Approved • {stats?.pendingProducts || 0} Pending
                </p>
              </div>
              <div className="flex items-center space-x-3">
                {stats?.pendingProducts && stats.pendingProducts > 0 && (
                  <span className="bg-red-100 text-red-800 text-xs font-semibold px-3 py-1 rounded-full">
                    {stats.pendingProducts} Pending Approval
                  </span>
                )}
                <button
                  onClick={refreshAll}
                  disabled={productsLoading}
                  className="flex items-center space-x-1.5 px-3 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${productsLoading ? 'animate-spin' : ''}`} />
                  <span>Refresh</span>
                </button>
              </div>
            </div>

            {/* Product content would go here */}
            <div className="bg-white rounded-lg p-8 text-center border border-gray-200 shadow-sm">
              <Package className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-gray-900 mb-1.5">Product Management</h3>
              <p className="text-gray-600 text-xs">Full product management features available</p>
              <button
                onClick={() => router.push('/admin/products')}
                className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 font-semibold text-xs"
              >
                Go to Products Page
              </button>
            </div>
          </div>
        )}

        {/* Orders Section */}
        {activeSection === 'orders' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Order Management</h2>
                <p className="text-gray-600 text-xs mt-0.5">
                  {stats?.totalOrders || 0} Total Orders • ${stats?.totalRevenue || 0} Total Revenue • {stats?.todayOrders || 0} Today
                </p>
              </div>
              <button
                onClick={refreshAll}
                disabled={ordersLoading}
                className="flex items-center space-x-1.5 px-3 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 font-semibold text-xs disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${ordersLoading ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            </div>

            {/* Orders content would go here */}
            <div className="bg-white rounded-lg p-8 text-center border border-gray-200 shadow-sm">
              <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-gray-900 mb-1.5">Order Management</h3>
              <p className="text-gray-600 text-xs">Full order management features available</p>
              <button
                onClick={() => router.push('/admin/orders')}
                className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 font-semibold text-xs"
              >
                Go to Orders Page
              </button>
            </div>
          </div>
        )}

        {/* Other sections would be implemented similarly */}
      </main>
    </div>
  );
};

export default AdminDashboard;