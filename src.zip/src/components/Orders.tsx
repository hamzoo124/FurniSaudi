import React, { useState, useEffect } from 'react';
import {
  AiOutlineSearch,
  AiOutlineFilter,
  AiOutlineDownload,
  AiOutlineEye,
  AiOutlineEdit,
  AiOutlineCheck,
  AiOutlineClose,
  AiOutlineFileText,
  AiOutlineShoppingCart,
  AiOutlineDollar,
  AiOutlineCalendar,
  AiOutlineUser,
  AiOutlineArrowLeft,
  AiOutlineExclamationCircle,
  AiOutlineClockCircle,
  AiOutlineCheckCircle,
  AiOutlineCloseCircle,
  AiOutlineTruck,
  AiOutlineMessage
} from "react-icons/ai";

interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  productName: string;
  productImage: string;
  productType: 'ready' | 'customized';
  category: string;
  seller: string;
  amount: number;
  status: 'pending' | 'confirmed' | 'in-production' | 'quality-check' | 'ready-for-shipping' | 'shipped' | 'delivered' | 'cancelled';
  orderDate: string;
  estimatedDelivery?: string;
  address: string;
  customizationDetails?: string;
  measurements?: string;
  materials?: string;
  designFiles?: string[];
  contractSent?: boolean;
  contractAccepted?: boolean;
  paymentStatus: 'pending' | 'paid' | 'partially-paid' | 'refunded';
  priority: 'low' | 'medium' | 'high';
  notes?: string;
  productionProgress?: number;
}

interface OrdersPageProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
}

const OrdersPage: React.FC<OrdersPageProps> = ({ onNavigate, onBack }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [productTypeFilter, setProductTypeFilter] = useState<string>('all');
  const [paymentStatusFilter, setPaymentStatusFilter] = useState<string>('all');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [showContractModal, setShowContractModal] = useState(false);
  const [showUpdateStatusModal, setShowUpdateStatusModal] = useState(false);
  const [showProductionModal, setShowProductionModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [productionNotes, setProductionNotes] = useState('');
  const [productionProgress, setProductionProgress] = useState(0);
  const [activeTab, setActiveTab] = useState<'all' | 'open' | 'in-production' | 'completed' | 'cancelled'>('all');

  // Sample orders data for furniture marketplace - more realistic scenarios
  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'ORD-2024-001',
      customerName: 'Ahmed Al-Rashid',
      customerEmail: 'ahmed@email.com',
      customerPhone: '+966 50 123 4567',
      productName: 'Luxury Queen Bed Frame',
      productImage: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=400',
      productType: 'ready',
      category: 'Beds',
      seller: 'Premium Furniture Co.',
      amount: 1249,
      status: 'pending',
      orderDate: '2024-01-15',
      estimatedDelivery: '2024-01-25',
      address: '123 King Fahd Road, Riyadh 11564',
      paymentStatus: 'paid',
      priority: 'high',
      notes: 'Customer requested quick delivery for wedding'
    },
    {
      id: 'ORD-2024-002',
      customerName: 'Sarah Mohammed',
      customerEmail: 'sarah@email.com',
      customerPhone: '+966 55 987 6543',
      productName: 'Custom Dining Table',
      productImage: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400',
      productType: 'customized',
      category: 'Tables',
      seller: 'Artisan Woodworks',
      amount: 1899,
      status: 'confirmed',
      orderDate: '2024-01-14',
      estimatedDelivery: '2024-02-15',
      address: '456 Corniche Road, Jeddah 23456',
      customizationDetails: 'Oak wood finish, extendable to 8 seats, custom carvings',
      measurements: '180cm x 90cm x 75cm',
      materials: 'Solid oak wood, brass fittings',
      designFiles: ['design1.pdf', 'sketch.jpg'],
      contractSent: true,
      contractAccepted: true,
      paymentStatus: 'partially-paid',
      priority: 'medium',
      productionProgress: 0
    },
    {
      id: 'ORD-2024-003',
      customerName: 'Omar Hassan',
      customerEmail: 'omar@email.com',
      customerPhone: '+966 54 456 7890',
      productName: 'Modern Leather Sofa Set',
      productImage: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400',
      productType: 'ready',
      category: 'Sofas',
      seller: 'Modern Living',
      amount: 2899,
      status: 'confirmed',
      orderDate: '2024-01-13',
      estimatedDelivery: '2024-01-20',
      address: '789 University Street, Dammam 31451',
      paymentStatus: 'paid',
      priority: 'medium'
    },
    {
      id: 'ORD-2024-004',
      customerName: 'Fatima Abdullah',
      customerEmail: 'fatima@email.com',
      customerPhone: '+966 53 111 2233',
      productName: 'Executive Office Desk',
      productImage: 'https://images.unsplash.com/photo-1487017159836-4e23ece2e4cf?w=400',
      productType: 'customized',
      category: 'Office Furniture',
      seller: 'Office Pro Solutions',
      amount: 899,
      status: 'in-production',
      orderDate: '2024-01-12',
      estimatedDelivery: '2024-01-30',
      address: '321 Business District, Riyadh 11564',
      customizationDetails: 'Walnut finish, built-in cable management, adjustable height',
      measurements: '160cm x 80cm x 75cm',
      materials: 'Engineered wood, steel frame',
      contractSent: true,
      contractAccepted: true,
      paymentStatus: 'paid',
      priority: 'low',
      productionProgress: 45
    },
    {
      id: 'ORD-2024-005',
      customerName: 'Khalid Ibrahim',
      customerEmail: 'khalid@email.com',
      customerPhone: '+966 56 444 5555',
      productName: 'Designer Coffee Table',
      productImage: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400',
      productType: 'ready',
      category: 'Tables',
      seller: 'Design Hub',
      amount: 450,
      status: 'quality-check',
      orderDate: '2024-01-10',
      estimatedDelivery: '2024-01-18',
      address: '654 Park Avenue, Jeddah 23456',
      paymentStatus: 'paid',
      priority: 'low'
    },
    {
      id: 'ORD-2024-006',
      customerName: 'Layla Ahmed',
      customerEmail: 'layla@email.com',
      customerPhone: '+966 57 888 9999',
      productName: 'Custom Wardrobe Cabinet',
      productImage: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400',
      productType: 'customized',
      category: 'Storage',
      seller: 'Custom Creations',
      amount: 1200,
      status: 'ready-for-shipping',
      orderDate: '2024-01-08',
      estimatedDelivery: '2024-01-22',
      address: '987 Palm Street, Khobar 31952',
      customizationDetails: '4 doors, mirror panels, internal lighting',
      measurements: '240cm x 200cm x 60cm',
      materials: 'MDF with laminate finish',
      paymentStatus: 'paid',
      priority: 'medium',
      productionProgress: 100
    },
    {
      id: 'ORD-2024-007',
      customerName: 'Mohammed Ali',
      customerEmail: 'mohammed@email.com',
      customerPhone: '+966 58 777 6666',
      productName: 'Bookshelf Unit',
      productImage: 'https://images.unsplash.com/photo-1487017159836-4e23ece2e4cf?w=400',
      productType: 'customized',
      category: 'Storage',
      seller: 'Custom Creations',
      amount: 670,
      status: 'shipped',
      orderDate: '2024-01-05',
      estimatedDelivery: '2024-01-15',
      address: '741 Garden Road, Riyadh 11564',
      customizationDetails: '6 shelves, glass doors, LED lighting',
      paymentStatus: 'paid',
      priority: 'medium'
    },
    {
      id: 'ORD-2024-008',
      customerName: 'Noura Hassan',
      customerEmail: 'noura@email.com',
      customerPhone: '+966 59 333 2222',
      productName: 'Dining Chair Set (4 pcs)',
      productImage: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400',
      productType: 'ready',
      category: 'Chairs',
      seller: 'Premium Furniture Co.',
      amount: 320,
      status: 'delivered',
      orderDate: '2024-01-03',
      estimatedDelivery: '2024-01-10',
      address: '852 Ocean View, Jeddah 23456',
      paymentStatus: 'paid',
      priority: 'low'
    },
    {
      id: 'ORD-2024-009',
      customerName: 'Yousef Khan',
      customerEmail: 'yousef@email.com',
      customerPhone: '+966 54 666 7777',
      productName: 'Custom Kitchen Cabinets',
      productImage: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400',
      productType: 'customized',
      category: 'Kitchen',
      seller: 'Artisan Woodworks',
      amount: 3500,
      status: 'cancelled',
      orderDate: '2024-01-02',
      address: '963 Mountain Road, Abha 62521',
      paymentStatus: 'refunded',
      priority: 'high',
      notes: 'Customer cancelled due to budget constraints'
    }
  ]);

  // Filter orders based on active tab and filters
  const filteredOrders = orders.filter(order => {
    // Tab filter
    if (activeTab === 'open') {
      if (!['pending', 'confirmed'].includes(order.status)) return false;
    } else if (activeTab === 'in-production') {
      if (!['in-production', 'quality-check', 'ready-for-shipping'].includes(order.status)) return false;
    } else if (activeTab === 'completed') {
      if (order.status !== 'delivered') return false;
    } else if (activeTab === 'cancelled') {
      if (order.status !== 'cancelled') return false;
    }

    // Status filter
    if (statusFilter !== 'all' && order.status !== statusFilter) return false;

    // Product type filter
    if (productTypeFilter !== 'all' && order.productType !== productTypeFilter) return false;

    // Payment status filter
    if (paymentStatusFilter !== 'all' && order.paymentStatus !== paymentStatusFilter) return false;

    // Date range filter
    if (dateRange.start && order.orderDate < dateRange.start) return false;
    if (dateRange.end && order.orderDate > dateRange.end) return false;

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        order.id.toLowerCase().includes(query) ||
        order.customerName.toLowerCase().includes(query) ||
        order.customerEmail.toLowerCase().includes(query) ||
        order.productName.toLowerCase().includes(query) ||
        order.seller.toLowerCase().includes(query)
      );
    }

    return true;
  });

  // Status color mapping
  const getStatusColor = (status: string) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      confirmed: 'bg-blue-100 text-blue-800 border-blue-200',
      'in-production': 'bg-purple-100 text-purple-800 border-purple-200',
      'quality-check': 'bg-orange-100 text-orange-800 border-orange-200',
      'ready-for-shipping': 'bg-indigo-100 text-indigo-800 border-indigo-200',
      shipped: 'bg-teal-100 text-teal-800 border-teal-200',
      delivered: 'bg-green-100 text-green-800 border-green-200',
      cancelled: 'bg-red-100 text-red-800 border-red-200'
    };
    return colors[status as keyof typeof colors] || colors.pending;
  };

  const getPaymentStatusColor = (status: string) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-800',
      paid: 'bg-green-100 text-green-800',
      'partially-paid': 'bg-blue-100 text-blue-800',
      refunded: 'bg-red-100 text-red-800'
    };
    return colors[status as keyof typeof colors] || colors.pending;
  };

  const getPriorityColor = (priority: string) => {
    const colors = {
      low: 'bg-gray-100 text-gray-800',
      medium: 'bg-blue-100 text-blue-800',
      high: 'bg-red-100 text-red-800'
    };
    return colors[priority as keyof typeof colors] || colors.low;
  };

  // Handler functions
  const handleAcceptOrder = (orderId: string) => {
    setOrders(prev => prev.map(order => 
      order.id === orderId 
        ? { ...order, status: 'confirmed' as const }
        : order
    ));
    alert(`Order ${orderId} accepted successfully!`);
  };

  const handleRejectOrder = (orderId: string) => {
    setSelectedOrder(orders.find(order => order.id === orderId) || null);
    setShowRejectModal(true);
  };

  const handleConfirmRejection = () => {
    if (selectedOrder && rejectReason) {
      setOrders(prev => prev.map(order => 
        order.id === selectedOrder.id 
          ? { 
              ...order, 
              status: 'cancelled' as const,
              paymentStatus: 'refunded' as const,
              notes: `Rejected: ${rejectReason}`
            }
          : order
      ));
      alert(`Order ${selectedOrder.id} rejected. Reason: ${rejectReason}`);
      setShowRejectModal(false);
      setRejectReason('');
      setSelectedOrder(null);
    }
  };

  const handleSendContract = () => {
    if (selectedOrder) {
      setOrders(prev => prev.map(order => 
        order.id === selectedOrder.id 
          ? { ...order, contractSent: true }
          : order
      ));
      alert(`Contract sent for order ${selectedOrder.id}`);
      setShowContractModal(false);
      setSelectedOrder(null);
    }
  };

  const handleUpdateStatus = (order: Order) => {
    setSelectedOrder(order);
    setShowUpdateStatusModal(true);
  };

  const handleConfirmStatusUpdate = () => {
    if (selectedOrder) {
      const statusSelect = document.getElementById('statusSelect') as HTMLSelectElement;
      const newStatus = statusSelect.value as Order['status'];
      
      setOrders(prev => prev.map(order => 
        order.id === selectedOrder.id 
          ? { ...order, status: newStatus }
          : order
      ));
      alert(`Order ${selectedOrder.id} status updated to ${newStatus}`);
      setShowUpdateStatusModal(false);
      setSelectedOrder(null);
    }
  };

  const handleUpdateProduction = (order: Order) => {
    setSelectedOrder(order);
    setProductionProgress(order.productionProgress || 0);
    setProductionNotes(order.notes || '');
    setShowProductionModal(true);
  };

  const handleSaveProductionUpdate = () => {
    if (selectedOrder) {
      setOrders(prev => prev.map(order => 
        order.id === selectedOrder.id 
          ? { 
              ...order, 
              productionProgress,
              notes: productionNotes,
              status: productionProgress >= 100 ? 'quality-check' as const : order.status
            }
          : order
      ));
      alert(`Production progress updated for ${selectedOrder.id}`);
      setShowProductionModal(false);
      setSelectedOrder(null);
      setProductionProgress(0);
      setProductionNotes('');
    }
  };

  const handleViewDetails = (order: Order) => {
    setSelectedOrder(order);
    setShowOrderModal(true);
  };

  const handleExportOrders = () => {
    console.log('Exporting orders data...');
    alert('Orders data exported successfully!');
  };

  // Stats for the header
  const orderStats = {
    total: orders.length,
    open: orders.filter(o => ['pending', 'confirmed'].includes(o.status)).length,
    inProduction: orders.filter(o => ['in-production', 'quality-check', 'ready-for-shipping'].includes(o.status)).length,
    delivered: orders.filter(o => o.status === 'delivered').length,
    revenue: orders.filter(o => o.paymentStatus === 'paid' || o.paymentStatus === 'partially-paid').reduce((sum, o) => sum + o.amount, 0)
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={onBack}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-700 transition-colors"
              >
                <AiOutlineArrowLeft size={20} />
                <span>Back to Dashboard</span>
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Order Management</h1>
                <p className="text-gray-600">Manage and track all customer orders</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button 
                onClick={handleExportOrders}
                className="flex items-center space-x-2 bg-white text-gray-700 border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 transition-all duration-200 font-medium"
              >
                <AiOutlineDownload size={18} />
                <span>Export Orders</span>
              </button>
            </div>
          </div>

          {/* Order Stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Orders</p>
                  <p className="text-2xl font-bold text-gray-900">{orderStats.total}</p>
                </div>
                <AiOutlineShoppingCart className="text-gray-400 text-xl" />
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Open Orders</p>
                  <p className="text-2xl font-bold text-blue-600">{orderStats.open}</p>
                </div>
                <AiOutlineClockCircle className="text-blue-400 text-xl" />
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">In Production</p>
                  <p className="text-2xl font-bold text-purple-600">{orderStats.inProduction}</p>
                </div>
                <AiOutlineExclamationCircle className="text-purple-400 text-xl" />
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Delivered</p>
                  <p className="text-2xl font-bold text-green-600">{orderStats.delivered}</p>
                </div>
                <AiOutlineCheckCircle className="text-green-400 text-xl" />
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Revenue</p>
                  <p className="text-2xl font-bold text-green-600">${orderStats.revenue}</p>
                </div>
                <AiOutlineDollar className="text-green-400 text-xl" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6 max-w-7xl mx-auto">
        {/* Tabs and Filters */}
        <div className="bg-white rounded-lg border border-gray-200 mb-6">
          <div className="p-4 border-b border-gray-200">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
              {/* Tabs */}
              <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setActiveTab('all')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === 'all'
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  All Orders ({orders.length})
                </button>
                <button
                  onClick={() => setActiveTab('open')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === 'open'
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  Open ({orderStats.open})
                </button>
                <button
                  onClick={() => setActiveTab('in-production')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === 'in-production'
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  In Production ({orderStats.inProduction})
                </button>
                <button
                  onClick={() => setActiveTab('completed')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === 'completed'
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  Completed ({orderStats.delivered})
                </button>
                <button
                  onClick={() => setActiveTab('cancelled')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === 'cancelled'
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  Cancelled ({orders.filter(o => o.status === 'cancelled').length})
                </button>
              </div>

              {/* Search and Filter */}
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <AiOutlineSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                  <input
                    type="text"
                    placeholder="Search orders..."
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Advanced Filters */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Order Status</option>
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="in-production">In Production</option>
                <option value="quality-check">Quality Check</option>
                <option value="ready-for-shipping">Ready for Shipping</option>
                <option value="shipped">Shipped</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
              </select>

              <select
                value={productTypeFilter}
                onChange={(e) => setProductTypeFilter(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Product Types</option>
                <option value="ready">Ready-made</option>
                <option value="customized">Customized</option>
              </select>

              <select
                value={paymentStatusFilter}
                onChange={(e) => setPaymentStatusFilter(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Payment Status</option>
                <option value="pending">Pending</option>
                <option value="partially-paid">Partially Paid</option>
                <option value="paid">Paid</option>
                <option value="refunded">Refunded</option>
              </select>

              <div className="flex space-x-2">
                <input
                  type="date"
                  value={dateRange.start}
                  onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent flex-1"
                  placeholder="Start Date"
                />
                <input
                  type="date"
                  value={dateRange.end}
                  onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent flex-1"
                  placeholder="End Date"
                />
              </div>
            </div>
          </div>

          {/* Orders Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Order ID</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Customer</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Product</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Type</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Amount</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Order Status</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Payment</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Priority</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50 transition">
                    <td className="py-4 px-6">
                      <div>
                        <p className="font-medium text-gray-900">{order.id}</p>
                        <p className="text-xs text-gray-500">{order.orderDate}</p>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div>
                        <p className="font-medium text-gray-900">{order.customerName}</p>
                        <p className="text-xs text-gray-500">{order.customerPhone}</p>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-3">
                        <img 
                          src={order.productImage} 
                          alt={order.productName}
                          className="w-12 h-12 object-cover rounded-lg"
                        />
                        <div>
                          <p className="font-medium text-gray-900 text-sm">{order.productName}</p>
                          <p className="text-xs text-gray-500">{order.seller}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                        order.productType === 'customized' 
                          ? 'bg-purple-100 text-purple-800' 
                          : 'bg-green-100 text-green-800'
                      }`}>
                        {order.productType}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <p className="font-bold text-gray-900">${order.amount}</p>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(order.status)}`}>
                        {order.status.split('-').map(word => 
                          word.charAt(0).toUpperCase() + word.slice(1)
                        ).join(' ')}
                      </span>
                      {order.productionProgress !== undefined && order.productionProgress > 0 && (
                        <div className="mt-1 w-full bg-gray-200 rounded-full h-1.5">
                          <div 
                            className="bg-blue-600 h-1.5 rounded-full" 
                            style={{ width: `${order.productionProgress}%` }}
                          ></div>
                        </div>
                      )}
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getPaymentStatusColor(order.paymentStatus)}`}>
                        {order.paymentStatus.split('-').map(word => 
                          word.charAt(0).toUpperCase() + word.slice(1)
                        ).join(' ')}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getPriorityColor(order.priority)}`}>
                        {order.priority.charAt(0).toUpperCase() + order.priority.slice(1)}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => handleViewDetails(order)}
                          className="text-blue-500 hover:text-blue-700 transition p-2 hover:bg-blue-50 rounded-lg"
                          title="View Details"
                        >
                          <AiOutlineEye size={16} />
                        </button>
                        
                        {order.status === 'pending' && (
                          <>
                            <button 
                              onClick={() => handleAcceptOrder(order.id)}
                              className="text-green-500 hover:text-green-700 transition p-2 hover:bg-green-50 rounded-lg"
                              title="Accept Order"
                            >
                              <AiOutlineCheck size={16} />
                            </button>
                            <button 
                              onClick={() => handleRejectOrder(order.id)}
                              className="text-red-500 hover:text-red-700 transition p-2 hover:bg-red-50 rounded-lg"
                              title="Reject Order"
                            >
                              <AiOutlineClose size={16} />
                            </button>
                          </>
                        )}
                        
                        {order.productType === 'customized' && order.status === 'confirmed' && !order.contractSent && (
                          <button 
                            onClick={() => {
                              setSelectedOrder(order);
                              setShowContractModal(true);
                            }}
                            className="text-purple-500 hover:text-purple-700 transition p-2 hover:bg-purple-50 rounded-lg"
                            title="Send Contract"
                          >
                            <AiOutlineFileText size={16} />
                          </button>
                        )}

                        {order.productType === 'customized' && ['in-production', 'quality-check'].includes(order.status) && (
                          <button 
                            onClick={() => handleUpdateProduction(order)}
                            className="text-orange-500 hover:text-orange-700 transition p-2 hover:bg-orange-50 rounded-lg"
                            title="Update Production"
                          >
                            <AiOutlineEdit size={16} />
                          </button>
                        )}

                        {!['pending', 'cancelled'].includes(order.status) && (
                          <button 
                            onClick={() => handleUpdateStatus(order)}
                            className="text-gray-500 hover:text-gray-700 transition p-2 hover:bg-gray-50 rounded-lg"
                            title="Update Status"
                          >
                            <AiOutlineTruck size={16} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {filteredOrders.length === 0 && (
              <div className="text-center py-8">
                <AiOutlineShoppingCart className="mx-auto text-gray-400 text-4xl mb-4" />
                <p className="text-gray-500 text-lg">No orders found</p>
                <p className="text-gray-400 text-sm">Try adjusting your filters or search query</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Order Details Modal */}
      {showOrderModal && selectedOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Order Details - {selectedOrder.id}</h2>
              <button 
                onClick={() => setShowOrderModal(false)}
                className="text-gray-500 hover:text-gray-700 p-2 hover:bg-gray-100 rounded-lg transition-all"
              >
                <AiOutlineClose size={24} />
              </button>
            </div>

            <div className="space-y-6">
              {/* Order Header */}
              <div className="bg-gray-50 rounded-xl p-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Order ID</p>
                    <p className="font-semibold text-gray-900">{selectedOrder.id}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">Order Date</p>
                    <p className="font-semibold text-gray-900">{selectedOrder.orderDate}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">Est. Delivery</p>
                    <p className="font-semibold text-gray-900">{selectedOrder.estimatedDelivery || 'Not set'}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">Seller</p>
                    <p className="font-semibold text-gray-900">{selectedOrder.seller}</p>
                  </div>
                </div>
              </div>

              {/* Status Overview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white border border-gray-200 rounded-xl p-4 text-center">
                  <p className="text-sm font-medium text-gray-600 mb-2">Order Status</p>
                  <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(selectedOrder.status)}`}>
                    {selectedOrder.status.split('-').map(word => 
                      word.charAt(0).toUpperCase() + word.slice(1)
                    ).join(' ')}
                  </span>
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-4 text-center">
                  <p className="text-sm font-medium text-gray-600 mb-2">Payment Status</p>
                  <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getPaymentStatusColor(selectedOrder.paymentStatus)}`}>
                    {selectedOrder.paymentStatus.split('-').map(word => 
                      word.charAt(0).toUpperCase() + word.slice(1)
                    ).join(' ')}
                  </span>
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-4 text-center">
                  <p className="text-sm font-medium text-gray-600 mb-2">Priority</p>
                  <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getPriorityColor(selectedOrder.priority)}`}>
                    {selectedOrder.priority.charAt(0).toUpperCase() + selectedOrder.priority.slice(1)}
                  </span>
                </div>
              </div>

              {/* Customer Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Customer Information</h3>
                <div className="bg-white border border-gray-200 rounded-xl p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Name</p>
                      <p className="font-medium text-gray-900">{selectedOrder.customerName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p className="font-medium text-gray-900">{selectedOrder.customerEmail}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Phone</p>
                      <p className="font-medium text-gray-900">{selectedOrder.customerPhone}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Address</p>
                      <p className="font-medium text-gray-900">{selectedOrder.address}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Product Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Product Information</h3>
                <div className="bg-white border border-gray-200 rounded-xl p-4">
                  <div className="flex items-center space-x-4">
                    <img 
                      src={selectedOrder.productImage} 
                      alt={selectedOrder.productName}
                      className="w-20 h-20 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 text-lg">{selectedOrder.productName}</h4>
                      <p className="text-sm text-gray-600 capitalize">{selectedOrder.productType} • {selectedOrder.category}</p>
                      <p className="text-xl font-bold text-gray-900 mt-2">${selectedOrder.amount}</p>
                    </div>
                  </div>
                  
                  {selectedOrder.customizationDetails && (
                    <div className="mt-4 space-y-3">
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-1">Customization Details</p>
                        <p className="text-sm text-gray-900 bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                          {selectedOrder.customizationDetails}
                        </p>
                      </div>
                      {selectedOrder.measurements && (
                        <div>
                          <p className="text-sm font-medium text-gray-600 mb-1">Measurements</p>
                          <p className="text-sm text-gray-900">{selectedOrder.measurements}</p>
                        </div>
                      )}
                      {selectedOrder.materials && (
                        <div>
                          <p className="text-sm font-medium text-gray-600 mb-1">Materials</p>
                          <p className="text-sm text-gray-900">{selectedOrder.materials}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-3 pt-4 border-t border-gray-200">
                <button 
                  onClick={() => setShowOrderModal(false)}
                  className="flex-1 bg-gray-500 text-white py-3 rounded-xl font-semibold hover:bg-gray-600 transition-all duration-200"
                >
                  Close
                </button>
                {selectedOrder.status === 'pending' && (
                  <>
                    <button 
                      onClick={() => handleAcceptOrder(selectedOrder.id)}
                      className="flex-1 bg-green-500 text-white py-3 rounded-xl font-semibold hover:bg-green-600 transition-all duration-200"
                    >
                      Accept Order
                    </button>
                    <button 
                      onClick={() => handleRejectOrder(selectedOrder.id)}
                      className="flex-1 bg-red-500 text-white py-3 rounded-xl font-semibold hover:bg-red-600 transition-all duration-200"
                    >
                      Reject Order
                    </button>
                  </>
                )}
                {selectedOrder.productType === 'customized' && selectedOrder.status === 'confirmed' && !selectedOrder.contractSent && (
                  <button 
                    onClick={() => setShowContractModal(true)}
                    className="flex-1 bg-purple-500 text-white py-3 rounded-xl font-semibold hover:bg-purple-600 transition-all duration-200"
                  >
                    Send Contract
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Update Status Modal */}
      {showUpdateStatusModal && selectedOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-900">Update Order Status</h2>
              <button 
                onClick={() => setShowUpdateStatusModal(false)}
                className="text-gray-500 hover:text-gray-700 p-2 hover:bg-gray-100 rounded-lg transition-all"
              >
                <AiOutlineClose size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <p className="text-gray-600">
                Update status for order <strong>{selectedOrder.id}</strong>
              </p>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Order Status
                </label>
                <select 
                  id="statusSelect"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  defaultValue={selectedOrder.status}
                >
                  <option value="pending">Pending</option>
                  <option value="confirmed">Confirmed</option>
                  <option value="in-production">In Production</option>
                  <option value="quality-check">Quality Check</option>
                  <option value="ready-for-shipping">Ready for Shipping</option>
                  <option value="shipped">Shipped</option>
                  <option value="delivered">Delivered</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>

              <div className="flex items-center space-x-3 pt-4">
                <button 
                  onClick={() => setShowUpdateStatusModal(false)}
                  className="flex-1 bg-gray-500 text-white py-3 rounded-lg font-semibold hover:bg-gray-600 transition-all duration-200"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleConfirmStatusUpdate}
                  className="flex-1 bg-blue-500 text-white py-3 rounded-lg font-semibold hover:bg-blue-600 transition-all duration-200"
                >
                  Update Status
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Production Update Modal */}
      {showProductionModal && selectedOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-900">Update Production Progress</h2>
              <button 
                onClick={() => setShowProductionModal(false)}
                className="text-gray-500 hover:text-gray-700 p-2 hover:bg-gray-100 rounded-lg transition-all"
              >
                <AiOutlineClose size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <p className="text-gray-600">
                Update production for <strong>{selectedOrder.productName}</strong>
              </p>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Production Progress: {productionProgress}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={productionProgress}
                  onChange={(e) => setProductionProgress(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>0%</span>
                  <span>50%</span>
                  <span>100%</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Production Notes
                </label>
                <textarea
                  value={productionNotes}
                  onChange={(e) => setProductionNotes(e.target.value)}
                  placeholder="Add notes about production progress, issues, or updates..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  rows={4}
                />
              </div>

              <div className="flex items-center space-x-3 pt-4">
                <button 
                  onClick={() => setShowProductionModal(false)}
                  className="flex-1 bg-gray-500 text-white py-3 rounded-lg font-semibold hover:bg-gray-600 transition-all duration-200"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleSaveProductionUpdate}
                  className="flex-1 bg-blue-500 text-white py-3 rounded-lg font-semibold hover:bg-blue-600 transition-all duration-200"
                >
                  Save Progress
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Reject Order Modal */}
      {showRejectModal && selectedOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-900">Reject Order</h2>
              <button 
                onClick={() => setShowRejectModal(false)}
                className="text-gray-500 hover:text-gray-700 p-2 hover:bg-gray-100 rounded-lg transition-all"
              >
                <AiOutlineClose size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <p className="text-gray-600">
                Are you sure you want to reject order <strong>{selectedOrder.id}</strong>?
              </p>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reason for rejection
                </label>
                <textarea
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  placeholder="Please provide a reason for rejecting this order..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                  rows={4}
                />
              </div>

              <div className="flex items-center space-x-3 pt-4">
                <button 
                  onClick={() => setShowRejectModal(false)}
                  className="flex-1 bg-gray-500 text-white py-3 rounded-lg font-semibold hover:bg-gray-600 transition-all duration-200"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleConfirmRejection}
                  disabled={!rejectReason.trim()}
                  className="flex-1 bg-red-500 text-white py-3 rounded-lg font-semibold hover:bg-red-600 disabled:bg-red-300 disabled:cursor-not-allowed transition-all duration-200"
                >
                  Confirm Rejection
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Send Contract Modal */}
      {showContractModal && selectedOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-900">Send Contract</h2>
              <button 
                onClick={() => setShowContractModal(false)}
                className="text-gray-500 hover:text-gray-700 p-2 hover:bg-gray-100 rounded-lg transition-all"
              >
                <AiOutlineClose size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <p className="text-gray-600">
                Send contract for custom furniture order <strong>{selectedOrder.id}</strong> to {selectedOrder.customerName}?
              </p>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-700">
                  A digital contract will be sent to {selectedOrder.customerEmail} with all specifications and terms.
                  The customer must accept the contract before production can begin.
                </p>
              </div>

              <div className="flex items-center space-x-3 pt-4">
                <button 
                  onClick={() => setShowContractModal(false)}
                  className="flex-1 bg-gray-500 text-white py-3 rounded-lg font-semibold hover:bg-gray-600 transition-all duration-200"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleSendContract}
                  className="flex-1 bg-blue-500 text-white py-3 rounded-lg font-semibold hover:bg-blue-600 transition-all duration-200"
                >
                  Send Contract
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrdersPage;