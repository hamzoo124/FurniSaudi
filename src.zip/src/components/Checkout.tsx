import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, CreditCard, Shield, Truck, Check, Wallet, 
  MapPin, User, Phone, Home, Package, MessageSquare, Lock
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface CheckoutProps {
  onNavigate: (page: string, data?: any) => void;
  cartItems?: any[];
  onOrderSuccess: () => void;
  directOrder?: any;
}

interface AddressFormData {
  fullName: string;
  phone: string;
  address: string;
  city: string;
  district: string;
  postalCode: string;
  additionalNotes: string;
}

export const Checkout: React.FC<CheckoutProps> = ({ 
  onNavigate, 
  cartItems = [], 
  onOrderSuccess,
  directOrder 
}) => {
  const { user } = useAuth();
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [orderComplete, setOrderComplete] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [loadedDirectOrder, setLoadedDirectOrder] = useState<any>(null);
  const [addressForm, setAddressForm] = useState<AddressFormData>({
    fullName: user?.name || '',
    phone: '+966 ',
    address: '',
    city: 'Riyadh',
    district: '',
    postalCode: '',
    additionalNotes: ''
  });

  // Load direct order from localStorage
  useEffect(() => {
    console.log('🔍 Checkout component mounted');
    
    // Check localStorage for direct order data
    const savedDirectOrder = localStorage.getItem('directOrderData');
    if (savedDirectOrder) {
      console.log('📦 Found direct order in localStorage:', JSON.parse(savedDirectOrder));
      setLoadedDirectOrder(JSON.parse(savedDirectOrder));
      localStorage.removeItem('directOrderData');
    }
    
    // Also check for pending direct order
    const pendingDirectOrder = localStorage.getItem('pending_direct_order');
    if (pendingDirectOrder) {
      console.log('⏳ Found pending direct order:', JSON.parse(pendingDirectOrder));
      setLoadedDirectOrder(JSON.parse(pendingDirectOrder));
      localStorage.removeItem('pending_direct_order');
    }
    
    // If directOrder prop is passed, use it
    if (directOrder) {
      console.log('🎯 Direct order from props:', directOrder);
      setLoadedDirectOrder(directOrder);
    }

    // Load user data if available
    if (user?.name) {
      setAddressForm(prev => ({ ...prev, fullName: user.name }));
    }
  }, [directOrder, user]);

  // Determine if this is a direct checkout or cart checkout
  const isDirectCheckout = !!loadedDirectOrder || !!directOrder;
  
  // Get the current order data
  const getCurrentOrder = () => {
    return loadedDirectOrder || directOrder;
  };

  // Prepare order items based on checkout type
  const orderItems = isDirectCheckout 
    ? [{
        product: getCurrentOrder()?.product,
        quantity: getCurrentOrder()?.quantity || 1,
        customization: getCurrentOrder()?.product?.customization || null,
        sellerInfo: getCurrentOrder()?.seller || null,
        deliveryInfo: getCurrentOrder()?.deliveryInfo || null,
        unitPrice: getCurrentOrder()?.product?.finalPrice || getCurrentOrder()?.product?.price || 0
      }]
    : cartItems.map(item => ({
        product: item.product,
        quantity: item.quantity,
        customization: item.customization || null,
        sellerInfo: null,
        deliveryInfo: null,
        unitPrice: item.product.finalPrice || item.product.price
      }));

  const calculateSubtotal = () => {
    if (isDirectCheckout) {
      const order = getCurrentOrder();
      return parseFloat(order?.product?.finalPrice || order?.product?.price || 0) * (order?.quantity || 1);
    }
    return cartItems.reduce((total, item) => {
      const itemPrice = item.product.finalPrice || item.product.price;
      return total + (parseFloat(itemPrice) * item.quantity);
    }, 0);
  };

  const calculateDeliveryFee = () => {
    if (isDirectCheckout) {
      const order = getCurrentOrder();
      return parseFloat(order?.deliveryInfo?.delivery_price) || 0;
    }
    return 0;
  };

  const calculateTotal = () => {
    const subtotal = calculateSubtotal();
    const deliveryFee = calculateDeliveryFee();
    return subtotal + deliveryFee;
  };

  const handleAddressChange = (field: keyof AddressFormData, value: string) => {
    setAddressForm(prev => ({ ...prev, [field]: value }));
  };

  const validateAddress = () => {
    if (!addressForm.fullName.trim()) {
      alert('Please enter your full name');
      return false;
    }
    if (!addressForm.phone.trim() || addressForm.phone.length < 9) {
      alert('Please enter a valid phone number');
      return false;
    }
    if (!addressForm.address.trim()) {
      alert('Please enter your address');
      return false;
    }
    if (!addressForm.city.trim()) {
      alert('Please select your city');
      return false;
    }
    return true;
  };

  const handlePlaceOrder = async () => {
    // Validate address
    if (!validateAddress()) {
      return;
    }

    setIsProcessing(true);

    // Get user info (guest or logged in)
    const userInfo = user ? {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone || addressForm.phone
    } : {
      id: `guest_${Date.now()}`,
      name: addressForm.fullName,
      email: `${addressForm.fullName.replace(/\s+/g, '.').toLowerCase()}@guest.com`,
      phone: addressForm.phone,
      isGuest: true
    };

    // Create complete order object
    const order = {
      id: `order_${Date.now()}`,
      orderNumber: `ORD${Date.now().toString().slice(-6)}`,
      userId: userInfo.id,
      userName: userInfo.name,
      userEmail: userInfo.email,
      userPhone: userInfo.phone,
      items: orderItems,
      subtotal: calculateSubtotal(),
      deliveryFee: calculateDeliveryFee(),
      total: calculateTotal(),
      paymentMethod,
      status: 'pending', // Always start as pending
      paymentStatus: paymentMethod === 'cash' ? 'pending' : 'paid',
      deliveryAddress: addressForm,
      deliveryInfo: isDirectCheckout 
        ? getCurrentOrder()?.deliveryInfo 
        : {
            delivery_option: 'free',
            delivery_price: 0,
            delivery_time: '3-5 business days'
          },
      sellerInfo: isDirectCheckout ? getCurrentOrder()?.seller : null,
      orderType: isDirectCheckout ? 'direct' : 'cart',
      isGuest: !user,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      notes: addressForm.additionalNotes
    };

    console.log('💾 Saving order to seller dashboard:', order);

    try {
      // 1. Save to ALL orders list (for seller dashboard)
      const allOrders = JSON.parse(localStorage.getItem('allOrders') || '[]');
      localStorage.setItem('allOrders', JSON.stringify([...allOrders, order]));

      // 2. Save to user-specific orders
      const userOrders = JSON.parse(localStorage.getItem('userOrders') || '[]');
      localStorage.setItem('userOrders', JSON.stringify([...userOrders, order]));

      // 3. Save to logged-in user's orders if applicable
      if (user) {
        const userSpecificOrders = JSON.parse(localStorage.getItem(`user_${user.id}_orders`) || '[]');
        localStorage.setItem(`user_${user.id}_orders`, JSON.stringify([...userSpecificOrders, order]));
      }

      // 4. Save to seller's orders (CRITICAL for seller dashboard)
      if (order.sellerInfo?.id) {
        // Save to seller's orders list
        const sellerOrdersKey = `seller_${order.sellerInfo.id}_orders`;
        const sellerOrders = JSON.parse(localStorage.getItem(sellerOrdersKey) || '[]');
        localStorage.setItem(sellerOrdersKey, JSON.stringify([...sellerOrders, order]));

        // Save to seller's dashboard active orders
        const sellerDashboardKey = `seller_dashboard_${order.sellerInfo.id}`;
        const sellerDashboardOrders = JSON.parse(localStorage.getItem(sellerDashboardKey) || '[]');
        localStorage.setItem(sellerDashboardKey, JSON.stringify([...sellerDashboardOrders, order]));

        // Save to seller's recent orders (last 50)
        const sellerRecentKey = `seller_recent_${order.sellerInfo.id}`;
        const sellerRecentOrders = JSON.parse(localStorage.getItem(sellerRecentKey) || '[]');
        const updatedRecent = [order, ...sellerRecentOrders].slice(0, 50);
        localStorage.setItem(sellerRecentKey, JSON.stringify(updatedRecent));

        console.log(`✅ Order saved to seller ${order.sellerInfo.id} dashboard`);
      } else {
        // If no seller info, save to default seller (for testing)
        const defaultSellerId = '1'; // Your default seller ID
        const defaultSellerOrders = JSON.parse(localStorage.getItem(`seller_${defaultSellerId}_orders`) || '[]');
        localStorage.setItem(`seller_${defaultSellerId}_orders`, JSON.stringify([...defaultSellerOrders, order]));
        
        const defaultDashboard = JSON.parse(localStorage.getItem(`seller_dashboard_${defaultSellerId}`) || '[]');
        localStorage.setItem(`seller_dashboard_${defaultSellerId}`, JSON.stringify([...defaultDashboard, order]));
      }

      // 5. Clear cart only if not a direct order
      if (!isDirectCheckout) {
        localStorage.removeItem(`user_${user?.id}_cart`);
        localStorage.removeItem('cart');
      }

      // 6. Clear pending data
      localStorage.removeItem('pending_checkout_data');
      localStorage.removeItem('pending_direct_order');
      localStorage.removeItem('directOrderData');

      // 7. Show success and redirect
      setTimeout(() => {
        setIsProcessing(false);
        setOrderComplete(true);
        onOrderSuccess();
      }, 1500);

    } catch (error) {
      console.error('❌ Error saving order:', error);
      alert('Error placing order. Please try again.');
      setIsProcessing(false);
    }
  };

  if (orderComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 text-center max-w-md w-full border border-gray-200">
          <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-gray-800 mb-3">Order Confirmed! 🎉</h2>
          <p className="text-gray-600 mb-6">
            Thank you for your purchase. Your order has been placed successfully and is being processed.
          </p>
          
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-5 mb-6">
            <div className="flex items-center justify-center mb-3">
              <Package className="w-6 h-6 text-green-600 mr-2" />
              <p className="font-semibold text-green-800 text-lg">Order Details</p>
            </div>
            <div className="space-y-2 text-left">
              <div className="flex justify-between">
                <span className="text-gray-700">Order Total:</span>
                <span className="font-bold text-green-700">{calculateTotal().toFixed(2)} SR</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-700">Payment:</span>
                <span className="font-medium text-gray-800">
                  {paymentMethod === 'cash' ? '💵 Cash on Delivery' : '💳 Paid Online'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-700">Delivery:</span>
                <span className="font-medium text-gray-800">
                  {isDirectCheckout ? '🚀 Express Delivery' : '📦 Standard Delivery'}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-5 mb-6">
            <div className="flex items-center justify-center mb-3">
              <MapPin className="w-6 h-6 text-amber-600 mr-2" />
              <p className="font-semibold text-amber-800">Delivery Address</p>
            </div>
            <div className="text-sm text-amber-700 text-left">
              <p className="font-medium">{addressForm.fullName}</p>
              <p>{addressForm.address}</p>
              <p>{addressForm.district && `${addressForm.district}, `}{addressForm.city}</p>
              <p>{addressForm.postalCode && `Postal: ${addressForm.postalCode}`}</p>
              <p className="mt-2">📞 {addressForm.phone}</p>
            </div>
          </div>

          <button
            onClick={() => onNavigate('home')}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-white py-4 rounded-xl font-bold text-lg hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg hover:shadow-xl"
          >
            Continue Shopping
          </button>
          
          <p className="text-sm text-gray-500 mt-4">
            A confirmation email has been sent. Order will appear in seller dashboard.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => isDirectCheckout ? onNavigate('home') : onNavigate('cart')}
              className="flex items-center space-x-2 text-gray-600 hover:text-amber-500 transition-colors group"
            >
              <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              <span className="font-medium">
                {isDirectCheckout ? 'Back to Home' : 'Back to Cart'}
              </span>
            </button>
            <div className="flex items-center space-x-2">
              <Lock className="w-5 h-5 text-green-500" />
              <span className="text-sm text-gray-600">Secure Checkout • SSL Encrypted</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Checkout</h1>
            <div className="flex items-center space-x-2 mt-2">
              <div className="flex items-center">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                <span className="text-sm text-gray-600">Secure • Fast • Reliable</span>
              </div>
            </div>
          </div>
          {isDirectCheckout && (
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-2 rounded-full shadow-lg">
              <span className="font-medium">🚀 Express Checkout</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column: Order Summary & Address */}
          <div className="space-y-6">
            {/* Order Summary */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800 flex items-center">
                  <Package className="w-6 h-6 mr-2 text-amber-500" />
                  Order Summary
                </h2>
                <span className="text-sm font-medium text-gray-500">
                  {orderItems.length} {orderItems.length === 1 ? 'item' : 'items'}
                </span>
              </div>
              
              <div className="space-y-4">
                {orderItems.map((item, index) => (
                  <div key={index} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                    <div className="relative">
                      <img
                        src={item.product?.images?.[0]}
                        alt={item.product?.title || item.product?.name}
                        className="w-20 h-20 object-cover rounded-lg border-2 border-white shadow"
                      />
                      {(item.customization || item.product?.customization) && (
                        <div className="absolute -top-2 -right-2 bg-purple-500 text-white text-xs px-2 py-1 rounded-full">
                          🎨 Custom
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800">{item.product?.title || item.product?.name}</h3>
                      <div className="flex items-center space-x-4 mt-1">
                        <span className="text-sm text-gray-600">Qty: {item.quantity}</span>
                        <span className="text-sm font-medium text-amber-600">
                          {parseFloat(item.unitPrice || 0).toFixed(2)} SR each
                        </span>
                      </div>
                      {item.sellerInfo && (
                        <p className="text-xs text-gray-500 mt-1">
                          Seller: <span className="font-medium">{item.sellerInfo.business_name}</span>
                        </p>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-amber-600">
                        {(parseFloat(item.unitPrice || 0) * item.quantity).toFixed(2)} SR
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="border-t border-gray-200 pt-6 mt-6 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">{calculateSubtotal().toFixed(2)} SR</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Delivery</span>
                  <span className={calculateDeliveryFee() === 0 ? 'font-medium text-green-600' : 'font-medium text-gray-700'}>
                    {calculateDeliveryFee() === 0 ? 'FREE' : `${calculateDeliveryFee().toFixed(2)} SR`}
                  </span>
                </div>
                <div className="flex justify-between items-center text-lg font-bold pt-3 border-t border-gray-300">
                  <span>Total Amount</span>
                  <span className="text-2xl text-amber-600">{calculateTotal().toFixed(2)} SR</span>
                </div>
              </div>
            </div>

            {/* Delivery Address Form */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <div className="flex items-center mb-6">
                <MapPin className="w-6 h-6 mr-2 text-blue-500" />
                <h2 className="text-xl font-bold text-gray-800">Delivery Address</h2>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <User className="w-4 h-4 inline mr-1" />
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={addressForm.fullName}
                      onChange={(e) => handleAddressChange('fullName', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="Enter your full name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Phone className="w-4 h-4 inline mr-1" />
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={addressForm.phone}
                      onChange={(e) => handleAddressChange('phone', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="+966 500 000 000"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Home className="w-4 h-4 inline mr-1" />
                    Full Address *
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={addressForm.address}
                    onChange={(e) => handleAddressChange('address', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                    placeholder="Street address, building, apartment, suite, etc."
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">City *</label>
                    <select
                      value={addressForm.city}
                      onChange={(e) => handleAddressChange('city', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white"
                    >
                      <option value="Riyadh">Riyadh</option>
                      <option value="Jeddah">Jeddah</option>
                      <option value="Dammam">Dammam</option>
                      <option value="Mecca">Mecca</option>
                      <option value="Medina">Medina</option>
                      <option value="Khobar">Khobar</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">District</label>
                    <input
                      type="text"
                      value={addressForm.district}
                      onChange={(e) => handleAddressChange('district', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="District / Area"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Postal Code</label>
                    <input
                      type="text"
                      value={addressForm.postalCode}
                      onChange={(e) => handleAddressChange('postalCode', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="12345"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <MessageSquare className="w-4 h-4 inline mr-1" />
                    Additional Notes
                  </label>
                  <textarea
                    rows={2}
                    value={addressForm.additionalNotes}
                    onChange={(e) => handleAddressChange('additionalNotes', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                    placeholder="Delivery instructions, gate code, etc."
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Payment & Order Button */}
          <div className="space-y-6">
            {/* Payment Method */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <div className="flex items-center mb-6">
                <CreditCard className="w-6 h-6 mr-2 text-purple-500" />
                <h2 className="text-xl font-bold text-gray-800">Payment Method</h2>
              </div>
              
              <div className="space-y-3">
                {[
                  { value: 'card', icon: CreditCard, label: 'Credit/Debit Card', color: 'text-blue-500' },
                  { value: 'cash', icon: Wallet, label: 'Cash on Delivery', color: 'text-green-500' },
                  { value: 'mada', label: 'Mada', color: 'text-red-500' },
                  { value: 'apple-pay', label: 'Apple Pay', color: 'text-black' }
                ].map((method) => (
                  <label 
                    key={method.value}
                    className={`flex items-center space-x-4 p-4 border-2 rounded-xl cursor-pointer transition-all hover:scale-[1.02] ${
                      paymentMethod === method.value 
                        ? 'border-amber-500 bg-amber-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      value={method.value}
                      checked={paymentMethod === method.value}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="w-5 h-5 text-amber-500 focus:ring-amber-500"
                    />
                    {method.icon && <method.icon className={`w-5 h-5 ${method.color}`} />}
                    <span className="flex-1 font-medium">{method.label}</span>
                    {method.value === 'cash' && (
                      <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">No fees</span>
                    )}
                  </label>
                ))}
              </div>

              {paymentMethod === 'cash' && (
                <div className="mt-4 p-4 bg-gradient-to-r from-yellow-50 to-amber-50 border border-yellow-200 rounded-xl">
                  <div className="flex items-center mb-2">
                    <Wallet className="w-5 h-5 text-yellow-600 mr-2" />
                    <p className="font-semibold text-yellow-800">Cash on Delivery</p>
                  </div>
                  <p className="text-sm text-yellow-700">
                    💵 Pay cash when your order arrives. Please have exact change ready. 
                    No additional payment processing fees.
                  </p>
                </div>
              )}
            </div>

            {/* Delivery Info */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <div className="flex items-center mb-4">
                <Truck className="w-6 h-6 mr-2 text-green-500" />
                <h2 className="text-xl font-bold text-gray-800">Delivery Information</h2>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl">
                  <span className="font-medium text-gray-700">Delivery Fee</span>
                  <span className="font-bold text-green-600 text-lg">
                    {calculateDeliveryFee() === 0 ? 'FREE' : `${calculateDeliveryFee().toFixed(2)} SR`}
                  </span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-xl">
                  <span className="font-medium text-gray-700">Estimated Delivery</span>
                  <span className="font-semibold text-blue-700">
                    {isDirectCheckout 
                      ? (getCurrentOrder()?.deliveryInfo?.delivery_time || '3-5 business days')
                      : '3-5 business days'
                    }
                  </span>
                </div>
                
                {isDirectCheckout && getCurrentOrder()?.sellerInfo && (
                  <div className="p-3 bg-purple-50 rounded-xl">
                    <p className="text-sm font-medium text-purple-800 mb-1">Seller Information</p>
                    <p className="text-sm text-purple-700">
                      {getCurrentOrder()?.sellerInfo?.business_name} • {getCurrentOrder()?.deliveryInfo?.delivery_option || 'Standard delivery'}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Order Button & Security */}
            <div className="space-y-4">
              <button
                onClick={handlePlaceOrder}
                disabled={isProcessing}
                className={`w-full py-5 rounded-2xl font-bold text-lg transition-all shadow-lg hover:shadow-xl ${
                  isProcessing 
                    ? 'bg-gray-400 cursor-not-allowed' 
                    : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700'
                } text-white flex items-center justify-center space-x-3`}
              >
                {isProcessing ? (
                  <>
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                    <span>Processing Your Order...</span>
                  </>
                ) : (
                  <>
                    <Shield className="w-6 h-6" />
                    <div className="text-center">
                      <div className="text-xl">
                        {paymentMethod === 'cash' ? 'Place Order' : 'Pay Now'} - {calculateTotal().toFixed(2)} SR
                      </div>
                      <div className="text-sm font-normal opacity-90">
                        {!user ? 'Guest Checkout • No login required' : 'Secure Payment'}
                      </div>
                    </div>
                    <Lock className="w-5 h-5" />
                  </>
                )}
              </button>

              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-5">
                <div className="flex items-center mb-3">
                  <Shield className="w-5 h-5 mr-2 text-blue-500" />
                  <h4 className="font-semibold text-blue-800">100% Secure Checkout</h4>
                </div>
                <div className="space-y-2 text-sm text-blue-700">
                  <p className="flex items-center">
                    <Check className="w-4 h-4 mr-2 text-green-500" />
                    Your payment information is secured with bank-level 256-bit SSL encryption
                  </p>
                  <p className="flex items-center">
                    <Check className="w-4 h-4 mr-2 text-green-500" />
                    {isDirectCheckout 
                      ? 'Direct factory order - No middlemen, best prices'
                      : 'Order will appear in seller dashboard immediately'
                    }
                  </p>
                  <p className="flex items-center">
                    <Check className="w-4 h-4 mr-2 text-green-500" />
                    Money-back guarantee • 24/7 customer support
                  </p>
                </div>
                {!user && (
                  <p className="text-xs text-blue-600 mt-3 pt-3 border-t border-blue-200">
                    💡 <strong>Guest Checkout:</strong> You can complete your order without creating an account. 
                    Your order will be saved and you can track it using your phone number.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};