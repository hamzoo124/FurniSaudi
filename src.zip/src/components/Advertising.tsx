import React, { useState, useEffect } from 'react';
import {
  AiOutlineArrowLeft,
  AiOutlineDollar,
  AiOutlineCalendar,
  AiOutlinePicture,
  AiOutlineShopping,
  AiOutlineRocket,
  AiOutlineFacebook,
  AiOutlineInstagram,
  AiOutlineTwitter,
  AiOutlineGoogle,
  AiOutlineCheckCircle,
  AiOutlineInfoCircle,
  AiOutlineUpload,
  AiOutlineEye,
  AiOutlineEdit,
  AiOutlinePlus,
  AiOutlineDelete,
  AiOutlinePause,
  AiOutlinePlayCircle,
  AiOutlineBarChart,
  AiOutlineTeam,
  AiOutlineSetting,
  AiOutlineUser,
  AiOutlineEnvironment
} from 'react-icons/ai';

interface AdvertisingPageProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
}

interface AdCampaign {
  id: string;
  name: string;
  platform: 'own-platform' | 'facebook' | 'instagram' | 'google' | 'twitter';
  budget: number;
  duration: number;
  dailyBudget: number;
  totalSpent: number;
  startDate: string;
  endDate: string;
  targetAudience: string[];
  furnitureType: 'customized' | 'ready-made' | 'both';
  adSource: 'existing-listing' | 'new-listing';
  images: string[];
  status: 'draft' | 'active' | 'paused' | 'completed';
  demographics: {
    ageRange: [number, number];
    gender: string[];
    interests: string[];
    locations: string[];
  };
  impressions: number;
  clicks: number;
  conversions: number;
  ctr: number;
  conversionRate: number;
  dailyStats: Array<{
    date: string;
    impressions: number;
    clicks: number;
    spent: number;
    conversions: number;
  }>;
  createdAt: string;
  updatedAt: string;
}

const AdvertisingPage: React.FC<AdvertisingPageProps> = ({ onNavigate, onBack }) => {
  // ✅ MOVE THE updateCampaignStats FUNCTION TO THE TOP
  const updateCampaignStats = (campaign: AdCampaign): AdCampaign => {
    if (campaign.status !== 'active') return campaign;

    const now = new Date();
    const start = new Date(campaign.startDate);
    const end = new Date(campaign.endDate);
    const totalDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    const daysPassed = Math.ceil((now.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    
    const progress = Math.min((daysPassed / totalDays) * 100, 100);
    const totalSpent = Math.min(campaign.dailyBudget * daysPassed, campaign.budget);
    
    // Generate realistic performance metrics based on budget and targeting
    const baseImpressions = campaign.budget * 20;
    const platformMultiplier = {
      'own-platform': 1.2,
      'facebook': 3.5,
      'instagram': 2.8,
      'google': 2.2,
      'twitter': 1.8
    };
    
    const impressions = Math.floor(baseImpressions * platformMultiplier[campaign.platform] * (progress / 100));
    const clicks = Math.floor(impressions * 0.05);
    const conversions = Math.floor(clicks * 0.08);
    
    // Generate daily stats
    const dailyStats = [];
    for (let i = 0; i <= daysPassed; i++) {
      const date = new Date(start);
      date.setDate(start.getDate() + i);
      
      dailyStats.push({
        date: date.toISOString().split('T')[0],
        impressions: Math.floor((impressions / (daysPassed + 1)) * (0.8 + Math.random() * 0.4)),
        clicks: Math.floor((clicks / (daysPassed + 1)) * (0.8 + Math.random() * 0.4)),
        spent: campaign.dailyBudget,
        conversions: Math.floor((conversions / (daysPassed + 1)) * (0.8 + Math.random() * 0.4))
      });
    }

    return {
      ...campaign,
      totalSpent,
      impressions,
      clicks,
      conversions,
      ctr: clicks / impressions,
      conversionRate: conversions / clicks,
      dailyStats
    };
  };

  const [activeTab, setActiveTab] = useState<'create' | 'active' | 'history' | 'analytics'>('create');
  const [selectedPlatform, setSelectedPlatform] = useState<'own-platform' | 'facebook' | 'instagram' | 'google' | 'twitter'>('own-platform');
  const [budget, setBudget] = useState<number>(1000);
  const [duration, setDuration] = useState<number>(14);
  const [furnitureType, setFurnitureType] = useState<'customized' | 'ready-made' | 'both'>('both');
  const [adSource, setAdSource] = useState<'existing-listing' | 'new-listing'>('existing-listing');
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [campaignName, setCampaignName] = useState<string>('');
  const [targetAudience, setTargetAudience] = useState<string[]>([]);
  const [step, setStep] = useState<number>(1);
  const [isCreating, setIsCreating] = useState<boolean>(false);
  
  const [demographics, setDemographics] = useState({
    ageRange: [25, 55] as [number, number],
    gender: ['male', 'female'],
    interests: [] as string[],
    locations: ['Riyadh', 'Jeddah']
  });

  const [activeCampaigns, setActiveCampaigns] = useState<AdCampaign[]>(() => {
    const saved = localStorage.getItem('adCampaigns');
    if (saved) {
      const campaigns = JSON.parse(saved);
      return campaigns.map((campaign: AdCampaign) => updateCampaignStats(campaign));
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem('adCampaigns', JSON.stringify(activeCampaigns));
    
    // Also save to a separate key for home page
    const activeAds = activeCampaigns.filter(camp => camp.status === 'active');
    localStorage.setItem('activeAdCampaigns', JSON.stringify(activeAds));
    
    // Trigger storage event to update home page
    window.dispatchEvent(new Event('storage'));
  }, [activeCampaigns]);

  const [existingProducts] = useState([
    { 
      id: '1', 
      name: 'Modern Leather Sofa', 
      price: 1200, 
      image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=300&h=200&fit=crop',
      type: 'ready-made',
      category: 'Living Room'
    },
    { 
      id: '2', 
      name: 'Wooden Dining Table', 
      price: 800, 
      image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=300&h=200&fit=crop',
      type: 'ready-made',
      category: 'Dining Room'
    },
    { 
      id: '3', 
      name: 'Office Ergonomic Chair', 
      price: 450, 
      image: 'https://images.unsplash.com/photo-1503602642458-232111445657?w=300&h=200&fit=crop',
      type: 'customized',
      category: 'Office'
    },
  ]);

  const platforms = [
    {
      id: 'own-platform',
      name: 'Our Platform',
      description: 'Advertise directly on our website and app',
      icon: <AiOutlineShopping className="text-xl" />,
      color: 'bg-gradient-to-r from-blue-500 to-blue-600',
      reach: 'High engagement from furniture buyers'
    },
    {
      id: 'facebook',
      name: 'Facebook',
      description: 'Reach customers on Facebook with targeted ads',
      icon: <AiOutlineFacebook className="text-xl" />,
      color: 'bg-gradient-to-r from-blue-600 to-blue-700',
      reach: '2.9B+ monthly active users'
    },
    {
      id: 'instagram',
      name: 'Instagram',
      description: 'Showcase your furniture with visual ads on Instagram',
      icon: <AiOutlineInstagram className="text-xl" />,
      color: 'bg-gradient-to-r from-pink-500 to-pink-600',
      reach: '1.3B+ monthly active users'
    },
    {
      id: 'google',
      name: 'Google Ads',
      description: 'Appear in Google search results and display network',
      icon: <AiOutlineGoogle className="text-xl" />,
      color: 'bg-gradient-to-r from-green-500 to-green-600',
      reach: 'Google search and partner sites'
    },
    {
      id: 'twitter',
      name: 'Twitter',
      description: 'Promote your furniture to engaged audiences on Twitter',
      icon: <AiOutlineTwitter className="text-xl" />,
      color: 'bg-gradient-to-r from-blue-400 to-blue-500',
      reach: '550M+ monthly active users'
    }
  ];

  const furnitureTypes = [
    { id: 'customized', name: 'Customized Furniture', description: 'Made-to-order pieces', icon: '🎨' },
    { id: 'ready-made', name: 'Ready-Made Furniture', description: 'In-stock items', icon: '📦' },
    { id: 'both', name: 'Both Types', description: 'Showcase all furniture', icon: '🏪' }
  ];

  const adSources = [
    { id: 'existing-listing', name: 'Existing Listing', description: 'Promote products already in your catalog', icon: '📋' },
    { id: 'new-listing', name: 'New Listing', description: 'Create a special ad-only listing', icon: '🆕' }
  ];

  const audienceOptions = [
    { id: 'home-owners', name: 'Home Owners', description: 'People looking to furnish their homes' },
    { id: 'interior-designers', name: 'Interior Designers', description: 'Professional designers and studios' },
    { id: 'luxury-buyers', name: 'Luxury Buyers', description: 'High-end furniture shoppers' },
    { id: 'first-time-buyers', name: 'First-time Buyers', description: 'New homeowners and renters' },
    { id: 'office-managers', name: 'Office Managers', description: 'Business and office furniture buyers' },
    { id: 'real-estate-agents', name: 'Real Estate Agents', description: 'Staging and property professionals' },
    { id: 'design-studios', name: 'Design Studios', description: 'Creative agencies and studios' },
    { id: 'hotel-chains', name: 'Hotel Chains', description: 'Hospitality industry buyers' }
  ];

  const genderOptions = [
    { id: 'male', name: 'Male' },
    { id: 'female', name: 'Female' },
    { id: 'all', name: 'All Genders' }
  ];

  const interestOptions = [
    { id: 'home-decor', name: 'Home Decor' },
    { id: 'interior-design', name: 'Interior Design' },
    { id: 'luxury-goods', name: 'Luxury Goods' },
    { id: 'diy-projects', name: 'DIY Projects' },
    { id: 'real-estate', name: 'Real Estate' },
    { id: 'architecture', name: 'Architecture' }
  ];

  const locationOptions = ['Riyadh', 'Jeddah', 'Dammam', 'Mecca', 'Medina', 'Khobar', 'Abha', 'Tabuk'];

  const handlePlatformSelect = (platformId: any) => {
    setSelectedPlatform(platformId);
  };

  const handleAudienceToggle = (audienceId: string) => {
    setTargetAudience(prev =>
      prev.includes(audienceId)
        ? prev.filter(a => a !== audienceId)
        : [...prev, audienceId]
    );
  };

  const handleDemographicChange = (field: string, value: any) => {
    setDemographics(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleLocationToggle = (location: string) => {
    setDemographics(prev => ({
      ...prev,
      locations: prev.locations.includes(location)
        ? prev.locations.filter(l => l !== location)
        : [...prev.locations, location]
    }));
  };

  const handleInterestToggle = (interest: string) => {
    setDemographics(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const newImages = Array.from(files).map(file => URL.createObjectURL(file));
      setSelectedImages(prev => [...prev, ...newImages]);
    }
  };

  const removeImage = (index: number) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleCreateCampaign = async () => {
    setIsCreating(true);
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(startDate.getDate() + duration);
    
    const dailyBudget = budget / duration;

    const newCampaign: AdCampaign = {
      id: `ad_${Date.now()}`,
      name: campaignName || `${furnitureType} Furniture Campaign - ${new Date().toLocaleDateString()}`,
      platform: selectedPlatform,
      budget,
      duration,
      dailyBudget,
      totalSpent: 0,
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0],
      targetAudience,
      furnitureType,
      adSource,
      images: selectedImages.length > 0 ? selectedImages : [existingProducts[0].image],
      status: 'active',
      demographics,
      impressions: 0,
      clicks: 0,
      conversions: 0,
      ctr: 0,
      conversionRate: 0,
      dailyStats: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const campaignWithStats = updateCampaignStats(newCampaign);
    
    setActiveCampaigns(prev => [...prev, campaignWithStats]);
    setActiveTab('active');
    
    setStep(1);
    setSelectedPlatform('own-platform');
    setBudget(1000);
    setDuration(14);
    setFurnitureType('both');
    setAdSource('existing-listing');
    setSelectedImages([]);
    setCampaignName('');
    setTargetAudience([]);
    setDemographics({
      ageRange: [25, 55],
      gender: ['male', 'female'],
      interests: [],
      locations: ['Riyadh', 'Jeddah']
    });
    setIsCreating(false);
  };

  const calculateEstimatedReach = () => {
    const baseReach = budget * 20;
    const platformMultiplier = {
      'own-platform': 1.2,
      'facebook': 3.5,
      'instagram': 2.8,
      'google': 2.2,
      'twitter': 1.8
    };
    
    return Math.floor(baseReach * platformMultiplier[selectedPlatform]);
  };

  const toggleCampaignStatus = (campaignId: string) => {
    setActiveCampaigns(prev => prev.map(campaign => 
      campaign.id === campaignId 
        ? { 
            ...campaign, 
            status: campaign.status === 'active' ? 'paused' : 'active',
            updatedAt: new Date().toISOString()
          }
        : campaign
    ));
  };

  const deleteCampaign = (campaignId: string) => {
    setActiveCampaigns(prev => prev.filter(campaign => campaign.id !== campaignId));
  };

  const getCampaignStats = (campaign: AdCampaign) => {
    const now = new Date();
    const start = new Date(campaign.startDate);
    const end = new Date(campaign.endDate);
    const totalDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    const daysPassed = Math.ceil((now.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    
    const progress = Math.min((daysPassed / totalDays) * 100, 100);
    const budgetSpent = Math.min(campaign.dailyBudget * daysPassed, campaign.budget);
    const remainingBudget = campaign.budget - budgetSpent;
    const daysRemaining = Math.max(0, totalDays - daysPassed);

    return {
      daysRunning: daysPassed,
      daysRemaining,
      budgetSpent: Math.min(budgetSpent, campaign.budget),
      remainingBudget,
      progress,
      totalDays
    };
  };

  const renderStep1 = () => (
    <div className="space-y-8 animate-fadeIn">
      <div className="text-center">
        <h3 className="text-3xl font-bold text-gray-900 mb-3 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Choose Advertising Platform
        </h3>
        <p className="text-gray-600 max-w-2xl mx-auto text-lg">
          Select where you want to run your ads to reach your target audience effectively
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {platforms.map((platform) => (
          <div
            key={platform.id}
            onClick={() => handlePlatformSelect(platform.id)}
            className={`relative border-2 rounded-2xl p-6 cursor-pointer transition-all duration-300 transform hover:scale-105 hover:shadow-2xl ${
              selectedPlatform === platform.id
                ? 'border-blue-500 bg-gradient-to-br from-blue-50 to-indigo-50 shadow-lg'
                : 'border-gray-200 hover:border-blue-300 bg-white shadow-md'
            }`}
          >
            <div className="flex items-start space-x-4">
              <div className={`${platform.color} text-white p-4 rounded-xl shadow-lg`}>
                {platform.icon}
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-gray-900 text-lg mb-2">{platform.name}</h4>
                <p className="text-gray-600 text-sm leading-relaxed mb-2">{platform.description}</p>
                <p className="text-xs text-blue-600 font-semibold">{platform.reach}</p>
              </div>
            </div>
            {selectedPlatform === platform.id && (
              <div className="absolute top-4 right-4">
                <div className="bg-green-500 text-white p-2 rounded-full shadow-lg">
                  <AiOutlineCheckCircle className="text-sm" />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-8 animate-fadeIn">
      <div className="text-center">
        <h3 className="text-3xl font-bold text-gray-900 mb-3 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Campaign Details & Budget
        </h3>
        <p className="text-gray-600">Set up your advertising preferences and budget allocation</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-8 bg-white rounded-2xl p-8 border border-gray-200 shadow-lg">
          <div>
            <label className="block text-lg font-bold text-gray-900 mb-3">
              ✏️ Campaign Name
            </label>
            <input
              type="text"
              value={campaignName}
              onChange={(e) => setCampaignName(e.target.value)}
              placeholder="e.g., Luxury Furniture Promotion - Riyadh"
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
            />
          </div>

          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <label className="block text-lg font-bold text-gray-900 mb-1">
                  💰 Total Budget (SAR)
                </label>
                <p className="text-gray-500 text-sm">Set your total campaign budget</p>
              </div>
              <span className="text-3xl font-bold text-blue-600 bg-blue-50 px-4 py-2 rounded-xl">
                {budget} SAR
              </span>
            </div>
            <div className="space-y-4">
              <input
                type="range"
                min="500"
                max="10000"
                step="100"
                value={budget}
                onChange={(e) => setBudget(Number(e.target.value))}
                className="w-full h-3 bg-gradient-to-r from-blue-200 to-blue-500 rounded-lg appearance-none cursor-pointer slider"
              />
              <div className="flex justify-between text-sm text-gray-500 font-medium">
                <span>500 SAR</span>
                <span>5,000 SAR</span>
                <span>10,000 SAR</span>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <label className="block text-lg font-bold text-gray-900 mb-1">
                  📅 Duration (Days)
                </label>
                <p className="text-gray-500 text-sm">Campaign running period</p>
              </div>
              <span className="text-3xl font-bold text-green-600 bg-green-50 px-4 py-2 rounded-xl">
                {duration} days
              </span>
            </div>
            <div className="space-y-4">
              <input
                type="range"
                min="7"
                max="90"
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="w-full h-3 bg-gradient-to-r from-green-200 to-green-500 rounded-lg appearance-none cursor-pointer slider"
              />
              <div className="flex justify-between text-sm text-gray-500 font-medium">
                <span>7 days</span>
                <span>30 days</span>
                <span>90 days</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8 border border-gray-200 shadow-lg">
          <h4 className="font-bold text-gray-900 text-xl mb-6 text-center">📊 Estimated Results</h4>
          <div className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-200 hover:border-blue-300 transition-all duration-300 shadow-sm">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <AiOutlineEye className="text-blue-600 text-xl" />
                </div>
                <div>
                  <div className="text-gray-600 font-medium">Estimated Reach</div>
                  <div className="text-2xl font-bold text-gray-900">{calculateEstimatedReach().toLocaleString()}</div>
                </div>
              </div>
              <div className="text-sm text-blue-600 font-semibold">people</div>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-200 hover:border-green-300 transition-all duration-300 shadow-sm">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <AiOutlineDollar className="text-green-600 text-xl" />
                </div>
                <div>
                  <div className="text-gray-600 font-medium">Daily Budget</div>
                  <div className="text-2xl font-bold text-gray-900">{Math.floor(budget / duration)}</div>
                </div>
              </div>
              <div className="text-sm text-green-600 font-semibold">SAR/day</div>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-200 hover:border-purple-300 transition-all duration-300 shadow-sm">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <AiOutlineCalendar className="text-purple-600 text-xl" />
                </div>
                <div>
                  <div className="text-gray-600 font-medium">Total Cost</div>
                  <div className="text-2xl font-bold text-blue-600">{budget} SAR</div>
                </div>
              </div>
              <div className="text-sm text-purple-600 font-semibold">total</div>
            </div>

            <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-200 hover:border-orange-300 transition-all duration-300 shadow-sm">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                  <AiOutlineUser className="text-orange-600 text-xl" />
                </div>
                <div>
                  <div className="text-gray-600 font-medium">Cost per Click</div>
                  <div className="text-2xl font-bold text-gray-900">SAR {Math.floor(budget / (calculateEstimatedReach() * 0.05))}</div>
                </div>
              </div>
              <div className="text-sm text-orange-600 font-semibold">estimated</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-8 border border-gray-200 shadow-lg">
        <label className="block text-lg font-bold text-gray-900 mb-6">
          🛋️ Furniture Type
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {furnitureTypes.map((type) => (
            <label
              key={type.id}
              className={`relative border-2 rounded-2xl p-6 cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                furnitureType === type.id
                  ? 'border-blue-500 bg-gradient-to-br from-blue-50 to-indigo-50 shadow-lg'
                  : 'border-gray-200 hover:border-blue-300 bg-white shadow-md'
              }`}
            >
              <input
                type="radio"
                name="furnitureType"
                value={type.id}
                checked={furnitureType === type.id}
                onChange={(e) => setFurnitureType(e.target.value as any)}
                className="sr-only"
              />
              <div className="text-2xl mb-3">{type.icon}</div>
              <div className="font-bold text-gray-900 text-lg mb-2">{type.name}</div>
              <div className="text-sm text-gray-600">{type.description}</div>
              {furnitureType === type.id && (
                <div className="absolute top-4 right-4">
                  <AiOutlineCheckCircle className="text-blue-500 text-xl" />
                </div>
              )}
            </label>
          ))}
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-8 animate-fadeIn">
      <div className="text-center">
        <h3 className="text-3xl font-bold text-gray-900 mb-3 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          🎯 Target Audience & Demographics
        </h3>
        <p className="text-gray-600">Define who you want to see your ads for better targeting</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-2xl p-8 border border-gray-200 shadow-lg">
          <h4 className="font-bold text-gray-900 text-xl mb-6">👥 Demographics</h4>
          
          <div className="mb-6">
            <label className="block text-lg font-semibold text-gray-800 mb-4">
              Age Range: {demographics.ageRange[0]} - {demographics.ageRange[1]} years
            </label>
            <div className="space-y-4">
              <input
                type="range"
                min="18"
                max="65"
                value={demographics.ageRange[0]}
                onChange={(e) => handleDemographicChange('ageRange', [Number(e.target.value), demographics.ageRange[1]])}
                className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer"
              />
              <input
                type="range"
                min="18"
                max="65"
                value={demographics.ageRange[1]}
                onChange={(e) => handleDemographicChange('ageRange', [demographics.ageRange[0], Number(e.target.value)])}
                className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-sm text-gray-600">
                <span>18</span>
                <span>25</span>
                <span>35</span>
                <span>45</span>
                <span>55</span>
                <span>65+</span>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-lg font-semibold text-gray-800 mb-4">Gender</label>
            <div className="grid grid-cols-3 gap-3">
              {genderOptions.map((gender) => (
                <label
                  key={gender.id}
                  className={`flex items-center justify-center p-3 border-2 rounded-xl cursor-pointer transition-all ${
                    demographics.gender.includes(gender.id)
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={demographics.gender.includes(gender.id)}
                    onChange={(e) => {
                      if (gender.id === 'all') {
                        handleDemographicChange('gender', ['male', 'female', 'all']);
                      } else {
                        const newGender = e.target.checked
                          ? [...demographics.gender.filter(g => g !== 'all'), gender.id]
                          : demographics.gender.filter(g => g !== gender.id);
                        handleDemographicChange('gender', newGender.length === 0 ? ['all'] : newGender);
                      }
                    }}
                    className="sr-only"
                  />
                  <span className="font-medium">{gender.name}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-lg font-semibold text-gray-800 mb-4">Interests</label>
            <div className="grid grid-cols-2 gap-3">
              {interestOptions.map((interest) => (
                <label
                  key={interest.id}
                  className={`flex items-center p-3 border-2 rounded-xl cursor-pointer transition-all ${
                    demographics.interests.includes(interest.id)
                      ? 'border-green-500 bg-green-50 text-green-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={demographics.interests.includes(interest.id)}
                    onChange={() => handleInterestToggle(interest.id)}
                    className="sr-only"
                  />
                  <span className="font-medium">{interest.name}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white rounded-2xl p-8 border border-gray-200 shadow-lg">
            <h4 className="font-bold text-gray-900 text-xl mb-6">
              <AiOutlineEnvironment className="inline mr-2" />
              Target Locations
            </h4>
            <div className="grid grid-cols-2 gap-3">
              {locationOptions.map((location) => (
                <label
                  key={location}
                  className={`flex items-center p-3 border-2 rounded-xl cursor-pointer transition-all ${
                    demographics.locations.includes(location)
                      ? 'border-purple-500 bg-purple-50 text-purple-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={demographics.locations.includes(location)}
                    onChange={() => handleLocationToggle(location)}
                    className="sr-only"
                  />
                  <span className="font-medium">{location}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-8 border border-gray-200 shadow-lg">
            <h4 className="font-bold text-gray-900 text-xl mb-6">🎯 Audience Segments</h4>
            <div className="space-y-3 max-h-60 overflow-y-auto">
              {audienceOptions.map((audience) => (
                <label
                  key={audience.id}
                  className={`flex items-start space-x-3 p-3 border-2 rounded-xl cursor-pointer transition-all ${
                    targetAudience.includes(audience.id)
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={targetAudience.includes(audience.id)}
                    onChange={() => handleAudienceToggle(audience.id)}
                    className="mt-1 text-blue-600 focus:ring-blue-500 rounded"
                  />
                  <div className="flex-1">
                    <div className="font-semibold text-gray-900">{audience.name}</div>
                    <div className="text-sm text-gray-600">{audience.description}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>

      {targetAudience.length > 0 && (
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200">
          <div className="flex items-center space-x-3">
            <AiOutlineTeam className="text-green-600 text-2xl" />
            <div>
              <h4 className="font-semibold text-green-800 text-lg">Audience Summary</h4>
              <p className="text-green-700">
                Targeting {targetAudience.length} audience segments • {demographics.locations.length} locations • 
                Age {demographics.ageRange[0]}-{demographics.ageRange[1]} • {demographics.gender.join(', ')}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-8 animate-fadeIn">
      <div className="text-center">
        <h3 className="text-3xl font-bold text-gray-900 mb-3 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          🎨 Ad Creative & Summary
        </h3>
        <p className="text-gray-600">Upload compelling images and review your campaign</p>
      </div>

      <div className="bg-white rounded-2xl p-8 border border-gray-200 shadow-lg">
        <div className="border-2 border-dashed border-gray-300 rounded-2xl p-12 text-center transition-all duration-300 hover:border-blue-400 hover:bg-blue-50">
          <AiOutlineUpload className="mx-auto text-gray-400 text-5xl mb-6" />
          <p className="text-gray-600 text-xl mb-4 font-semibold">Drag and drop images or click to browse</p>
          <input
            type="file"
            multiple
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
            id="image-upload"
          />
          <label
            htmlFor="image-upload"
            className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-8 py-4 rounded-xl hover:from-blue-600 hover:to-blue-700 cursor-pointer inline-flex items-center space-x-3 transition-all duration-200 transform hover:scale-105 shadow-lg text-lg font-semibold"
          >
            <AiOutlinePlus className="text-xl" />
            <span>Choose Images</span>
          </label>
          <p className="text-sm text-gray-500 mt-4">PNG, JPG, WEBP up to 10MB each • Recommended: 1200x630px</p>
        </div>
      </div>

      {selectedImages.length > 0 && (
        <div className="bg-white rounded-2xl p-8 border border-gray-200 shadow-lg">
          <h4 className="font-bold text-gray-900 text-xl mb-6">
            Selected Images ({selectedImages.length})
          </h4>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {selectedImages.map((image, index) => (
              <div key={index} className="relative group animate-fadeIn">
                <img
                  src={image}
                  alt={`Ad image ${index + 1}`}
                  className="w-full h-32 object-cover rounded-xl shadow-lg group-hover:shadow-xl transition-all duration-300 transform group-hover:scale-105"
                />
                <button
                  onClick={() => removeImage(index)}
                  className="absolute top-2 right-2 bg-red-500 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-200 transform hover:scale-110 shadow-lg"
                >
                  <AiOutlineDelete className="text-sm" />
                </button>
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 rounded-xl transition-all duration-200" />
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8 border border-gray-200 shadow-lg">
        <h4 className="font-bold text-gray-900 text-2xl mb-8 text-center">📋 Campaign Summary</h4>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 bg-white rounded-xl border border-gray-200 shadow-sm">
              <span className="text-gray-600 font-semibold">Campaign Name:</span>
              <span className="font-bold text-gray-900">{campaignName || 'Untitled Campaign'}</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-white rounded-xl border border-gray-200 shadow-sm">
              <span className="text-gray-600 font-semibold">Platform:</span>
              <span className="font-bold text-gray-900 flex items-center space-x-2">
                {platforms.find(p => p.id === selectedPlatform)?.icon}
                <span>{platforms.find(p => p.id === selectedPlatform)?.name}</span>
              </span>
            </div>
            <div className="flex justify-between items-center p-4 bg-white rounded-xl border border-gray-200 shadow-sm">
              <span className="text-gray-600 font-semibold">Budget:</span>
              <span className="font-bold text-blue-600 text-lg">{budget} SAR</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-white rounded-xl border border-gray-200 shadow-sm">
              <span className="text-gray-600 font-semibold">Duration:</span>
              <span className="font-bold text-gray-900">{duration} days</span>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 bg-white rounded-xl border border-gray-200 shadow-sm">
              <span className="text-gray-600 font-semibold">Furniture Type:</span>
              <span className="font-bold text-gray-900 capitalize">{furnitureType.replace('-', ' ')}</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-white rounded-xl border border-gray-200 shadow-sm">
              <span className="text-gray-600 font-semibold">Target Audience:</span>
              <span className="font-bold text-green-600">{targetAudience.length} segments</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-white rounded-xl border border-gray-200 shadow-sm">
              <span className="text-gray-600 font-semibold">Locations:</span>
              <span className="font-bold text-purple-600">{demographics.locations.length} cities</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-white rounded-xl border border-gray-200 shadow-sm">
              <span className="text-gray-600 font-semibold">Daily Budget:</span>
              <span className="font-bold text-orange-600">{Math.floor(budget / duration)} SAR/day</span>
            </div>
          </div>
        </div>
        
        <div className="mt-6 p-6 bg-white rounded-xl border border-gray-200">
          <h5 className="font-semibold text-gray-800 mb-4 text-center">👥 Targeting Details</h5>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-lg font-bold text-blue-600">{demographics.ageRange[0]}-{demographics.ageRange[1]}</div>
              <div className="text-sm text-gray-600">Age Range</div>
            </div>
            <div>
              <div className="text-lg font-bold text-green-600">{demographics.gender.length}</div>
              <div className="text-sm text-gray-600">Genders</div>
            </div>
            <div>
              <div className="text-lg font-bold text-purple-600">{demographics.interests.length}</div>
              <div className="text-sm text-gray-600">Interests</div>
            </div>
            <div>
              <div className="text-lg font-bold text-orange-600">{demographics.locations.length}</div>
              <div className="text-sm text-gray-600">Locations</div>
            </div>
          </div>
        </div>

        <div className="mt-6 p-6 bg-white rounded-xl border border-gray-200">
          <h5 className="font-semibold text-gray-800 mb-4 text-center">📈 Expected Performance</h5>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-xl font-bold text-blue-600">{calculateEstimatedReach().toLocaleString()}</div>
              <div className="text-sm text-gray-600">Estimated Reach</div>
            </div>
            <div>
              <div className="text-xl font-bold text-green-600">{Math.floor(calculateEstimatedReach() * 0.05).toLocaleString()}</div>
              <div className="text-sm text-gray-600">Expected Clicks</div>
            </div>
            <div>
              <div className="text-xl font-bold text-purple-600">{Math.floor(calculateEstimatedReach() * 0.004).toLocaleString()}</div>
              <div className="text-sm text-gray-600">Expected Sales</div>
            </div>
            <div>
              <div className="text-xl font-bold text-orange-600">SAR {Math.floor(budget * 1.8)}</div>
              <div className="text-sm text-gray-600">Expected Revenue</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderActiveCampaigns = () => (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h3 className="text-3xl font-bold text-gray-900 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Active Campaigns
          </h3>
          <p className="text-gray-600 mt-2 text-lg">Manage and monitor your running advertising campaigns</p>
        </div>
        <button
          onClick={() => setActiveTab('create')}
          className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-8 py-4 rounded-xl hover:from-blue-600 hover:to-blue-700 flex items-center space-x-3 transition-all duration-200 transform hover:scale-105 shadow-lg text-lg font-semibold"
        >
          <AiOutlineRocket className="text-xl" />
          <span>Create New Campaign</span>
        </button>
      </div>

      {activeCampaigns.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-gray-300">
          <AiOutlineRocket className="mx-auto text-gray-400 text-6xl mb-6" />
          <h4 className="text-2xl font-bold text-gray-900 mb-3">No Active Campaigns</h4>
          <p className="text-gray-600 mb-8 max-w-md mx-auto text-lg">
            Create your first advertising campaign to reach more customers and grow your business
          </p>
          <button
            onClick={() => setActiveTab('create')}
            className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-10 py-4 rounded-xl hover:from-blue-600 hover:to-blue-700 transition-all duration-200 transform hover:scale-105 shadow-lg text-lg font-semibold"
          >
            Create Your First Campaign
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {activeCampaigns.map((campaign) => {
            const stats = getCampaignStats(campaign);
            return (
              <div key={campaign.id} className="bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
                <div className="h-48 bg-gradient-to-br from-gray-100 to-gray-200 relative overflow-hidden">
                  {campaign.images[0] && (
                    <img
                      src={campaign.images[0]}
                      alt={campaign.name}
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                    />
                  )}
                  <div className="absolute top-4 right-4">
                    <span className={`px-3 py-2 rounded-full text-sm font-semibold shadow-lg ${
                      campaign.status === 'active' ? 'bg-green-100 text-green-800 border border-green-200' :
                      campaign.status === 'paused' ? 'bg-yellow-100 text-yellow-800 border border-yellow-200' :
                      'bg-gray-100 text-gray-800 border border-gray-200'
                    }`}>
                      {campaign.status}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <div className={`p-3 rounded-xl text-white shadow-2xl ${platforms.find(p => p.id === campaign.platform)?.color}`}>
                      {platforms.find(p => p.id === campaign.platform)?.icon}
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <h4 className="font-bold text-gray-900 text-xl leading-tight">{campaign.name}</h4>
                  </div>
                  
                  <div className="mb-4">
                    <div className="flex justify-between text-sm text-gray-600 mb-2">
                      <span>Progress ({stats.daysRunning}/{stats.totalDays} days)</span>
                      <span>{Math.round(stats.progress)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${stats.progress}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="text-center p-2 bg-blue-50 rounded-lg">
                      <div className="text-lg font-bold text-blue-600">{campaign.impressions?.toLocaleString()}</div>
                      <div className="text-xs text-gray-600">Impressions</div>
                    </div>
                    <div className="text-center p-2 bg-green-50 rounded-lg">
                      <div className="text-lg font-bold text-green-600">{campaign.clicks?.toLocaleString()}</div>
                      <div className="text-xs text-gray-600">Clicks</div>
                    </div>
                    <div className="text-center p-2 bg-purple-50 rounded-lg">
                      <div className="text-lg font-bold text-purple-600">{campaign.conversions?.toLocaleString()}</div>
                      <div className="text-xs text-gray-600">Sales</div>
                    </div>
                    <div className="text-center p-2 bg-orange-50 rounded-lg">
                      <div className="text-lg font-bold text-orange-600">SAR {stats.budgetSpent}</div>
                      <div className="text-xs text-gray-600">Spent</div>
                    </div>
                  </div>

                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between items-center py-2 border-b border-gray-100">
                      <span className="text-gray-600">Budget:</span>
                      <span className="font-semibold text-gray-900">{campaign.budget} SAR</span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-gray-100">
                      <span className="text-gray-600">Duration:</span>
                      <span className="font-semibold text-gray-900">{campaign.duration} days</span>
                    </div>
                    <div className="flex justify-between items-center py-2">
                      <span className="text-gray-600">Locations:</span>
                      <span className="font-semibold text-gray-900">{campaign.demographics.locations.length} cities</span>
                    </div>
                  </div>

                  <div className="flex space-x-2 mt-6">
                    <button 
                      onClick={() => toggleCampaignStatus(campaign.id)}
                      className={`flex-1 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 flex items-center justify-center space-x-2 ${
                        campaign.status === 'active' 
                          ? 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200 shadow-md' 
                          : 'bg-green-100 text-green-700 hover:bg-green-200 shadow-md'
                      }`}
                    >
                      {campaign.status === 'active' ? <AiOutlinePause /> : <AiOutlinePlayCircle />}
                      <span>{campaign.status === 'active' ? 'Pause' : 'Resume'}</span>
                    </button>
                    <button className="flex-1 bg-blue-100 text-blue-700 px-4 py-3 rounded-xl text-sm font-semibold hover:bg-blue-200 transition-all duration-200 flex items-center justify-center space-x-2 shadow-md">
                      <AiOutlineBarChart />
                      <span>Analytics</span>
                    </button>
                    <button 
                      onClick={() => deleteCampaign(campaign.id)}
                      className="flex-1 bg-red-100 text-red-700 px-4 py-3 rounded-xl text-sm font-semibold hover:bg-red-200 transition-all duration-200 flex items-center justify-center space-x-2 shadow-md"
                    >
                      <AiOutlineDelete />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );

  const renderAnalytics = () => (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h3 className="text-3xl font-bold text-gray-900 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Campaign Analytics
          </h3>
          <p className="text-gray-600 mt-2 text-lg">Track performance and optimize your advertising strategy</p>
        </div>
      </div>

      {activeCampaigns.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-gray-300">
          <AiOutlineBarChart className="mx-auto text-gray-400 text-6xl mb-6" />
          <h4 className="text-2xl font-bold text-gray-900 mb-3">No Analytics Data</h4>
          <p className="text-gray-600 mb-8 max-w-md mx-auto text-lg">
            Create advertising campaigns to see detailed analytics and performance metrics
          </p>
          <button
            onClick={() => setActiveTab('create')}
            className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-10 py-4 rounded-xl hover:from-blue-600 hover:to-blue-700 transition-all duration-200 transform hover:scale-105 shadow-lg text-lg font-semibold"
          >
            Create Campaign
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-2xl p-8 border border-gray-200 shadow-lg">
            <h4 className="font-bold text-gray-900 text-xl mb-6">📈 Overall Performance</h4>
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center p-4 bg-blue-50 rounded-xl">
                <div className="text-3xl font-bold text-blue-600">
                  {activeCampaigns.reduce((sum, camp) => sum + (camp.impressions || 0), 0).toLocaleString()}
                </div>
                <div className="text-gray-600">Total Impressions</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-xl">
                <div className="text-3xl font-bold text-green-600">
                  {activeCampaigns.reduce((sum, camp) => sum + (camp.clicks || 0), 0).toLocaleString()}
                </div>
                <div className="text-gray-600">Total Clicks</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-xl">
                <div className="text-3xl font-bold text-purple-600">
                  {activeCampaigns.reduce((sum, camp) => sum + (camp.conversions || 0), 0).toLocaleString()}
                </div>
                <div className="text-gray-600">Total Sales</div>
              </div>
              <div className="text-center p-4 bg-orange-50 rounded-xl">
                <div className="text-3xl font-bold text-orange-600">
                  SAR {activeCampaigns.reduce((sum, camp) => sum + getCampaignStats(camp).budgetSpent, 0)}
                </div>
                <div className="text-gray-600">Total Spent</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-8 border border-gray-200 shadow-lg">
            <h4 className="font-bold text-gray-900 text-xl mb-6">🌐 Platform Performance</h4>
            <div className="space-y-4">
              {platforms.map(platform => {
                const platformCampaigns = activeCampaigns.filter(camp => camp.platform === platform.id);
                if (platformCampaigns.length === 0) return null;
                
                const totalImpressions = platformCampaigns.reduce((sum, camp) => sum + (camp.impressions || 0), 0);
                const totalClicks = platformCampaigns.reduce((sum, camp) => sum + (camp.clicks || 0), 0);
                const totalSpent = platformCampaigns.reduce((sum, camp) => sum + getCampaignStats(camp).budgetSpent, 0);
                
                return (
                  <div key={platform.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="flex items-center space-x-3">
                      <div className={`${platform.color} text-white p-2 rounded-lg`}>
                        {platform.icon}
                      </div>
                      <div>
                        <div className="font-semibold">{platform.name}</div>
                        <div className="text-sm text-gray-600">
                          {platformCampaigns.length} campaign{platformCampaigns.length > 1 ? 's' : ''}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-blue-600">{totalImpressions.toLocaleString()}</div>
                      <div className="text-sm text-gray-600">impressions</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-50">
      <div className="bg-white border-b border-gray-200 shadow-lg">
        <div className="px-8 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <button 
                onClick={onBack}
                className="flex items-center space-x-3 text-gray-600 hover:text-gray-700 transition-all duration-200 transform hover:scale-105 bg-white hover:bg-gray-50 px-6 py-3 rounded-xl border border-gray-200 shadow-sm"
              >
                <AiOutlineArrowLeft size={22} />
                <span className="font-semibold text-lg">Back to Home</span>
              </button>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 via-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Advertising Center
                </h1>
                <p className="text-gray-600 mt-2 text-lg">Promote your furniture and reach more customers effectively</p>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <nav className="flex space-x-3 bg-gray-100 p-2 rounded-2xl w-fit shadow-inner">
              {[
                { id: 'create', name: 'Create Campaign', icon: <AiOutlineRocket /> },
                { id: 'active', name: 'Active Campaigns', icon: <AiOutlineEye /> },
                { id: 'analytics', name: 'Analytics', icon: <AiOutlineBarChart /> },
                { id: 'history', name: 'Campaign History', icon: <AiOutlineCalendar /> }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-3 py-4 px-8 rounded-xl font-semibold text-lg transition-all duration-200 ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg transform scale-105'
                      : 'text-gray-600 hover:text-gray-700 hover:bg-white hover:shadow-md'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.name}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>
      </div>

      <div className="p-8 max-w-7xl mx-auto">
        {activeTab === 'create' && (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-xl overflow-hidden">
            <div className="border-b border-gray-200 p-8 bg-gradient-to-r from-gray-50 to-white">
              <div className="max-w-4xl mx-auto">
                <div className="flex items-center justify-between">
                  {[1, 2, 3, 4].map((stepNumber) => (
                    <div key={stepNumber} className="flex items-center flex-1">
                      <div className="flex items-center justify-center flex-col">
                        <div
                          className={`w-16 h-16 rounded-2xl flex items-center justify-center text-xl font-bold transition-all duration-300 shadow-lg ${
                            step >= stepNumber
                              ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white transform scale-110'
                              : 'bg-gray-200 text-gray-600'
                          }`}
                        >
                          {stepNumber}
                        </div>
                        <span className={`text-sm font-semibold mt-3 transition-all duration-300 ${
                          step >= stepNumber ? 'text-blue-600' : 'text-gray-500'
                        }`}>
                          {['Platform', 'Details', 'Audience', 'Creative'][stepNumber - 1]}
                        </span>
                      </div>
                      {stepNumber < 4 && (
                        <div
                          className={`flex-1 h-2 mx-6 transition-all duration-300 rounded-full ${
                            step > stepNumber ? 'bg-gradient-to-r from-blue-500 to-purple-500' : 'bg-gray-200'
                          }`}
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-8">
              {step === 1 && renderStep1()}
              {step === 2 && renderStep2()}
              {step === 3 && renderStep3()}
              {step === 4 && renderStep4()}

              <div className="flex justify-between mt-12 pt-8 border-t border-gray-200">
                <button
                  onClick={() => setStep(prev => Math.max(1, prev - 1))}
                  disabled={step === 1}
                  className={`px-10 py-4 rounded-xl border-2 font-semibold transition-all duration-200 flex items-center space-x-3 text-lg ${
                    step === 1
                      ? 'border-gray-200 text-gray-400 cursor-not-allowed'
                      : 'border-gray-300 text-gray-700 hover:bg-gray-50 hover:shadow-lg transform hover:scale-105'
                  }`}
                >
                  <AiOutlineArrowLeft />
                  <span>Previous</span>
                </button>

                {step < 4 ? (
                  <button
                    onClick={() => setStep(prev => Math.min(4, prev + 1))}
                    className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-10 py-4 rounded-xl hover:from-blue-600 hover:to-blue-700 font-semibold transition-all duration-200 transform hover:scale-105 shadow-lg flex items-center space-x-3 text-lg"
                  >
                    <span>Next Step</span>
                    <AiOutlineArrowLeft className="transform rotate-180" />
                  </button>
                ) : (
                  <button
                    onClick={handleCreateCampaign}
                    disabled={isCreating}
                    className="bg-gradient-to-r from-green-500 to-green-600 text-white px-10 py-4 rounded-xl hover:from-green-600 hover:to-green-700 font-semibold transition-all duration-200 transform hover:scale-105 shadow-lg flex items-center space-x-3 text-lg disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isCreating ? (
                      <>
                        <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Creating Campaign...</span>
                      </>
                    ) : (
                      <>
                        <AiOutlineRocket />
                        <span>Launch Campaign</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'active' && renderActiveCampaigns()}

        {activeTab === 'analytics' && renderAnalytics()}

        {activeTab === 'history' && (
          <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-gray-300 shadow-lg">
            <AiOutlineCalendar className="mx-auto text-gray-400 text-6xl mb-6" />
            <h4 className="text-2xl font-bold text-gray-900 mb-3">Campaign History</h4>
            <p className="text-gray-600 max-w-md mx-auto text-lg mb-8">View your past advertising campaigns and analyze their performance metrics over time</p>
            <button
              onClick={() => setActiveTab('create')}
              className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-10 py-4 rounded-xl hover:from-blue-600 hover:to-blue-700 transition-all duration-200 transform hover:scale-105 shadow-lg text-lg font-semibold"
            >
              Create New Campaign
            </button>
          </div>
        )}
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.6s ease-out;
        }
        .slider::-webkit-slider-thumb {
          appearance: none;
          height: 24px;
          width: 24px;
          border-radius: 50%;
          background: linear-gradient(135deg, #3b82f6, #8b5cf6);
          cursor: pointer;
          border: 3px solid white;
          box-shadow: 0 4px 8px rgba(0,0,0,0.3);
          transition: all 0.2s ease;
        }
        .slider::-webkit-slider-thumb:hover {
          transform: scale(1.1);
          box-shadow: 0 6px 12px rgba(0,0,0,0.4);
        }
        .slider::-moz-range-thumb {
          height: 24px;
          width: 24px;
          border-radius: 50%;
          background: linear-gradient(135deg, #3b82f6, #8b5cf6);
          cursor: pointer;
          border: 3px solid white;
          box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        }
      `}</style>
    </div>
  );
};

export default AdvertisingPage;