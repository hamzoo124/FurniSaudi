import React, { useState } from 'react';
import {
  AiOutlineArrowLeft,
  AiOutlineSave,
  AiOutlineUpload,
  AiOutlineDownload,
  AiOutlineShop,
  AiOutlineDollar,
  AiOutlineTruck,
  AiOutlineBell,
  AiOutlineLock,
  AiOutlineAppstore,
  AiOutlineApi,
  AiOutlineCheckCircle,
  AiOutlineCloseCircle,
  AiOutlineSetting,
  AiOutlineUser,
  AiOutlineGlobal,
  AiOutlineSafety,
  AiOutlineDatabase
} from "react-icons/ai";

// Types
interface StoreSettings {
  storeName: string;
  storeDescription: string;
  contactEmail: string;
  phoneNumber: string;
  address: string;
  city: string;
  country: string;
  currency: string;
  timezone: string;
  language: string;
  storeLogo?: string;
  favicon?: string;
}

interface PaymentSettings {
  acceptedMethods: string[];
  currency: string;
  taxRate: number;
  autoCapture: boolean;
  refundPolicy: string;
  installmentPlans: boolean;
  customDeposit: boolean;
  sandboxMode: boolean;
}

interface ShippingSettings {
  domesticShipping: number;
  internationalShipping: number;
  freeShippingThreshold: number;
  processingTime: string;
  shippingProviders: string[];
  packagingOptions: string[];
  deliveryAreas: string[];
  returnPolicy: string;
}

interface NotificationSettings {
  emailNotifications: boolean;
  smsNotifications: boolean;
  pushNotifications: boolean;
  orderAlerts: boolean;
  paymentAlerts: boolean;
  lowStockAlerts: boolean;
  reviewAlerts: boolean;
  marketingEmails: boolean;
  customerUpdates: boolean;
}

interface SecuritySettings {
  twoFactorAuth: boolean;
  loginAlerts: boolean;
  sessionTimeout: number;
  passwordExpiry: number;
  ipWhitelist: string[];
  apiRateLimit: number;
  auditLog: boolean;
}

interface IntegrationSettings {
  googleAnalytics: boolean;
  facebookPixel: boolean;
  googleAds: boolean;
  mailchimp: boolean;
  slack: boolean;
  zapier: boolean;
  quickbooks: boolean;
  shopify: boolean;
}

interface SettingsPageProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
  onLogout?: () => void;
}

type Section = 'general' | 'payment' | 'shipping' | 'notifications' | 'security' | 'integrations' | 'advanced';

interface SidebarItem {
  id: Section;
  label: string;
  icon: JSX.Element;
  description: string;
}

// Reusable Components
const SettingCard: React.FC<{
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}> = ({ title, icon, children }) => (
  <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
    <div className="flex items-center space-x-3 mb-4">
      <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
        {icon}
      </div>
      <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
    </div>
    {children}
  </div>
);

const FormField: React.FC<{
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: 'text' | 'email' | 'password' | 'number' | 'textarea' | 'tel';
  placeholder?: string;
  min?: string;
  max?: string;
  step?: string;
  readOnly?: boolean;
}> = ({ label, value, onChange, type = 'text', placeholder, min, max, step, readOnly }) => (
  <div>
    <label className="block text-sm font-medium text-gray-700 mb-2">{label}</label>
    {type === 'textarea' ? (
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={3}
        readOnly={readOnly}
        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none bg-white"
      />
    ) : (
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        min={min}
        max={max}
        step={step}
        readOnly={readOnly}
        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
      />
    )}
  </div>
);

const SelectField: React.FC<{
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
}> = ({ label, value, onChange, options }) => (
  <div>
    <label className="block text-sm font-medium text-gray-700 mb-2">{label}</label>
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
    >
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  </div>
);

const ToggleField: React.FC<{
  label: string;
  description: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  icon?: string;
}> = ({ label, description, checked, onChange, icon }) => (
  <label className="flex items-center justify-between p-4 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
    <div className="flex items-center space-x-3">
      {icon && <span className="text-lg">{icon}</span>}
      <div>
        <div className="font-medium text-gray-900">{label}</div>
        <div className="text-sm text-gray-500">{description}</div>
      </div>
    </div>
    <label className="relative inline-flex items-center cursor-pointer">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="sr-only peer"
      />
      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
    </label>
  </label>
);

// Individual Settings Components
const GeneralSettings: React.FC<{
  settings: StoreSettings;
  onChange: (settings: StoreSettings) => void;
}> = ({ settings, onChange }) => {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">General Settings</h2>
          <p className="text-gray-600 mt-2">Basic store information and preferences</p>
        </div>
        <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center text-white font-bold text-lg">
          EF
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <SettingCard title="Store Information" icon={<AiOutlineShop />}>
          <div className="space-y-4">
            <FormField
              label="Store Name"
              value={settings.storeName}
              onChange={(value) => onChange({ ...settings, storeName: value })}
              placeholder="Enter store name"
            />
            <FormField
              label="Contact Email"
              type="email"
              value={settings.contactEmail}
              onChange={(value) => onChange({ ...settings, contactEmail: value })}
              placeholder="contact@store.com"
            />
            <FormField
              label="Phone Number"
              type="tel"
              value={settings.phoneNumber}
              onChange={(value) => onChange({ ...settings, phoneNumber: value })}
              placeholder="+966 123 456 789"
            />
            <FormField
              label="Store Description"
              type="textarea"
              value={settings.storeDescription}
              onChange={(value) => onChange({ ...settings, storeDescription: value })}
              placeholder="Describe your store..."
            />
          </div>
        </SettingCard>

        <SettingCard title="Business Location" icon={<AiOutlineGlobal />}>
          <div className="space-y-4">
            <FormField
              label="Address"
              value={settings.address}
              onChange={(value) => onChange({ ...settings, address: value })}
              placeholder="Street address"
            />
            <FormField
              label="City"
              value={settings.city}
              onChange={(value) => onChange({ ...settings, city: value })}
              placeholder="City"
            />
            <FormField
              label="Country"
              value={settings.country}
              onChange={(value) => onChange({ ...settings, country: value })}
              placeholder="Country"
            />
            <SelectField
              label="Timezone"
              value={settings.timezone}
              onChange={(value) => onChange({ ...settings, timezone: value })}
              options={[
                { value: 'Asia/Riyadh', label: 'Asia/Riyadh (GMT+3)' },
                { value: 'Asia/Dubai', label: 'Asia/Dubai (GMT+4)' },
                { value: 'Europe/London', label: 'Europe/London (GMT+0)' },
                { value: 'America/New_York', label: 'America/New_York (GMT-5)' },
              ]}
            />
          </div>
        </SettingCard>

        <SettingCard title="Regional Settings" icon={<AiOutlineUser />}>
          <div className="space-y-4">
            <SelectField
              label="Language"
              value={settings.language}
              onChange={(value) => onChange({ ...settings, language: value })}
              options={[
                { value: 'en', label: 'English' },
                { value: 'ar', label: 'Arabic' },
                { value: 'fr', label: 'French' },
                { value: 'es', label: 'Spanish' },
              ]}
            />
            <SelectField
              label="Currency"
              value={settings.currency}
              onChange={(value) => onChange({ ...settings, currency: value })}
              options={[
                { value: 'SAR', label: 'Saudi Riyal (﷼)' },
                { value: 'USD', label: 'US Dollar ($)' },
                { value: 'EUR', label: 'Euro (€)' },
                { value: 'GBP', label: 'British Pound (£)' },
              ]}
            />
          </div>
        </SettingCard>

        <SettingCard title="Store Branding" icon={<AiOutlineSetting />}>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Store Logo</label>
              <div className="flex items-center space-x-4">
                <div className="w-20 h-20 bg-gray-200 rounded-lg flex items-center justify-center">
                  <span className="text-gray-500 text-sm">Upload Logo</span>
                </div>
                <div>
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                    Upload New
                  </button>
                  <p className="text-xs text-gray-500 mt-1">Recommended: 200x200px PNG</p>
                </div>
              </div>
            </div>
          </div>
        </SettingCard>
      </div>
    </div>
  );
};

const PaymentSettingsSection: React.FC<{
  settings: PaymentSettings;
  onChange: (settings: PaymentSettings) => void;
}> = ({ settings, onChange }) => {
  const paymentMethods = [
    { id: 'credit_card', name: 'Credit Card', icon: '💳', enabled: true },
    { id: 'bank_transfer', name: 'Bank Transfer', icon: '🏦', enabled: true },
    { id: 'apple_pay', name: 'Apple Pay', icon: '', enabled: true },
    { id: 'mada', name: 'Mada', icon: 'M', enabled: true },
    { id: 'stc_pay', name: 'STC Pay', icon: 'STC', enabled: false },
    { id: 'cash_on_delivery', name: 'Cash on Delivery', icon: '💵', enabled: true },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Payment Settings</h2>
        <p className="text-gray-600 mt-2">Configure payment methods and transaction settings</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <SettingCard title="Payment Methods" icon={<AiOutlineDollar />}>
          <div className="space-y-3">
            {paymentMethods.map((method) => (
              <ToggleField
                key={method.id}
                label={method.name}
                description={`Accept ${method.name} payments`}
                icon={method.icon}
                checked={settings.acceptedMethods.includes(method.id)}
                onChange={(checked) => {
                  const newMethods = checked
                    ? [...settings.acceptedMethods, method.id]
                    : settings.acceptedMethods.filter(m => m !== method.id);
                  onChange({ ...settings, acceptedMethods: newMethods });
                }}
              />
            ))}
          </div>
        </SettingCard>

        <SettingCard title="Payment Configuration" icon={<AiOutlineSetting />}>
          <div className="space-y-4">
            <FormField
              label="Tax Rate (%)"
              type="number"
              value={settings.taxRate.toString()}
              onChange={(value) => onChange({ ...settings, taxRate: parseFloat(value) })}
              min="0"
              max="100"
              step="0.1"
            />
            <SelectField
              label="Refund Policy"
              value={settings.refundPolicy}
              onChange={(value) => onChange({ ...settings, refundPolicy: value })}
              options={[
                { value: '14_days', label: '14 Days Refund' },
                { value: '30_days', label: '30 Days Refund' },
                { value: '60_days', label: '60 Days Refund' },
                { value: 'no_refunds', label: 'No Refunds' },
              ]}
            />
            <ToggleField
              label="Sandbox Mode"
              description="Test payments without processing real transactions"
              checked={settings.sandboxMode}
              onChange={(checked) => onChange({ ...settings, sandboxMode: checked })}
            />
          </div>
        </SettingCard>

        <SettingCard title="Furniture-Specific Options" icon={<AiOutlineDollar />}>
          <div className="space-y-4">
            <ToggleField
              label="Installment Plans"
              description="Allow customers to pay in multiple installments"
              checked={settings.installmentPlans}
              onChange={(checked) => onChange({ ...settings, installmentPlans: checked })}
            />
            <ToggleField
              label="Custom Deposit System"
              description="Require deposits for custom furniture orders"
              checked={settings.customDeposit}
              onChange={(checked) => onChange({ ...settings, customDeposit: checked })}
            />
            <ToggleField
              label="Auto-Capture Payments"
              description="Automatically capture payments when orders are confirmed"
              checked={settings.autoCapture}
              onChange={(checked) => onChange({ ...settings, autoCapture: checked })}
            />
          </div>
        </SettingCard>
      </div>
    </div>
  );
};

const ShippingSettingsSection: React.FC<{
  settings: ShippingSettings;
  onChange: (settings: ShippingSettings) => void;
}> = ({ settings, onChange }) => {
  const [newDeliveryArea, setNewDeliveryArea] = useState('');

  const handleAddDeliveryArea = () => {
    if (newDeliveryArea.trim() && !settings.deliveryAreas.includes(newDeliveryArea.trim())) {
      onChange({
        ...settings,
        deliveryAreas: [...settings.deliveryAreas, newDeliveryArea.trim()]
      });
      setNewDeliveryArea('');
    }
  };

  const handleRemoveDeliveryArea = (area: string) => {
    onChange({
      ...settings,
      deliveryAreas: settings.deliveryAreas.filter(a => a !== area)
    });
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Shipping Settings</h2>
        <p className="text-gray-600 mt-2">Configure delivery options and shipping rates</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <SettingCard title="Shipping Rates" icon={<AiOutlineTruck />}>
          <div className="space-y-4">
            <FormField
              label="Domestic Shipping (SAR)"
              type="number"
              value={settings.domesticShipping.toString()}
              onChange={(value) => onChange({ ...settings, domesticShipping: parseFloat(value) })}
            />
            <FormField
              label="International Shipping (SAR)"
              type="number"
              value={settings.internationalShipping.toString()}
              onChange={(value) => onChange({ ...settings, internationalShipping: parseFloat(value) })}
            />
            <FormField
              label="Free Shipping Threshold (SAR)"
              type="number"
              value={settings.freeShippingThreshold.toString()}
              onChange={(value) => onChange({ ...settings, freeShippingThreshold: parseFloat(value) })}
            />
            <FormField
              label="Processing Time (Days)"
              value={settings.processingTime}
              onChange={(value) => onChange({ ...settings, processingTime: value })}
              placeholder="e.g., 3-5"
            />
          </div>
        </SettingCard>

        <SettingCard title="Delivery Options" icon={<AiOutlineTruck />}>
          <div className="space-y-4">
            <SelectField
              label="Return Policy"
              value={settings.returnPolicy}
              onChange={(value) => onChange({ ...settings, returnPolicy: value })}
              options={[
                { value: '14_days', label: '14 Days Return' },
                { value: '30_days', label: '30 Days Return' },
                { value: '60_days', label: '60 Days Return' },
                { value: 'no_returns', label: 'No Returns' },
              ]}
            />
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Delivery Areas</label>
              <div className="flex flex-wrap gap-2 mb-3">
                {settings.deliveryAreas.map((area, index) => (
                  <div key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm flex items-center space-x-2">
                    <span>{area}</span>
                    <button
                      onClick={() => handleRemoveDeliveryArea(area)}
                      className="text-blue-600 hover:text-blue-800 text-xs"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={newDeliveryArea}
                  onChange={(e) => setNewDeliveryArea(e.target.value)}
                  placeholder="Add delivery area"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <button
                  onClick={handleAddDeliveryArea}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Add
                </button>
              </div>
            </div>
          </div>
        </SettingCard>
      </div>
    </div>
  );
};

const NotificationSettingsSection: React.FC<{
  settings: NotificationSettings;
  onChange: (settings: NotificationSettings) => void;
}> = ({ settings, onChange }) => {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Notification Settings</h2>
        <p className="text-gray-600 mt-2">Manage your notification preferences</p>
      </div>

      <div className="grid grid-cols-1 gap-8">
        <SettingCard title="Notification Channels" icon={<AiOutlineBell />}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ToggleField
              label="Email Notifications"
              description="Receive notifications via email"
              checked={settings.emailNotifications}
              onChange={(checked) => onChange({ ...settings, emailNotifications: checked })}
            />
            <ToggleField
              label="SMS Notifications"
              description="Receive notifications via SMS"
              checked={settings.smsNotifications}
              onChange={(checked) => onChange({ ...settings, smsNotifications: checked })}
            />
            <ToggleField
              label="Push Notifications"
              description="Receive browser push notifications"
              checked={settings.pushNotifications}
              onChange={(checked) => onChange({ ...settings, pushNotifications: checked })}
            />
          </div>
        </SettingCard>

        <SettingCard title="Notification Types" icon={<AiOutlineBell />}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ToggleField
              label="New Order Alerts"
              description="Get notified when new orders are placed"
              checked={settings.orderAlerts}
              onChange={(checked) => onChange({ ...settings, orderAlerts: checked })}
            />
            <ToggleField
              label="Payment Alerts"
              description="Get notified for payment updates"
              checked={settings.paymentAlerts}
              onChange={(checked) => onChange({ ...settings, paymentAlerts: checked })}
            />
            <ToggleField
              label="Low Stock Alerts"
              description="Get notified when inventory is low"
              checked={settings.lowStockAlerts}
              onChange={(checked) => onChange({ ...settings, lowStockAlerts: checked })}
            />
            <ToggleField
              label="Review Alerts"
              description="Get notified for new customer reviews"
              checked={settings.reviewAlerts}
              onChange={(checked) => onChange({ ...settings, reviewAlerts: checked })}
            />
            <ToggleField
              label="Customer Updates"
              description="Get notified about customer activities"
              checked={settings.customerUpdates}
              onChange={(checked) => onChange({ ...settings, customerUpdates: checked })}
            />
            <ToggleField
              label="Marketing Emails"
              description="Receive marketing and promotional emails"
              checked={settings.marketingEmails}
              onChange={(checked) => onChange({ ...settings, marketingEmails: checked })}
            />
          </div>
        </SettingCard>
      </div>
    </div>
  );
};

const SecuritySettingsSection: React.FC<{
  settings: SecuritySettings;
  onChange: (settings: SecuritySettings) => void;
}> = ({ settings, onChange }) => {
  const [newIp, setNewIp] = useState('');

  const handleAddIp = () => {
    if (newIp.trim() && !settings.ipWhitelist.includes(newIp.trim())) {
      onChange({
        ...settings,
        ipWhitelist: [...settings.ipWhitelist, newIp.trim()]
      });
      setNewIp('');
    }
  };

  const handleRemoveIp = (ip: string) => {
    onChange({
      ...settings,
      ipWhitelist: settings.ipWhitelist.filter(i => i !== ip)
    });
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Security Settings</h2>
        <p className="text-gray-600 mt-2">Manage security and access control</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <SettingCard title="Security Features" icon={<AiOutlineSafety />}>
          <div className="space-y-4">
            <ToggleField
              label="Two-Factor Authentication"
              description="Add an extra layer of security to your account"
              checked={settings.twoFactorAuth}
              onChange={(checked) => onChange({ ...settings, twoFactorAuth: checked })}
            />
            <ToggleField
              label="Login Alerts"
              description="Get notified of new login sessions"
              checked={settings.loginAlerts}
              onChange={(checked) => onChange({ ...settings, loginAlerts: checked })}
            />
            <ToggleField
              label="Audit Log"
              description="Keep track of all account activities"
              checked={settings.auditLog}
              onChange={(checked) => onChange({ ...settings, auditLog: checked })}
            />
          </div>
        </SettingCard>

        <SettingCard title="Session Management" icon={<AiOutlineLock />}>
          <div className="space-y-4">
            <FormField
              label="Session Timeout (Minutes)"
              type="number"
              value={settings.sessionTimeout.toString()}
              onChange={(value) => onChange({ ...settings, sessionTimeout: parseInt(value) })}
            />
            <FormField
              label="Password Expiry (Days)"
              type="number"
              value={settings.passwordExpiry.toString()}
              onChange={(value) => onChange({ ...settings, passwordExpiry: parseInt(value) })}
            />
            <FormField
              label="API Rate Limit (Requests/Hour)"
              type="number"
              value={settings.apiRateLimit.toString()}
              onChange={(value) => onChange({ ...settings, apiRateLimit: parseInt(value) })}
            />
          </div>
        </SettingCard>

        <SettingCard title="IP Whitelist" icon={<AiOutlineSafety />}>
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2 mb-3">
              {settings.ipWhitelist.map((ip, index) => (
                <div key={index} className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm flex items-center space-x-2">
                  <span>{ip}</span>
                  <button
                    onClick={() => handleRemoveIp(ip)}
                    className="text-green-600 hover:text-green-800 text-xs"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
            <div className="flex space-x-2">
              <input
                type="text"
                value={newIp}
                onChange={(e) => setNewIp(e.target.value)}
                placeholder="Add IP address"
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                onClick={handleAddIp}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Add
              </button>
            </div>
          </div>
        </SettingCard>
      </div>
    </div>
  );
};

const IntegrationSettingsSection: React.FC<{
  settings: IntegrationSettings;
  onChange: (settings: IntegrationSettings) => void;
}> = ({ settings, onChange }) => {
  const integrationList = [
    { key: 'googleAnalytics', name: 'Google Analytics', description: 'Website analytics and tracking' },
    { key: 'facebookPixel', name: 'Facebook Pixel', description: 'Conversion tracking and optimization' },
    { key: 'googleAds', name: 'Google Ads', description: 'Advertising campaign integration' },
    { key: 'mailchimp', name: 'Mailchimp', description: 'Email marketing automation' },
    { key: 'slack', name: 'Slack', description: 'Team communication and alerts' },
    { key: 'zapier', name: 'Zapier', description: 'Workflow automation' },
    { key: 'quickbooks', name: 'QuickBooks', description: 'Accounting integration' },
    { key: 'shopify', name: 'Shopify', description: 'E-commerce platform integration' },
  ];

  const [apiKeys, setApiKeys] = useState<Record<string, string>>({
    googleAnalytics: '••••••••••••••••',
    facebookPixel: '••••••••••••••••',
    googleAds: '••••••••••••••••',
    mailchimp: '••••••••••••••••',
    slack: '••••••••••••••••',
    zapier: '••••••••••••••••',
    quickbooks: '••••••••••••••••',
    shopify: '••••••••••••••••',
  });

  const handleApiKeyChange = (integrationKey: string, value: string) => {
    setApiKeys(prev => ({
      ...prev,
      [integrationKey]: value
    }));
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Integration Settings</h2>
        <p className="text-gray-600 mt-2">Connect with third-party services and APIs</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {integrationList.map((integration) => (
          <div key={integration.key} className="bg-gray-50 rounded-xl p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-gray-900">{integration.name}</h3>
                <p className="text-sm text-gray-600">{integration.description}</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings[integration.key as keyof IntegrationSettings] as boolean}
                  onChange={(e) => onChange({
                    ...settings,
                    [integration.key]: e.target.checked
                  })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            {settings[integration.key as keyof IntegrationSettings] && (
              <div className="space-y-3">
                <FormField
                  label="API Key"
                  type="password"
                  value={apiKeys[integration.key]}
                  onChange={(value) => handleApiKeyChange(integration.key, value)}
                  placeholder="Enter API key"
                />
                <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                  Configure Integration
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const AdvancedSettingsSection: React.FC<{
  onLogout?: () => void;
}> = ({ onLogout }) => {
  const [apiKey, setApiKey] = useState('sk_live_xxxxxxxxxxxxxxxx');
  const [webhookUrl, setWebhookUrl] = useState('');

  const handleRegenerateApiKey = () => {
    const newKey = `sk_live_${Math.random().toString(36).substr(2, 16)}`;
    setApiKey(newKey);
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Advanced Settings</h2>
        <p className="text-gray-600 mt-2">Advanced configuration and tools</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <SettingCard title="API Access" icon={<AiOutlineApi />}>
          <div className="space-y-4">
            <FormField
              label="API Key"
              value={apiKey}
              onChange={setApiKey}
              readOnly
            />
            <FormField
              label="Webhook URL"
              value={webhookUrl}
              onChange={setWebhookUrl}
              placeholder="https://your-domain.com/webhooks"
            />
            <div className="flex space-x-3">
              <button 
                onClick={handleRegenerateApiKey}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
              >
                Regenerate Key
              </button>
              <button className="bg-gray-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors">
                View Documentation
              </button>
            </div>
          </div>
        </SettingCard>

        <SettingCard title="Data Management" icon={<AiOutlineDatabase />}>
          <div className="space-y-4">
            <button className="w-full text-left p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
              <div className="font-medium text-gray-900">Export Store Data</div>
              <div className="text-sm text-gray-500">Download all store data including products, orders, and customers</div>
            </button>
            <button className="w-full text-left p-4 border border-red-200 rounded-lg hover:bg-red-50 transition-colors">
              <div className="font-medium text-red-900">Delete Store Data</div>
              <div className="text-sm text-red-500">Permanently delete all store data. This action cannot be undone.</div>
            </button>
          </div>
        </SettingCard>

        {onLogout && (
          <SettingCard title="Account Actions" icon={<AiOutlineUser />}>
            <div className="space-y-3">
              <button 
                onClick={onLogout}
                className="w-full bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 transition-colors font-medium"
              >
                Logout
              </button>
              <button className="w-full bg-gray-600 text-white py-3 px-4 rounded-lg hover:bg-gray-700 transition-colors font-medium">
                Delete Account
              </button>
            </div>
          </SettingCard>
        )}
      </div>
    </div>
  );
};

// Main Settings Page Component
const SettingsPage: React.FC<SettingsPageProps> = ({ onNavigate, onBack, onLogout }) => {
  const [activeSection, setActiveSection] = useState<Section>('general');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [searchTerm, setSearchTerm] = useState('');

  // Store Settings
  const [storeSettings, setStoreSettings] = useState<StoreSettings>({
    storeName: 'Elite Furniture Co.',
    storeDescription: 'Premium custom furniture and luxury home decor',
    contactEmail: 'contact@elitefurniture.com',
    phoneNumber: '+966 123 456 789',
    address: '123 King Fahd Road',
    city: 'Riyadh',
    country: 'Saudi Arabia',
    currency: 'SAR',
    timezone: 'Asia/Riyadh',
    language: 'en'
  });

  // Payment Settings
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>({
    acceptedMethods: ['credit_card', 'bank_transfer', 'apple_pay', 'mada'],
    currency: 'SAR',
    taxRate: 15,
    autoCapture: true,
    refundPolicy: '30_days',
    installmentPlans: true,
    customDeposit: true,
    sandboxMode: false
  });

  // Shipping Settings
  const [shippingSettings, setShippingSettings] = useState<ShippingSettings>({
    domesticShipping: 50,
    internationalShipping: 200,
    freeShippingThreshold: 1000,
    processingTime: '3-5',
    shippingProviders: ['aramax', 'dhl', 'fedex', 'smsa'],
    packagingOptions: ['standard', 'premium', 'custom_crate'],
    deliveryAreas: ['Riyadh', 'Jeddah', 'Dammam'],
    returnPolicy: '30_days'
  });

  // Notification Settings
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    emailNotifications: true,
    smsNotifications: true,
    pushNotifications: true,
    orderAlerts: true,
    paymentAlerts: true,
    lowStockAlerts: true,
    reviewAlerts: true,
    marketingEmails: false,
    customerUpdates: true
  });

  // Security Settings
  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>({
    twoFactorAuth: true,
    loginAlerts: true,
    sessionTimeout: 60,
    passwordExpiry: 90,
    ipWhitelist: ['192.168.1.1', '10.0.0.1'],
    apiRateLimit: 1000,
    auditLog: true
  });

  // Integration Settings
  const [integrations, setIntegrations] = useState<IntegrationSettings>({
    googleAnalytics: true,
    facebookPixel: true,
    googleAds: false,
    mailchimp: true,
    slack: false,
    zapier: false,
    quickbooks: false,
    shopify: false
  });

  // Handler functions
  const handleSaveSettings = async () => {
    setIsSaving(true);
    setSaveStatus('idle');
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // In real implementation, you would send this to your backend
      const settingsData = {
        storeSettings,
        paymentSettings,
        shippingSettings,
        notificationSettings,
        securitySettings,
        integrations
      };
      
      console.log('Settings saved:', settingsData);
      setSaveStatus('success');
      setTimeout(() => setSaveStatus('idle'), 3000);
    } catch (error) {
      console.error('Error saving settings:', error);
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    } finally {
      setIsSaving(false);
    }
  };

  const handleExportSettings = () => {
    const settingsData = {
      storeSettings,
      paymentSettings,
      shippingSettings,
      notificationSettings,
      securitySettings,
      integrations,
      exportDate: new Date().toISOString(),
      version: '1.0'
    };
    
    const dataStr = JSON.stringify(settingsData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = `elite-furniture-settings-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  };

  const handleImportSettings = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const settings = JSON.parse(e.target?.result as string);
        // Here you would validate and set the imported settings
        console.log('Settings imported:', settings);
        alert('Settings imported successfully!');
      } catch (error) {
        alert('Error importing settings. Please check the file format.');
      }
    };
    reader.readAsText(file);
  };

  // Sidebar navigation items
  const sidebarItems: SidebarItem[] = [
    { 
      id: 'general', 
      label: 'General', 
      icon: <AiOutlineSetting />, 
      description: 'Store basic information and preferences' 
    },
    { 
      id: 'payment', 
      label: 'Payment', 
      icon: <AiOutlineDollar />, 
      description: 'Payment methods and transaction settings' 
    },
    { 
      id: 'shipping', 
      label: 'Shipping', 
      icon: <AiOutlineTruck />, 
      description: 'Delivery options and shipping rates' 
    },
    { 
      id: 'notifications', 
      label: 'Notifications', 
      icon: <AiOutlineBell />, 
      description: 'Alert and notification preferences' 
    },
    { 
      id: 'security', 
      label: 'Security', 
      icon: <AiOutlineSafety />, 
      description: 'Security and access control' 
    },
    { 
      id: 'integrations', 
      label: 'Integrations', 
      icon: <AiOutlineAppstore />, 
      description: 'Third-party services and APIs' 
    },
    { 
      id: 'advanced', 
      label: 'Advanced', 
      icon: <AiOutlineApi />, 
      description: 'Advanced configuration and tools' 
    }
  ];

  // Filter sidebar items based on search
  const filteredSidebarItems = sidebarItems.filter(item =>
    item.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Settings sections components
  const renderSection = () => {
    switch (activeSection) {
      case 'general':
        return <GeneralSettings settings={storeSettings} onChange={setStoreSettings} />;
      case 'payment':
        return <PaymentSettingsSection settings={paymentSettings} onChange={setPaymentSettings} />;
      case 'shipping':
        return <ShippingSettingsSection settings={shippingSettings} onChange={setShippingSettings} />;
      case 'notifications':
        return <NotificationSettingsSection settings={notificationSettings} onChange={setNotificationSettings} />;
      case 'security':
        return <SecuritySettingsSection settings={securitySettings} onChange={setSecuritySettings} />;
      case 'integrations':
        return <IntegrationSettingsSection settings={integrations} onChange={setIntegrations} />;
      case 'advanced':
        return <AdvancedSettingsSection onLogout={onLogout} />;
      default:
        return <GeneralSettings settings={storeSettings} onChange={setStoreSettings} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-lg border-b border-gray-200/60 sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={onBack}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-700 transition-all duration-200 hover:bg-gray-100 rounded-lg px-3 py-2"
              >
                <AiOutlineArrowLeft size={20} />
                <span className="font-medium">Dashboard</span>
              </button>
              <div className="h-8 w-px bg-gray-300"></div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                  Settings
                </h1>
                <p className="text-gray-600 text-sm">Manage your store configuration and preferences</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              {/* Search Bar */}
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search settings..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white/50 backdrop-blur-sm"
                />
                <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                  <AiOutlineSetting size={18} />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button 
                  onClick={handleExportSettings}
                  className="flex items-center space-x-2 bg-white text-gray-700 border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 transition-all duration-200 font-medium shadow-sm hover:shadow-md"
                >
                  <AiOutlineDownload size={18} />
                  <span>Export</span>
                </button>
                
                <label className="flex items-center space-x-2 bg-white text-gray-700 border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 transition-all duration-200 font-medium shadow-sm hover:shadow-md cursor-pointer">
                  <AiOutlineUpload size={18} />
                  <span>Import</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportSettings}
                    className="hidden"
                  />
                </label>
                
                <button 
                  onClick={handleSaveSettings}
                  disabled={isSaving}
                  className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-2 rounded-lg hover:from-blue-700 hover:to-blue-800 disabled:from-blue-400 disabled:to-blue-500 transition-all duration-200 font-medium shadow-lg hover:shadow-xl disabled:shadow-none"
                >
                  <AiOutlineSave size={18} />
                  <span>{isSaving ? 'Saving...' : 'Save Changes'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Save Status */}
          {saveStatus !== 'idle' && (
            <div className={`mt-4 flex items-center space-x-2 rounded-lg p-4 border ${
              saveStatus === 'success' 
                ? 'text-green-800 bg-green-50 border-green-200' 
                : 'text-red-800 bg-red-50 border-red-200'
            }`}>
              {saveStatus === 'success' ? (
                <AiOutlineCheckCircle className="text-green-600" size={20} />
              ) : (
                <AiOutlineCloseCircle className="text-red-600" size={20} />
              )}
              <span className="font-medium">
                {saveStatus === 'success' 
                  ? 'Settings saved successfully!' 
                  : 'Error saving settings. Please try again.'}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6 max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar Navigation */}
          <div className="lg:w-80">
            <div className="bg-white/80 backdrop-blur-lg rounded-2xl border border-gray-200/60 p-6 shadow-sm sticky top-24">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Settings Menu</h3>
              
              <nav className="space-y-2">
                {filteredSidebarItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveSection(item.id)}
                    className={`flex items-start space-x-3 w-full p-4 rounded-xl text-left transition-all duration-200 group ${
                      activeSection === item.id
                        ? 'bg-blue-50 border border-blue-200 shadow-sm'
                        : 'hover:bg-gray-50 border border-transparent'
                    }`}
                  >
                    <div className={`p-2 rounded-lg ${
                      activeSection === item.id
                        ? 'bg-blue-100 text-blue-600'
                        : 'bg-gray-100 text-gray-600 group-hover:bg-gray-200'
                    }`}>
                      {item.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className={`font-semibold ${
                        activeSection === item.id ? 'text-blue-900' : 'text-gray-900'
                      }`}>
                        {item.label}
                      </div>
                      <div className={`text-sm ${
                        activeSection === item.id ? 'text-blue-700' : 'text-gray-500'
                      } mt-1`}>
                        {item.description}
                      </div>
                    </div>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Settings Content */}
          <div className="flex-1">
            <div className="bg-white/80 backdrop-blur-lg rounded-2xl border border-gray-200/60 p-8 shadow-sm">
              {renderSection()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;