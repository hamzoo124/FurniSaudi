// Hero section placeholder 
